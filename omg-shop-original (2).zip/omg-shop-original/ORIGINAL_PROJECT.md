# OMG SHOP — Original Project Snapshot

บันทึกจากเว็บตัวอย่างที่ติดตั้งใน Sandbox เมื่อ 2026-10-05

## เนื้อหา
- `htdocs/` — source เว็บไซต์ PHP สำหรับ preview
- `database/catullusshop_combined.sql` — ฐานข้อมูลหลักรวม migrations

## หมายเหตุ
- snapshot นี้ใช้ฐานข้อมูล preview แยกภายใน และเปิด preview-only mode สำหรับ reCAPTCHA
- ห้ามนำค่า preview-only ไปใช้บน production
- ไม่รวมไฟล์รหัสผ่านแอดมินและข้อมูลลับของการเชื่อมต่อ
