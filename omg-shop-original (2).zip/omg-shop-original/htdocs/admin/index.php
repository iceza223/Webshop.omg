<?php
header('Location: /admin/iceland/', true, 302);
exit;
