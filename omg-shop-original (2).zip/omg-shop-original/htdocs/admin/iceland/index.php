<?php

declare(strict_types=1);

session_start();

require_once __DIR__ . '/config.php';


/* =========================================
   Helper
========================================= */

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url = 'index.php'): never
{
    header('Location: ' . $url);
    exit;
}

function csrfToken(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf'];
}

function checkCsrf(): void
{
    if (
        empty($_POST['csrf']) ||
        empty($_SESSION['csrf']) ||
        !hash_equals($_SESSION['csrf'], $_POST['csrf'])
    ) {
        http_response_code(403);
        exit('คำขอไม่ถูกต้อง');
    }
}

function formatSize(int $bytes): string
{
    if ($bytes >= 1024 * 1024 * 1024) {
        return number_format($bytes / (1024 * 1024 * 1024), 2) . ' GB';
    }

    if ($bytes >= 1024 * 1024) {
        return number_format($bytes / (1024 * 1024), 2) . ' MB';
    }

    if ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    }

    return $bytes . ' B';
}

function safeFilename(string $filename): string
{
    $filename = basename($filename);

    // รองรับภาษาไทยและตัวอักษรทั่วไป
    $filename = preg_replace(
        '/[^\p{L}\p{N}\._\- ]/u',
        '_',
        $filename
    );

    $filename = trim($filename);

    if ($filename === '' || $filename === '.' || $filename === '..') {
        $filename = 'file';
    }

    return $filename;
}


/* =========================================
   Login
========================================= */

if (isset($_POST['login'])) {

    checkCsrf();

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (
        hash_equals(ADMIN_USERNAME, $username) &&
        hash_equals(ADMIN_PASSWORD, $password)
    ) {
        session_regenerate_id(true);

        $_SESSION['admin_logged_in'] = true;

        redirect();
    }

    $loginError = 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
}


/* =========================================
   Logout
========================================= */

if (isset($_GET['logout'])) {

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    redirect();
}


/* =========================================
   Login Page
========================================= */

if (empty($_SESSION['admin_logged_in'])):
?>
<!DOCTYPE html>
<html lang="th">
<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>OMGVIP ADMIN LOGIN</title>

<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:20px;
    font-family:Arial,sans-serif;
    color:#fff;
    background:
        radial-gradient(circle at top,#3d0000,#100000 45%,#050505);
}

.login-box{
    width:100%;
    max-width:420px;
    padding:30px;
    border-radius:24px;
    background:rgba(20,20,20,.92);
    border:1px solid rgba(255,40,40,.35);
    box-shadow:0 0 45px rgba(255,0,0,.20);
}

.logo{
    text-align:center;
    font-size:30px;
    font-weight:bold;
    color:#ff3333;
    text-shadow:0 0 20px red;
    margin-bottom:8px;
}

.subtitle{
    text-align:center;
    color:#888;
    margin-bottom:25px;
}

input{
    width:100%;
    padding:15px;
    margin-bottom:12px;
    border:1px solid #333;
    border-radius:12px;
    background:#0c0c0c;
    color:#fff;
    font-size:16px;
    outline:none;
}

input:focus{
    border-color:#ff3030;
}

button{
    width:100%;
    padding:15px;
    border:0;
    border-radius:12px;
    color:#fff;
    font-weight:bold;
    font-size:17px;
    cursor:pointer;
    background:linear-gradient(90deg,#b00000,#ff3030);
}

.error{
    padding:12px;
    margin-bottom:15px;
    border-radius:10px;
    background:#350000;
    color:#ff7777;
    text-align:center;
}

</style>

</head>

<body>

<div class="login-box">

    <div class="logo">🔥 OMGVIP</div>

    <div class="subtitle">
        ADMIN FILE MANAGER
    </div>

    <?php if (!empty($loginError)): ?>

        <div class="error">
            <?=h($loginError)?>
        </div>

    <?php endif; ?>

    <form method="post">

        <input
            type="hidden"
            name="csrf"
            value="<?=h(csrfToken())?>"
        >

        <input
            type="text"
            name="username"
            placeholder="ชื่อผู้ใช้"
            autocomplete="username"
            required
        >

        <input
            type="password"
            name="password"
            placeholder="รหัสผ่าน"
            autocomplete="current-password"
            required
        >

        <button type="submit" name="login">
            🔐 เข้าสู่ระบบ
        </button>

    </form>

</div>

</body>
</html>

<?php
exit;
endif;


/* =========================================
   Actions
========================================= */

$message = '';
$error = '';


/* ---------- Upload ---------- */

if (isset($_POST['upload'])) {

    checkCsrf();

    if (
        !isset($_FILES['file']) ||
        !is_array($_FILES['file'])
    ) {
        $error = 'ไม่พบไฟล์';
    } else {

        $file = $_FILES['file'];

        if ($file['error'] !== UPLOAD_ERR_OK) {

            $error = 'อัปโหลดไฟล์ไม่สำเร็จ รหัส: ' . $file['error'];

        } elseif ($file['size'] > MAX_FILE_SIZE) {

            $error = 'ไฟล์ใหญ่เกินกำหนด';

        } else {

            $originalName = basename((string)$file['name']);

            $extension = strtolower(
                pathinfo($originalName, PATHINFO_EXTENSION)
            );

            if (
                $extension === '' ||
                !in_array($extension, ALLOWED_EXTENSIONS, true)
            ) {

                $error = 'ไม่อนุญาตให้อัปโหลดไฟล์ประเภทนี้';

            } else {

                $filename = safeFilename($originalName);

                /*
                   ป้องกันชื่อไฟล์ซ้ำ
                */
                $base = pathinfo(
                    $filename,
                    PATHINFO_FILENAME
                );

                $ext = pathinfo(
                    $filename,
                    PATHINFO_EXTENSION
                );

                $finalName = $filename;

                $counter = 1;

                while (
                    file_exists(UPLOAD_DIR . $finalName)
                ) {

                    $finalName =
                        $base .
                        '_' .
                        $counter .
                        ($ext !== '' ? '.' . $ext : '');

                    $counter++;
                }

                $target =
                    UPLOAD_DIR .
                    $finalName;


                if (
                    move_uploaded_file(
                        $file['tmp_name'],
                        $target
                    )
                ) {

                    $stmt = $pdo->prepare("
                        INSERT INTO files
                        (
                            filename,
                            original_name,
                            filesize,
                            filetype,
                            upload_date
                        )
                        VALUES
                        (
                            :filename,
                            :original_name,
                            :filesize,
                            :filetype,
                            NOW()
                        )
                    ");

                    $stmt->execute([
                        ':filename'     => $finalName,
                        ':original_name'=> $originalName,
                        ':filesize'     => (int)$file['size'],
                        ':filetype'     => $file['type'] ?? null
                    ]);

                    $message = 'อัปโหลดไฟล์สำเร็จ';

                } else {

                    $error = 'ไม่สามารถบันทึกไฟล์ได้';
                }
            }
        }
    }
}


/* ---------- Rename ---------- */

if (isset($_POST['rename'])) {

    checkCsrf();

    $id = (int)($_POST['id'] ?? 0);

    $newName = safeFilename(
        trim($_POST['new_name'] ?? '')
    );

    $stmt = $pdo->prepare(
        "SELECT * FROM files WHERE id = ?"
    );

    $stmt->execute([$id]);

    $file = $stmt->fetch();

    if (!$file) {

        $error = 'ไม่พบไฟล์';

    } elseif ($newName === '') {

        $error = 'กรุณาระบุชื่อไฟล์';

    } else {

        /*
           รักษานามสกุลเดิม
        */
        $oldExt = strtolower(
            pathinfo(
                $file['filename'],
                PATHINFO_EXTENSION
            )
        );

        $newExt = strtolower(
            pathinfo(
                $newName,
                PATHINFO_EXTENSION
            )
        );

        if ($newExt === '' && $oldExt !== '') {
            $newName .= '.' . $oldExt;
        }

        $newName = safeFilename($newName);

        $oldPath =
            UPLOAD_DIR .
            basename($file['filename']);

        $newPath =
            UPLOAD_DIR .
            $newName;

        if (
            file_exists($newPath) &&
            $newName !== $file['filename']
        ) {

            $error = 'มีไฟล์ชื่อนี้อยู่แล้ว';

        } elseif (!is_file($oldPath)) {

            $error = 'ไม่พบไฟล์ในเซิร์ฟเวอร์';

        } elseif (
            rename($oldPath, $newPath)
        ) {

            $stmt = $pdo->prepare("
                UPDATE files
                SET filename = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $newName,
                $id
            ]);

            $message = 'เปลี่ยนชื่อไฟล์สำเร็จ';

        } else {

            $error = 'เปลี่ยนชื่อไฟล์ไม่สำเร็จ';
        }
    }
}


/* ---------- Delete ---------- */

if (isset($_POST['delete'])) {

    checkCsrf();

    $id = (int)($_POST['id'] ?? 0);

    $stmt = $pdo->prepare(
        "SELECT * FROM files WHERE id = ?"
    );

    $stmt->execute([$id]);

    $file = $stmt->fetch();

    if (!$file) {

        $error = 'ไม่พบไฟล์';

    } else {

        $path =
            UPLOAD_DIR .
            basename($file['filename']);

        if (is_file($path)) {
            unlink($path);
        }

        $stmt = $pdo->prepare(
            "DELETE FROM files WHERE id = ?"
        );

        $stmt->execute([$id]);

        $message = 'ลบไฟล์สำเร็จ';
    }
}


/* =========================================
   File List
========================================= */

$stmt = $pdo->query("
    SELECT *
    FROM files
    ORDER BY id DESC
");

$files = $stmt->fetchAll();

$totalFiles = count($files);

$totalSize = 0;

foreach ($files as $f) {
    $totalSize += (int)$f['filesize'];
}

?>
<!DOCTYPE html>
<html lang="th">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>OMGVIP FILE ADMIN</title>

<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    color:#fff;
    font-family:Arial,sans-serif;

    background:
        radial-gradient(
            circle at top,
            #400000 0,
            #120000 38%,
            #050505 75%
        );
}

.container{
    width:100%;
    max-width:1050px;
    margin:auto;
    padding:18px;
}

.header{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:15px;
    margin-bottom:18px;
}

.logo{
    font-size:28px;
    font-weight:bold;
    color:#ff3030;
    text-shadow:0 0 18px red;
}

.logout{
    text-decoration:none;
    color:#fff;
    background:#202020;
    padding:11px 16px;
    border-radius:10px;
}

.card{
    margin-bottom:18px;
    padding:20px;

    border-radius:20px;

    background:rgba(18,18,18,.90);

    border:1px solid rgba(255,0,0,.30);

    box-shadow:
        0 0 30px rgba(255,0,0,.10);
}

.title{
    font-size:20px;
    font-weight:bold;
    margin-bottom:15px;
}

.stats{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:12px;
    margin-bottom:18px;
}

.stat{
    padding:16px;
    text-align:center;
    border-radius:14px;
    background:#0b0b0b;
    border:1px solid #292929;
}

.stat-number{
    font-size:25px;
    font-weight:bold;
    color:#ff3535;
}

.stat-label{
    margin-top:5px;
    color:#888;
}

.upload-box{
    padding:25px 15px;
    text-align:center;
    border:2px dashed #8e2222;
    border-radius:16px;
}

input[type=file]{
    width:100%;
    padding:14px;
    color:#ddd;
    background:#080808;
    border:1px solid #333;
    border-radius:11px;
}

.btn{
    border:0;
    border-radius:11px;
    padding:12px 16px;
    color:#fff;
    font-weight:bold;
    cursor:pointer;
}

.upload-btn{
    width:100%;
    margin-top:12px;
    font-size:17px;
    background:linear-gradient(
        90deg,
        #b00000,
        #ff3030
    );
}

.success{
    padding:13px;
    margin-bottom:18px;
    border-radius:11px;
    background:#07351b;
    color:#63ff99;
}

.error{
    padding:13px;
    margin-bottom:18px;
    border-radius:11px;
    background:#390000;
    color:#ff7777;
}

.file{
    padding:16px;
    margin-top:12px;
    border-radius:15px;
    background:#0b0b0b;
    border:1px solid #292929;
}

.filename{
    font-size:17px;
    font-weight:bold;
    word-break:break-all;
}

.info{
    color:#888;
    font-size:13px;
    margin:8px 0 13px;
}

.actions{
    display:flex;
    flex-wrap:wrap;
    gap:8px;
}

.actions form{
    flex:1;
    min-width:110px;
}

.actions a,
.actions button{
    display:block;
    width:100%;
    text-align:center;
    text-decoration:none;
    border:0;
    border-radius:9px;
    padding:11px 8px;
    font-weight:bold;
    cursor:pointer;
}

.download{
    background:#075d30;
    color:#fff;
}

.copy-link{
    background:#194f6d;
    color:#fff;
}

.copy-link:focus{
    outline:2px solid #6fd7ff;
    outline-offset:2px;
}

.rename{
    background:#765100;
    color:#fff;
}

.delete{
    background:#720d0d;
    color:#fff;
}

.rename-box{
    display:none;
    margin-top:12px;
}

.rename-box input{
    width:100%;
    padding:12px;
    border:1px solid #444;
    border-radius:9px;
    background:#111;
    color:#fff;
    margin-bottom:7px;
}

.empty{
    padding:30px;
    text-align:center;
    color:#777;
}

@media(max-width:600px){

    .container{
        padding:12px;
    }

    .header{
        align-items:flex-start;
    }

    .logo{
        font-size:22px;
    }

    .stats{
        grid-template-columns:1fr 1fr;
    }

    .actions{
        display:grid;
        grid-template-columns:1fr 1fr;
    }

    .actions form{
        min-width:0;
    }

}

</style>

</head>

<body>

<div class="container">

    <div class="header">

        <div class="logo">
            🔥 OMGVIP FILE ADMIN
        </div>

        <a
            href="?logout=1"
            class="logout"
        >
            ออกจากระบบ
        </a>

    </div>


    <?php if ($message !== ''): ?>

        <div class="success">
            ✅ <?=h($message)?>
        </div>

    <?php endif; ?>


    <?php if ($error !== ''): ?>

        <div class="error">
            ❌ <?=h($error)?>
        </div>

    <?php endif; ?>


    <!-- Statistics -->

    <div class="stats">

        <div class="stat">

            <div class="stat-number">
                <?=number_format($totalFiles)?>
            </div>

            <div class="stat-label">
                ไฟล์ทั้งหมด
            </div>

        </div>

        <div class="stat">

            <div class="stat-number">
                <?=h(formatSize($totalSize))?>
            </div>

            <div class="stat-label">
                ขนาดรวม
            </div>

        </div>

    </div>


    <!-- Upload -->

    <div class="card">

        <div class="title">
            📤 อัปโหลดไฟล์
        </div>

        <div class="upload-box">

            <form
                method="post"
                enctype="multipart/form-data"
            >

                <input
                    type="hidden"
                    name="csrf"
                    value="<?=h(csrfToken())?>"
                >

                <input
                    type="file"
                    name="file"
                    required
                >

                <button
                    class="btn upload-btn"
                    type="submit"
                    name="upload"
                >
                    ⬆️ อัปโหลดไฟล์
                </button>

            </form>

            <div style="color:#777;margin-top:10px">
                สูงสุด <?=h(formatSize(MAX_FILE_SIZE))?>
            </div>

        </div>

    </div>


    <!-- File list -->

    <div class="card">

        <div class="title">
            📁 จัดการไฟล์
        </div>


        <?php if (!$files): ?>

            <div class="empty">
                ยังไม่มีไฟล์
            </div>

        <?php else: ?>


            <?php foreach ($files as $file): ?>

                <?php

                $downloadUrl =
                    rtrim(BASE_URL, '/') .
                    '/download.php?id=' .
                    rawurlencode((string)$file['id']);

                ?>

                <div class="file">

                    <div class="filename">
                        📄 <?=h($file['filename'])?>
                    </div>

                    <div class="info">

                        ขนาด:
                        <?=h(formatSize((int)$file['filesize']))?>

                        &nbsp; | &nbsp;

                        อัปโหลด:
                        <?=h($file['upload_date'])?>

                    </div>


                    <div class="actions">

                        <form
                            method="get"
                            action="download.php"
                            target="_blank"
                        >

                            <input
                                type="hidden"
                                name="id"
                                value="<?=h((string)$file['id'])?>"
                            >

                            <button
                                class="download"
                                type="submit"
                            >
                                ⬇️ ดาวน์โหลด
                            </button>

                        </form>


                        <button
                            class="copy-link"
                            type="button"
                            data-url="<?=h($downloadUrl)?>"
                            onclick="copyDownloadLink(this)"
                        >
                            🔗 คัดลอกลิงก์
                        </button>


                        <button
                            class="rename"
                            type="button"
                            onclick="showRename(<?=h((string)$file['id'])?>)"
                        >
                            ✏️ เปลี่ยนชื่อ
                        </button>


                        <form
                            method="post"
                            onsubmit="return confirm('ต้องการลบไฟล์นี้หรือไม่?')"
                        >

                            <input
                                type="hidden"
                                name="csrf"
                                value="<?=h(csrfToken())?>"
                            >

                            <input
                                type="hidden"
                                name="id"
                                value="<?=h((string)$file['id'])?>"
                            >

                            <button
                                class="delete"
                                type="submit"
                                name="delete"
                            >
                                🗑️ ลบ
                            </button>

                        </form>

                    </div>


                    <div
                        class="rename-box"
                        id="rename-<?=h((string)$file['id'])?>"
                    >

                        <form method="post">

                            <input
                                type="hidden"
                                name="csrf"
                                value="<?=h(csrfToken())?>"
                            >

                            <input
                                type="hidden"
                                name="id"
                                value="<?=h((string)$file['id'])?>"
                            >

                            <input
                                type="text"
                                name="new_name"
                                value="<?=h($file['filename'])?>"
                                required
                            >

                            <button
                                class="btn upload-btn"
                                type="submit"
                                name="rename"
                            >
                                💾 บันทึกชื่อใหม่
                            </button>

                        </form>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

</div>


<script>

async function copyDownloadLink(button){

    const url = button.dataset.url || '';

    if(!url){
        return;
    }

    const originalText = button.textContent;

    try{
        if(navigator.clipboard && window.isSecureContext){
            await navigator.clipboard.writeText(url);
        }else{
            const textarea = document.createElement('textarea');
            textarea.value = url;
            textarea.setAttribute('readonly', '');
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.focus();
            textarea.select();
            document.execCommand('copy');
            textarea.remove();
        }

        button.textContent = '✅ คัดลอกแล้ว';

        window.setTimeout(function(){
            button.textContent = originalText;
        }, 1800);
    }catch(error){
        window.prompt('คัดลอกลิงก์นี้:', url);
    }
}

function showRename(id){

    const box =
        document.getElementById(
            'rename-' + id
        );

    if(!box){
        return;
    }

    if(box.style.display === 'block'){
        box.style.display = 'none';
    }else{
        box.style.display = 'block';
    }
}

</script>

</body>
</html>