<?php
/*
 * THLIVE-OMGMOD - Mobile PHP Download Page
 * แก้ไขลิงก์ดาวน์โหลดได้ใน $versions
 */

$versions = [
    [
        "version" => "V2",
        "image" => "https://omgvip.shop/download/files/5980502dfad2b123_v2.png",
        "url" => "https://www.mediafire.com/file/7mi3ohtegjbv69t/THLIVE-OMG.apk/file"
    ],
    [
        "version" => "V3",
        "image" => "https://omgvip.shop/download/files/4393b2c44e9e2533_v3.png",
        "url" => "https://www.mediafire.com/file/exexp44h0809v51/THLIVE-OMGMOD_V3.apk/file"
    ],
    [
        "version" => "V4",
        "image" => "https://omgvip.shop/View/thlive-omgmod-v4.png",
        "url" => "https://www.mediafire.com/file/70kjtfy5hkev69h/THLIVE-OMGMOD_4.apk/file"
    ]
];

$exampleCode = "OMG-ABCD-1234";
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<meta name="theme-color" content="#090806">
<title>ดาวโหลดแอปTHLIVEMOD</title>

<style>
* {
    box-sizing: border-box;
}

html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    overflow-x: hidden;
}

body {
    background: #090806;
    color: #fff8df;
    font-family: Tahoma, Arial, sans-serif;
}

.header {
    text-align: center;
    padding: 18px 12px;
    background: linear-gradient(180deg, #21170a 0%, #0d0b07 62%, #090806 100%);
    border-bottom: 1px solid #8f6413;
}

.title {
    margin: 0;
    font-size: 26px;
    font-weight: 900;
    background: linear-gradient(90deg, #b7f000 0%, #ffe45c 34%, #ffd447 52%, #ff9d1c 76%, #ff3b18 100%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 0 0 18px rgba(255, 190, 30, .22);
}

.subtitle {
    margin: 6px 0 0;
    font-size: 13px;
    color: #d8cba8;
}

.notice {
    margin: 8px 0 0;
    font-size: 13px;
    line-height: 1.7;
    color: #ffe36a;
}

.container {
    width: 100%;
    max-width: 520px;
    margin: 0 auto;
    padding: 12px 10px 30px;
}

/* รหัส */
.code-box {
    text-align: center;
    margin-bottom: 14px;
    padding: 15px 10px;
    border: 1px solid #d3a329;
    border-radius: 15px;
    background: linear-gradient(135deg, #241a08, #100d08);
    box-shadow: inset 0 1px 0 rgba(255, 228, 92, .12), 0 0 20px rgba(255, 174, 0, .08);
}

.code-title {
    margin: 0;
    font-size: 18px;
    font-weight: 900;
    color: #ffe36a;
}

.code-desc {
    display: inline-block;
    margin: 8px 0 12px;
    padding: 5px 14px;
    border-radius: 999px;
    background: #ffe45c;
    color: #241500;
    font-size: 17px;
    font-weight: 900;
    box-shadow: 0 0 14px rgba(255, 212, 71, .5);
}

.example-code {
    display: inline-block;
    padding: 12px 20px;
    border-radius: 12px;
    border: 2px solid #ffe45c;
    background: linear-gradient(135deg, #211500, #4a2d00);
    color: #fff3a3;
    box-shadow: 0 0 22px rgba(255, 193, 7, .45), inset 0 0 12px rgba(255, 228, 92, .12);
    font-size: 25px;
    font-weight: 900;
    letter-spacing: 1.5px;
    text-shadow: 0 0 10px rgba(255, 228, 92, .75);
}

/* การ์ด */
.card {
    width: 100%;
    margin-bottom: 18px;
    padding: 7px;
    border: 1px solid #624813;
    border-radius: 15px;
    background: linear-gradient(180deg, #171209, #0d0b07);
    box-shadow: 0 8px 25px rgba(0,0,0,.55), 0 0 18px rgba(255, 174, 0, .08);
}

.poster {
    display: block;
    width: 100%;
    height: auto;
    border-radius: 10px;
}

.version {
    text-align: center;
    margin: 10px 0;
    font-size: 18px;
    font-weight: 900;
    color: #ffe36a;
    text-shadow: 0 0 12px rgba(255, 190, 30, .2);
}

.download {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    min-height: 54px;
    border-radius: 11px;
    background: linear-gradient(115deg, #8ec400 0%, #d7ef26 18%, #ffd447 43%, #ffb01c 65%, #ff4a17 100%);
    color: #130d02;
    box-shadow: 0 6px 18px rgba(255, 157, 0, .24), 0 0 10px rgba(177, 239, 0, .12);
    text-decoration: none;
    font-size: 17px;
    font-weight: 900;
    -webkit-tap-highlight-color: transparent;
}

.download:active {
    transform: scale(.98);
}

.download.disabled {
    background: #555;
    color: #d8d8d8;
    box-shadow: none;
    cursor: not-allowed;
}

.footer {
    text-align: center;
    padding: 0 10px 25px;
    color: #a99669;
    font-size: 11px;
}

@media (min-width: 600px) {
    .container {
        max-width: 540px;
    }
}
</style>
</head>

<body>

<header class="header">
    <h1 class="title">ดาวโหลดแอปTHLIVEMOD</h1>
    <p class="subtitle">หน้าดาวน์โหลดสำหรับมือถือ</p>
    <p class="notice">-ใช้ V2 ฟรี<br>- (V3-V4 แก้ไม่ให้พิม)</p>
</header>

<main class="container">

    <section class="code-box">
        <h2 class="code-title">🔑 รหัสใหม่ใช้ได้ทุกเวอร์ชั่น</h2>
        <p class="code-desc"><strong>ตัวอย่างรหัส</strong></p>
        <div class="example-code">
            <?= htmlspecialchars($exampleCode, ENT_QUOTES, 'UTF-8') ?>
        </div>
    </section>

    <?php foreach ($versions as $item): ?>
        <article class="card">

            <img
                class="poster"
                src="<?= htmlspecialchars($item['image'], ENT_QUOTES, 'UTF-8') ?>"
                alt="THLIVE-OMGMOD <?= htmlspecialchars($item['version'], ENT_QUOTES, 'UTF-8') ?>"
            >

            <div class="version">
                THLIVE-OMGMOD <?= htmlspecialchars($item['version'], ENT_QUOTES, 'UTF-8') ?>
            </div>

            <a
                class="download"
                href="<?= htmlspecialchars($item['url'], ENT_QUOTES, 'UTF-8') ?>"
                target="_blank"
                rel="noopener noreferrer"
            >
                ⬇️ ดาวน์โหลด <?= htmlspecialchars($item['version'], ENT_QUOTES, 'UTF-8') ?>
            </a>

        </article>
    <?php endforeach; ?>

</main>

<footer class="footer">
    THLIVE-OMGMOD • Mobile Download
</footer>

</body>
</html>
