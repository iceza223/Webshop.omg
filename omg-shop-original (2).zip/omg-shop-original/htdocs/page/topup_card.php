<?php
if (!isset($_SESSION['id'])) {
    echo '<div class="container-sm mt-5"><div class="alert alert-warning text-center">กรุณาเข้าสู่ระบบก่อนเติมเงิน</div></div>';
    return;
}
?>
<div class="container-sm mt-4">
    <div class="xez-card p-4">
        <div class="mb-4 text-center">
            <h4 class="fw-bold mb-1 text-dark"><i class="fa-solid fa-credit-card text-xez-primary me-2"></i>เติมเงินด้วยบัตร TrueMoney</h4>
            <p class="text-muted small mb-1">กรอกเลขบัตรทรูมันนี่ 14 หลัก แล้วรอแอดมินตรวจสอบ</p>
            <p class="text-warning small fw-bold">แอดมินจะดำเนินการภายใน 24 ชั่วโมง</p>
        </div>
        <div class="alert alert-info small">
            <i class="fa-solid fa-circle-info me-1"></i> กรุณาตรวจสอบเลขบัตรให้ถูกต้องก่อนส่ง ระบบจะไม่เปิดเผยเลขบัตรในประวัติทั่วไป
        </div>
        <div class="card-fee-notice mb-4">
            <div class="d-flex align-items-center gap-2 mb-2">
                <i class="fa-solid fa-calculator"></i>
                <strong>ตารางคำนวณยอดสุทธิหลังหัก 25%</strong>
            </div>
            <p class="small mb-2">ยอดสุทธิเป็นตัวอย่างเพื่อให้ตรวจสอบก่อนส่งบัตร โดยระบบจะหัก 25% จากมูลค่าบัตร</p>
            <div class="table-responsive">
                <table class="table table-sm align-middle mb-0 card-fee-table">
                    <thead><tr><th>มูลค่าบัตร</th><th>หัก 25%</th><th>ยอดสุทธิที่ได้รับ</th></tr></thead>
                    <tbody>
                        <tr><td>50 บาท</td><td>12.50 บาท</td><td><strong>37.50 บาท</strong></td></tr>
                        <tr><td>90 บาท</td><td>22.50 บาท</td><td><strong>67.50 บาท</strong></td></tr>
                        <tr><td>150 บาท</td><td>37.50 บาท</td><td><strong>112.50 บาท</strong></td></tr>
                        <tr><td>300 บาท</td><td>75 บาท</td><td><strong>225 บาท</strong></td></tr>
                        <tr><td>500 บาท</td><td>125 บาท</td><td><strong>375 บาท</strong></td></tr>
                        <tr><td>1,000 บาท</td><td>250 บาท</td><td><strong>750 บาท</strong></td></tr>
                    </tbody>
                </table>
            </div>
            <div class="small mt-2"><i class="fa-solid fa-circle-info me-1"></i>ยอดจริงจะยืนยันโดยแอดมินหลังตรวจสอบบัตร และตารางนี้ยังไม่เปลี่ยนยอดในระบบโดยอัตโนมัติ</div>
        </div>
        <form id="truemoneyCardForm" class="col-lg-8 mx-auto">
            <label class="form-label fw-bold">เลขบัตรทรูมันนี่ 14 หลัก</label>
            <input type="text" id="card_number" class="form-control text-center py-3 fs-4" inputmode="numeric" autocomplete="off" maxlength="14" pattern="[0-9]{14}" placeholder="กรอกเลขบัตร 14 หลัก" required>
            <div class="form-text mb-4">กรอกเฉพาะตัวเลข ไม่ต้องเว้นวรรค</div>
            <button class="btn btn-topup-confirm w-100 py-3 fw-bold" type="submit"><i class="fa-solid fa-paper-plane me-2"></i>ส่งคำขอเติมเงิน</button>
            <a href="?page=topup" class="btn btn-outline-secondary w-100 py-3 mt-2">ยกเลิก</a>
        </form>
    </div>
</div>
<script>
$('#card_number').on('input', function(){ this.value = this.value.replace(/\D/g,'').slice(0,14); });
$('#truemoneyCardForm').on('submit', function(e){
    e.preventDefault();
    const card = $('#card_number').val();
    if (!/^\d{14}$/.test(card)) { Swal.fire({icon:'warning',title:'เลขบัตรไม่ถูกต้อง',text:'กรุณากรอกเลขบัตร 14 หลัก'}); return; }
    const fd = new FormData(); fd.append('card_number', card);
    Swal.fire({title:'กำลังส่งคำขอ...',allowOutsideClick:false,didOpen:()=>Swal.showLoading()});
    $.ajax({type:'POST',url:'system/truemoney_card_request.php',data:fd,contentType:false,processData:false})
      .done(function(res){ Swal.fire({icon:'success',title:'ส่งคำขอแล้ว',text:res.message}).then(()=>location.href='?page=profile&subpage=topuphis'); })
      .fail(function(xhr){ const r=xhr.responseJSON; Swal.fire({icon:'error',title:'ส่งคำขอไม่สำเร็จ',text:r?.message||'กรุณาลองใหม่อีกครั้ง'}); });
});
</script>
<style>
.truemoney-card-form input{letter-spacing:.18em}
.card-fee-notice{padding:16px;border:1px solid rgba(255,179,0,.45);border-radius:14px;background:linear-gradient(145deg,rgba(67,31,15,.88),rgba(26,14,14,.94));color:#ffe8b0;box-shadow:0 8px 22px rgba(0,0,0,.18)}
.card-fee-notice>div:first-child{color:#ffd166}.card-fee-notice p,.card-fee-notice .small{color:#e8cfa0}.card-fee-table{color:#fff0c7;border-color:rgba(255,210,120,.22)}.card-fee-table th{color:#ffd166;background:rgba(255,179,0,.12);white-space:nowrap}.card-fee-table td{border-color:rgba(255,210,120,.18)}.card-fee-table td:last-child{color:#86efac}
</style>
