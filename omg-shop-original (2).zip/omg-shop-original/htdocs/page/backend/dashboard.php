<?php
// Dashboard metrics use the site's configured timezone and transaction timestamps.
date_default_timezone_set('Asia/Bangkok');

$midnight = strtotime('today 00:00:00');
$tomorrow = strtotime('+1 day', $midnight);
$date_day = date('Y-m-d H:i:s', $midnight);
$date_tomorrow = date('Y-m-d H:i:s', $tomorrow);
$date_month = date('Y-m-01 00:00:00');

// Website launch date: yesterday, so today is counted as day 2.
$site_launch_date = '2026-08-30';
$site_start_ts = strtotime($site_launch_date . ' 00:00:00');
$site_days = max(1, (int) floor((time() - $site_start_ts) / 86400) + 1);

$purchase_all_q = dd_q('SELECT COALESCE(SUM(price), 0) AS total, COUNT(*) AS count FROM boxlog');
$purchase_all = $purchase_all_q ? ($purchase_all_q->fetch(PDO::FETCH_ASSOC) ?: []) : [];
$purchase_all_total = (float) ($purchase_all['total'] ?? 0);
$purchase_all_count = (int) ($purchase_all['count'] ?? 0);

$purchase_today_q = dd_q(
    'SELECT COALESCE(SUM(price), 0) AS total, COUNT(*) AS count FROM boxlog WHERE date >= ? AND date < ?',
    [$date_day, $date_tomorrow]
);
$purchase_today = $purchase_today_q ? ($purchase_today_q->fetch(PDO::FETCH_ASSOC) ?: []) : [];
$purchase_today_total = (float) ($purchase_today['total'] ?? 0);
$purchase_today_count = (int) ($purchase_today['count'] ?? 0);

$topup_day_q = dd_q('SELECT COALESCE(SUM(amount), 0) AS total FROM topup_his WHERE date >= ? AND date < ?', [$date_day, $date_tomorrow]);
$topup_day = $topup_day_q ? ($topup_day_q->fetch(PDO::FETCH_ASSOC) ?: []) : [];
$topup_day_total = (float) ($topup_day['total'] ?? 0);

$topup_month_q = dd_q('SELECT COALESCE(SUM(amount), 0) AS total FROM topup_his WHERE date >= ?', [$date_month]);
$topup_month = $topup_month_q ? ($topup_month_q->fetch(PDO::FETCH_ASSOC) ?: []) : [];
$topup_month_total = (float) ($topup_month['total'] ?? 0);

$topup_all_q = dd_q('SELECT COALESCE(SUM(amount), 0) AS total, COUNT(*) AS count FROM topup_his');
$topup_all = $topup_all_q ? ($topup_all_q->fetch(PDO::FETCH_ASSOC) ?: []) : [];
$topup_all_total = (float) ($topup_all['total'] ?? 0);
$topup_all_count = (int) ($topup_all['count'] ?? 0);
?>

<div class="p-4 p-lg-5">
    <div class="mb-5">
        <h3 class="fw-bold mb-1"><i class="fa-solid fa-chart-pie text-xez-primary me-2"></i> แผงควบคุมระบบ (Dashboard)</h3>
        <p class="text-muted small">ภาพรวมสถิติการใช้งาน ยอดขาย และการเติมเงินของร้านค้า</p>
    </div>

    <!-- Key business metrics -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="stat-card h-100">
                <div class="d-flex align-items-center mb-3">
                    <div class="stat-icon me-3"><i class="fa-solid fa-calendar-days"></i></div>
                    <span class="text-muted small fw-bold">เปิดเว็บไซต์มาแล้ว</span>
                </div>
                <h2 class="fw-bold mb-1"><?= number_format($site_days) ?> วัน</h2>
                <small class="text-muted">นับจากวันที่เปิดเว็บไซต์</small>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card h-100">
                <div class="d-flex align-items-center mb-3">
                    <div class="stat-icon me-3"><i class="fa-solid fa-cart-shopping"></i></div>
                    <span class="text-muted small fw-bold">ยอดการซื้อสินค้าทั้งหมด</span>
                </div>
                <h2 class="fw-bold mb-1"><?= number_format($purchase_all_total, 2) ?>฿</h2>
                <small class="text-muted"><?= number_format($purchase_all_count) ?> รายการซื้อ</small>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card h-100">
                <div class="d-flex align-items-center mb-3">
                    <div class="stat-icon me-3"><i class="fa-solid fa-chart-line"></i></div>
                    <span class="text-muted small fw-bold">ยอดการซื้อสินค้าวันนี้</span>
                </div>
                <h2 class="fw-bold mb-1"><?= number_format($purchase_today_total, 2) ?>฿</h2>
                <small class="text-muted"><?= number_format($purchase_today_count) ?> รายการวันนี้</small>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="stat-card h-100">
                <div class="d-flex align-items-center mb-3">
                    <div class="stat-icon me-3"><i class="fa-solid fa-vault"></i></div>
                    <span class="text-muted small fw-bold">ยอดการเติมเงินทั้งหมด</span>
                </div>
                <h2 class="fw-bold mb-1"><?= number_format($topup_all_total, 2) ?>฿</h2>
                <small class="text-muted"><?= number_format($topup_all_count) ?> รายการเติมเงิน</small>
            </div>
        </div>
    </div>

    <!-- Additional top-up metrics -->
    <div class="row g-4 mb-5">
        <div class="col-lg-4 col-md-6">
            <div class="stat-card h-100">
                <div class="d-flex align-items-center mb-3">
                    <div class="stat-icon me-3"><i class="fa-solid fa-calendar-day"></i></div>
                    <span class="text-muted small fw-bold">ยอดเติมวันนี้</span>
                </div>
                <h2 class="fw-bold mb-0"><?= number_format($topup_day_total, 2) ?>฿</h2>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="stat-card h-100">
                <div class="d-flex align-items-center mb-3">
                    <div class="stat-icon me-3"><i class="fa-solid fa-calendar-check"></i></div>
                    <span class="text-muted small fw-bold">ยอดเติมเดือนนี้</span>
                </div>
                <h2 class="fw-bold mb-0"><?= number_format($topup_month_total, 2) ?>฿</h2>
            </div>
        </div>
        <div class="col-lg-4 col-md-6">
            <div class="stat-card h-100">
                <div class="d-flex align-items-center mb-3">
                    <div class="stat-icon me-3"><i class="fa-solid fa-receipt"></i></div>
                    <span class="text-muted small fw-bold">สถานะข้อมูลธุรกรรม</span>
                </div>
                <h2 class="fw-bold mb-0">อัปเดตสด</h2>
                <small class="text-muted">เวลา <?= date('H:i') ?> น.</small>
            </div>
        </div>
    </div>

    <!-- Recent top-up transactions -->
    <div class="xez-card p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h5 class="fw-bold mb-0"><i class="fa-solid fa-clock-rotate-left text-xez-primary me-2"></i>รายการเติมเงินล่าสุด</h5>
            <a href="?page=backend_topup_history" class="btn btn-light btn-sm rounded-pill px-3">ดูทั้งหมด</a>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th class="border-0 py-3 ps-3">ID</th>
                        <th class="border-0 py-3">ผู้ใช้งาน</th>
                        <th class="border-0 py-3">จำนวน</th>
                        <th class="border-0 py-3 pe-3 text-end">วันที่</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $recent_topup = dd_q('SELECT * FROM topup_his ORDER BY date DESC LIMIT 5');
                    $has_recent_topup = false;
                    if ($recent_topup):
                        while ($row = $recent_topup->fetch(PDO::FETCH_ASSOC)):
                            $has_recent_topup = true;
                            ?>
                            <tr class="align-middle">
                                <td class="py-3 ps-3 fw-bold">#<?= (int) $row['id'] ?></td>
                                <td class="py-3">
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary-soft rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px;">
                                            <i class="fa-solid fa-user text-xez-primary" style="font-size: 0.75rem;"></i>
                                        </div>
                                        <span class="fw-medium"><?= htmlspecialchars($row['uname'] ?? '', ENT_QUOTES, 'UTF-8') ?></span>
                                    </div>
                                </td>
                                <td class="py-3"><span class="text-success fw-bold">+ ฿<?= number_format((float) ($row['amount'] ?? 0), 2) ?></span></td>
                                <td class="py-3 pe-3 text-end text-muted small"><?= htmlspecialchars($row['date'] ?? '', ENT_QUOTES, 'UTF-8') ?></td>
                            </tr>
                        <?php endwhile;
                    endif;
                    if (!$has_recent_topup): ?>
                        <tr><td colspan="4" class="text-center text-muted py-4">ยังไม่มีรายการเติมเงิน</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
