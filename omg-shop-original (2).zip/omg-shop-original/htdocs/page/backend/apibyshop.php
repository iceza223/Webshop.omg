<div class="p-4 p-lg-5">
    <div class="mb-5">
        <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-link text-xdvz-primary me-2"></i> ตั้งค่าระบบ API
            Byshop</h3>
        <p class="text-muted small">config ข้อมูล API สำหรับดึงข้อมูลและจัดการสินค้าจาก Byshop</p>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">สถานะการทำงาน</label>
                <select class="form-select py-3 shadow-none border" id="st" style="border-radius: 12px;">
                    <option value="on" <?php if ($byshop_status == "on")
                        echo "selected"; ?>>เปิดใช้งาน (Enabled)</option>
                    <option value="off" <?php if ($byshop_status == "off")
                        echo "selected"; ?>>ปิดใช้งาน (Disabled)
                    </option>
                </select>
                <div class="form-text text-muted small mt-2">เปิดเพื่อพรีเมี่ยมสั่งซื้อสินค้าผ่าน API อัตโนมัติ</div>
            </div>

            <div class="mb-4">
                <label class="form-label text-dark fw-bold small">API Key (จาก Byshop.me)</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0" style="border-radius: 12px 0 0 12px;"><i
                            class="fa-solid fa-key text-muted"></i></span>
                    <input type="text" id="apikey" class="form-control border-start-0 py-3"
                        value="<?php echo $byshop_key; ?>" placeholder="ระบุ API Key ของคุณ"
                        style="border-radius: 0 12px 12px 0;">
                </div>
            </div>

            <div class="mb-5">
                <label class="form-label text-dark fw-bold small">ตั้งราคาบวกเพิ่ม (บาท)</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0" style="border-radius: 12px 0 0 12px;"><i
                            class="fa-solid fa-plus text-muted"></i></span>
                    <input type="number" id="cost" class="form-control border-start-0 py-3"
                        value="<?php echo $byshop_cost; ?>" placeholder="เช่น 5" style="border-radius: 0 12px 12px 0;">
                </div>
                <div class="form-text text-muted small mt-2">ราคาสินค้าที่จะนำไปบวกเพิ่มจากต้นทุน API</div>
            </div>

            <div class="row g-3">
                <div class="col-md-6">
                    <button class="btn xdvz-btn-cyan w-100 py-3 fw-bold" id="subm">
                        <i class="fa-solid fa-save me-2"></i> บันทึกข้อมูล
                    </button>
                </div>
                <div class="col-md-6">
                    <button class="btn btn-outline-dark w-100 py-3 fw-bold shadow-none" id="check"
                        style="border-radius: 15px;">
                        <i class="fa-solid fa-wallet me-2"></i> เช็คยอดเงิน Byshop
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $("#subm").click(function (e) {
        e.preventDefault();
        var formData = new FormData();
        formData.append('st', $("#st").val());
        formData.append('apikey', $("#apikey").val());
        formData.append('cost', $("#cost").val());

        Swal.fire({
            title: 'กำลังบันทึก...',
            didOpen: () => { Swal.showLoading() }
        });

        $.ajax({
            type: 'POST',
            url: 'system/backend/byshop_editinfo.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            Swal.fire({
                icon: 'success',
                title: 'สำเร็จ',
                text: res.message
            }).then(() => window.location.reload());
        }).fail(function (jqXHR) {
            Swal.fire({ icon: 'error', title: 'ผิดพลาด', text: 'เกิดข้อผิดพลาดในการบันทึก' });
        });
    });

    $("#check").click(function (e) {
        e.preventDefault();
        var formData = new FormData();
        formData.append('st', $("#st").val());

        Swal.fire({
            title: 'กำลังตรวจสอบยอดคงเหลือ...',
            didOpen: () => { Swal.showLoading() }
        });

        $.ajax({
            type: 'POST',
            url: 'system/byshop/checkmoney.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            Swal.fire({
                icon: 'success',
                title: 'ยอดคงเหลือ Byshop',
                text: res.message
            });
        }).fail(function (jqXHR) {
            Swal.fire({ icon: 'error', title: 'ผิดพลาด', text: 'ไม่สามารถเชื่อมต่อ API ได้' });
        });
    });
</script>