<div class="p-2">
    <div class="mb-4">
        <h4 class="fw-bold text-dark mb-1"><i class="fa-solid fa-coins text-xdvz-primary me-2"></i> ประวัติเติมเงินและคำขอบัตร
        </h4>
        <p class="text-muted small">รายการเติมเงินของคุณ รวมคำขอบัตรทรูมันนี่ที่รอแอดมินตรวจสอบ</p>
    </div>

    <div class="table-responsive">
        <table class="table table-hover border-0" id="table">
            <thead class="bg-light">
                <tr>
                    <th class="border-0 py-3 ps-4 text-muted small fw-bold">ช่องทาง / รายละเอียด</th>
                    <th class="border-0 py-3 text-muted small fw-bold">จำนวนเงิน</th>
                    <th class="border-0 py-3 text-muted small fw-bold">สถานะ</th>
                    <th class="border-0 py-3 pe-4 text-muted small fw-bold">วันที่ / เวลา</th>
                </tr>
            </thead>
            <tbody>
                <?php
                dd_q("CREATE TABLE IF NOT EXISTS truemoney_card_requests (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, username VARCHAR(255) NOT NULL, card_hash CHAR(64) NOT NULL, card_last4 CHAR(4) NOT NULL, card_encrypted TEXT NOT NULL, amount DECIMAL(10,2) NULL, status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending', admin_note VARCHAR(500) NOT NULL DEFAULT '', created_at DATETIME NOT NULL, reviewed_at DATETIME NULL, reviewed_by VARCHAR(255) NOT NULL DEFAULT '', INDEX(status), INDEX(card_hash), INDEX(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $card_requests = dd_q("SELECT id, card_last4, amount, status, admin_note, created_at FROM truemoney_card_requests WHERE user_id = ? ORDER BY created_at DESC", [$_SESSION['id']]);
                if ($card_requests) while ($card = $card_requests->fetch(PDO::FETCH_ASSOC)) {
                    $card_status = $card['status'] === 'pending' ? 'รอแอดมินตรวจสอบ' : ($card['status'] === 'approved' ? 'อนุมัติแล้ว' : 'ยกเลิก: ' . ($card['admin_note'] ?: 'บัตรไม่ถูกต้อง'));
                    $card_class = $card['status'] === 'pending' ? 'warning' : ($card['status'] === 'approved' ? 'success' : 'danger');
                    $card_date = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', (string)$card['created_at'], new DateTimeZone('Asia/Bangkok'));
                    $card_display_time = $card_date ? $card_date->format('d/m/Y H:i:s') : (string)$card['created_at'];
                    ?>
                    <tr class="align-middle border-bottom">
                        <td class="py-3 ps-4"><span class="badge bg-light-soft text-xdvz-primary px-3 py-2 rounded-3 small">บัตร TrueMoney ****<?= htmlspecialchars($card['card_last4']) ?></span></td>
                        <td class="py-3"><span class="<?= $card['status'] === 'approved' ? 'text-success' : 'text-muted' ?> fw-bold"><?= $card['amount'] !== null ? '+ ฿' . number_format((float)$card['amount'], 2) : 'รอตรวจสอบยอด' ?></span></td>
                        <td class="py-3" style="min-width:150px;"><span class="badge bg-<?= $card_class ?> w-100"><?= htmlspecialchars($card_status) ?></span></td>
                        <td class="py-3 pe-4 text-muted small"><?= htmlspecialchars($card_display_time, ENT_QUOTES, 'UTF-8') ?></td>
                    </tr>
                    <?php
                }
                dd_q("CREATE TABLE IF NOT EXISTS slip_requests (id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,username VARCHAR(255) NOT NULL,amount DECIMAL(10,2) NOT NULL,ref VARCHAR(255) NOT NULL,image_hash CHAR(64) NOT NULL,image_path VARCHAR(500) NOT NULL,status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',admin_note VARCHAR(500) NOT NULL DEFAULT '',created_at DATETIME NOT NULL,reviewed_at DATETIME NULL,reviewed_by VARCHAR(255) NOT NULL DEFAULT '',INDEX(status),INDEX(ref),INDEX(image_hash),INDEX(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $slip_requests = dd_q("SELECT amount, ref, status, admin_note, created_at FROM slip_requests WHERE user_id = ? ORDER BY created_at DESC", [$_SESSION['id']]);
                if ($slip_requests) while ($slip = $slip_requests->fetch(PDO::FETCH_ASSOC)) {
                    $slip_status = $slip['status'] === 'pending' ? 'รอแอดมินตรวจสอบ' : ($slip['status'] === 'approved' ? 'อนุมัติแล้ว' : 'ยกเลิก: ' . ($slip['admin_note'] ?: 'สลิปไม่ถูกต้อง'));
                    $slip_class = $slip['status'] === 'pending' ? 'warning' : ($slip['status'] === 'approved' ? 'success' : 'danger');
                    $slip_date = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', (string)$slip['created_at'], new DateTimeZone('Asia/Bangkok'));
                    $slip_display_time = $slip_date ? $slip_date->format('d/m/Y H:i:s') : (string)$slip['created_at'];
                    ?>
                    <tr class="align-middle border-bottom">
                        <td class="py-3 ps-4"><span class="badge bg-light-soft text-xdvz-primary px-3 py-2 rounded-3 small">สลิป Ref: <?= htmlspecialchars($slip['ref']) ?></span></td>
                        <td class="py-3"><span class="<?= $slip['status'] === 'approved' ? 'text-success' : 'text-muted' ?> fw-bold">฿<?= number_format((float)$slip['amount'], 2) ?></span></td>
                        <td class="py-3" style="min-width:150px;"><span class="badge bg-<?= $slip_class ?> w-100"><?= htmlspecialchars($slip_status) ?></span></td>
                        <td class="py-3 pe-4 text-muted small"><?= htmlspecialchars($slip_display_time, ENT_QUOTES, 'UTF-8') ?></td>
                    </tr>
                    <?php
                }
                $f = dd_q("SELECT * FROM topup_his WHERE uid = ? ORDER BY date DESC", [$_SESSION['id']]);
                while ($row = $f->fetch(PDO::FETCH_ASSOC)) {
                    $topup_time = (string)($row['date'] ?? '');
                    $topup_date = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $topup_time, new DateTimeZone('Asia/Bangkok'));
                    $topup_display_time = $topup_date
                        ? $topup_date->setTimezone(new DateTimeZone('Asia/Bangkok'))->format('d/m/Y H:i:s')
                        : $topup_time;
                    $status = $row['status'] ?? 'success'; // Default for old data
                    $statusBadge = $status == 'success'
                        ? '<span class="badge bg-success w-100">สำเร็จ</span>'
                        : '<span class="badge bg-danger w-100">ไม่สำเร็จ</span>';
                    $note = $row['note'] ? '<div class="text-danger x-small mt-1">(' . htmlspecialchars($row['note']) . ')</div>' : '';
                    ?>
                    <tr class="align-middle border-bottom">
                        <td class="py-3 ps-4">
                            <span class="badge bg-light-soft text-xdvz-primary px-3 py-2 rounded-3 small">
                                <?= htmlspecialchars($row['link'] ?? 'เติมเงิน') ?>
                            </span>
                        </td>
                        <td class="py-3">
                            <span class="<?= $status == 'success' ? 'text-success' : 'text-muted' ?> fw-bold">
                                + ฿<?= number_format($row['amount'], 2) ?>
                            </span>
                        </td>
                        <td class="py-3" style="min-width: 100px;">
                            <?= $statusBadge ?>
                            <?= $status != 'success' ? $note : '' ?>
                        </td>
                        <td class="py-3 pe-4 text-muted small"><?= htmlspecialchars($topup_display_time, ENT_QUOTES, 'UTF-8') ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('#table').DataTable({
            "language": { "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Thai.json" },
            "pageLength": 10,
            "order": [[3, "desc"]]
        });
    });
</script>
