<?php
// Product Detail Page
if (!isset($_GET['id'])) {
    echo "<script>window.location.href = '?page=shop';</script>";
    exit;
}

$product_id = intval($_GET['id']);

// Get product - simpler query first
$product_result = dd_q("SELECT * FROM box_product WHERE id = ?", [$product_id]);

if (!$product_result || $product_result->rowCount() == 0) {
    echo "<script>alert('ไม่พบสินค้านี้'); window.location.href = '?page=shop';</script>";
    exit;
}

$product = $product_result->fetch(PDO::FETCH_ASSOC);

// Get category name separately
$category_name = '';
if (!empty($product['c_id'])) {
    $cat_result = dd_q("SELECT * FROM category WHERE id = ?", [$product['c_id']]);
    if ($cat_result && $cat_result->rowCount() > 0) {
        $cat = $cat_result->fetch(PDO::FETCH_ASSOC);
        $category_name = $cat['c_name'] ?? $cat['name'] ?? '';
    }
}

// Get stock count
$stock_result = dd_q("SELECT COUNT(*) as cnt FROM box_stock WHERE p_id = ?", [$product_id]);
$stock = $stock_result ? $stock_result->fetch(PDO::FETCH_ASSOC)['cnt'] : 0;
?>

<!-- Breadcrumb -->
<div class="container-sm py-3">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-0 small">
            <li class="breadcrumb-item"><a href="?page=shop" class="text-decoration-none">สินค้าทั้งหมด</a></li>
            <?php if (!empty($category_name)): ?>
                <li class="breadcrumb-item"><a href="?page=shop&category=<?= urlencode($product['c_type'] ?? '') ?>"
                        class="text-decoration-none">
                        <?= htmlspecialchars($category_name) ?>
                    </a></li>
            <?php endif; ?>
            <li class="breadcrumb-item active" aria-current="page">
                <?= htmlspecialchars($product['name']) ?>
            </li>
        </ol>
    </nav>
</div>

<!-- Product Detail Section -->
<div class="container-sm pb-5">
    <div class="product-detail-card">
        <div class="row g-4">
            <!-- Product Image -->
            <div class="col-lg-5">
                <div class="product-image-wrapper">
                    <img src="<?= htmlspecialchars($product['img'] ?? '') ?>"
                        alt="<?= htmlspecialchars($product['name']) ?>" class="product-main-image">
                    <?php if ($stock <= 5 && $stock > 0): ?>
                        <span class="product-badge badge-warning">เหลือน้อย</span>
                    <?php elseif ($stock == 0): ?>
                        <span class="product-badge badge-danger">สินค้าหมด</span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Product Info -->
            <div class="col-lg-7">
                <div class="product-info">
                    <h1 class="product-title">
                        <?= htmlspecialchars($product['name']) ?>
                    </h1>

                    <div class="product-description">
                        <h6 class="fw-bold mb-3">รายละเอียดสินค้า</h6>
                        <div class="description-content">
                            <?= nl2br(htmlspecialchars($product['des'] ?? 'ไม่มีรายละเอียด')) ?>
                        </div>
                    </div>

                    <div class="product-price-box">
                        <span class="product-price">
                            <?= number_format($product['price']) ?> ฿
                        </span>
                        <?php if ($product['price'] < 100): ?>
                            <span class="badge bg-danger ms-2">HOT DEAL</span>
                        <?php endif; ?>
                    </div>

                    <div class="product-stock-info">
                        <?php if ($stock > 0): ?><span class="badge rounded-pill bg-success-subtle text-success px-3 py-2"><i class="fa-solid fa-box me-1"></i>คงเหลือ <?= number_format($stock) ?> ชิ้น</span><?php else: ?><span class="badge rounded-pill bg-danger-subtle text-danger px-3 py-2"><i class="fa-solid fa-circle-xmark me-1"></i>สินค้าหมด</span><?php endif; ?>
                        <span class="mx-2">|</span>
                        <span class="text-muted">ราคาสินค้า
                            <?= number_format($product['price']) ?> บาท / ชิ้น
                        </span>
                    </div>

                    <?php if ($stock > 0): ?>
                        <!-- กำหนดซื้อครั้งละ 1 ชิ้น และซ่อนตัวควบคุมจำนวน -->
                        <input type="hidden" id="qty-input" value="1">

                        <!-- Discount Code Input -->
                        <div class="discount-code-box mb-3">
                            <label class="form-label small fw-bold">
                                <i class="fa-solid fa-tag text-xez-primary me-1"></i> โค้ดส่วนลด
                            </label>
                            <div class="input-group">
                                <input type="text" id="discount-code" class="form-control" placeholder="ใส่โค้ดส่วนลด">
                                <button class="btn xez-btn-outline" type="button" onclick="applyDiscount()">
                                    ใช้โค้ด
                                </button>
                            </div>
                            <div id="discount-result" class="mt-2 small"></div>
                        </div>

                        <div class="product-actions">
                            <button class="btn product-buy-btn" onclick="buyProduct()">
                                <i class="fa-solid fa-shopping-cart me-2"></i>สั่งซื้อเลย
                            </button>
                            <button class="btn product-action-btn" onclick="copyProductLink()">
                                <i class="fa-solid fa-code"></i>
                            </button>
                            <button class="btn product-action-btn" onclick="shareProduct()">
                                <i class="fa-solid fa-share-nodes"></i>
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-danger mt-4">
                            <i class="fa-solid fa-exclamation-circle me-2"></i>สินค้าหมดชั่วคราว กรุณาติดต่อแอดมิน
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Product Detail Styles */
    .product-detail-card {
        background: var(--bg-card);
        border-radius: 20px;
        padding: 30px;
        border: 1px solid var(--border-color);
    }

    .product-image-wrapper {
        position: relative;
        border-radius: 16px;
        overflow: hidden;
        background: linear-gradient(135deg, rgba(var(--xez-primary-rgb), 0.1) 0%, rgba(var(--xez-primary-rgb), 0.05) 100%);
        border: 3px solid var(--xez-primary);
        padding: 20px;
    }

    .product-main-image {
        width: 100%;
        height: auto;
        border-radius: 12px;
        display: block;
    }

    .product-badge {
        position: absolute;
        top: 15px;
        right: 15px;
        padding: 8px 16px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 0.8rem;
    }

    .badge-warning {
        background: #f59e0b;
        color: #fff;
    }

    .badge-danger {
        background: #ef4444;
        color: #fff;
    }

    .product-info {
        padding: 10px 0;
    }

    .product-title {
        font-size: 1.8rem;
        font-weight: 800;
        margin-bottom: 20px;
        color: var(--text-primary);
    }

    .product-description {
        background: var(--bg-secondary);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 20px;
        max-height: 250px;
        overflow-y: auto;
    }

    .description-content {
        color: var(--text-secondary);
        font-size: 0.9rem;
        line-height: 1.8;
    }

    .product-price-box {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
    }

    .product-price {
        font-size: 1.5rem;
        font-weight: 800;
        color: var(--xez-primary);
    }

    .product-stock-info {
        color: var(--text-muted);
        font-size: 0.9rem;
        margin-bottom: 20px;
    }

    .product-quantity {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 20px;
    }

    .qty-btn {
        width: 45px;
        height: 45px;
        border: 1px solid var(--border-color);
        background: var(--bg-secondary);
        color: var(--text-primary);
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .qty-btn:hover {
        background: var(--xez-primary);
        color: #fff;
        border-color: var(--xez-primary);
    }

    .qty-input {
        width: 80px;
        height: 45px;
        text-align: center;
        border: 1px solid var(--border-color);
        background: var(--bg-secondary);
        color: var(--text-primary);
        border-radius: 10px;
        font-weight: 600;
        font-size: 1.1rem;
    }

    .product-actions {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .product-buy-btn {
        flex: 1;
        background: linear-gradient(135deg, var(--xez-primary) 0%, var(--xez-secondary) 100%);
        color: #fff;
        padding: 15px 30px;
        font-weight: 600;
        border-radius: 12px;
        font-size: 1rem;
        transition: all 0.3s ease;
    }

            .product-buy-btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(var(--xez-primary-rgb), 0.4);
        color: #fff;
    }

    /* Purchase confirmation modal: force readable contrast on light SweetAlert panels. */
    .xez-purchase-confirm-popup {
        color: #0f172a !important;
        background: #ffffff !important;
    }

    .xez-purchase-confirm-popup .swal2-title,
    .xez-purchase-confirm-popup .swal2-html-container,
    .xez-purchase-confirm-popup .swal2-html-container p,
    .xez-purchase-confirm-popup .swal2-html-container strong {
        color: #0f172a !important;
        opacity: 1 !important;
    }

    .xez-purchase-confirm-popup .swal2-html-container {
        font-size: 1rem !important;
        line-height: 1.8 !important;
    }

    .xez-purchase-confirm-popup .swal2-html-container p {
        margin: 0.45rem 0 !important;
    }

    .xez-purchase-confirm-popup .swal2-html-container .text-success {
        color: #15803d !important;
    }

    .xez-purchase-confirm-popup .xez-confirm-button {
        color: #ffffff !important;
        background: #ffb300 !important;
        font-weight: 700 !important;
    }

    .xez-purchase-confirm-popup .xez-cancel-button {
        color: #ffffff !important;
        background: #64748b !important;
        font-weight: 700 !important;
    }

    .product-action-btn {

        width: 50px;
        height: 50px;
        border: 1px solid var(--border-color);
        background: var(--bg-secondary);
        color: var(--text-primary);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
    }

    .product-action-btn:hover {
        background: var(--xez-primary);
        color: #fff;
        border-color: var(--xez-primary);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .product-detail-card {
            padding: 20px;
        }

        .product-title {
            font-size: 1.4rem;
        }

        .product-buy-btn {
            width: 100%;
            flex: none;
        }
    }
</style>

<script>
    const maxStock = <?= $stock ?>;
    const productId = <?= $product_id ?>;
    const productName = "<?= htmlspecialchars(addslashes($product['name'])) ?>";
    const productPrice = <?= $product['price'] ?>;

    // Discount variables
    let appliedDiscount = null;
    let discountAmount = 0;

    function changeQty(delta) {
        // ล็อกจำนวนไว้ที่ 1 แม้มีสคริปต์อื่นพยายามเปลี่ยนค่า
        const input = document.getElementById('qty-input');
        if (input) input.value = 1;

        // Re-validate discount if applied
        if (appliedDiscount) {
            applyDiscount();
        }
    }

    function applyDiscount() {
        const code = document.getElementById('discount-code').value.trim();
        const qty = parseInt(document.getElementById('qty-input').value);
        const total = productPrice * qty;

        if (!code) {
            $('#discount-result').html('<span class="text-danger"><i class="fa-solid fa-times-circle me-1"></i>กรุณากรอกโค้ดส่วนลด</span>');
            return;
        }

        $.ajax({
            type: 'POST',
            url: 'system/backend/discount_validate.php',
            data: { code: code, total: total },
            dataType: 'json'
        }).done(function (res) {
            if (res.status === 'success') {
                appliedDiscount = res.discount_id;
                discountAmount = res.discount_amount;
                $('#discount-result').html(`
                    <span class="text-success">
                        <i class="fa-solid fa-check-circle me-1"></i>
                        ใช้โค้ดสำเร็จ! ลด ${res.discount_text} (-฿${res.discount_amount.toLocaleString()})
                    </span>
                `);
            } else {
                appliedDiscount = null;
                discountAmount = 0;
                $('#discount-result').html(`<span class="text-danger"><i class="fa-solid fa-times-circle me-1"></i>${res.message}</span>`);
            }
        }).fail(function () {
            $('#discount-result').html('<span class="text-danger"><i class="fa-solid fa-times-circle me-1"></i>เกิดข้อผิดพลาด</span>');
        });
    }

    function buyProduct() {
        // บังคับจำนวนซื้อฝั่งหน้าเว็บให้เป็น 1 เสมอ
        const qty = 1;
        const qtyInput = document.getElementById('qty-input');
        if (qtyInput) qtyInput.value = 1;

        <?php if (!isset($_SESSION['id'])): ?>
            Swal.fire({
                icon: 'warning',
                title: 'กรุณาเข้าสู่ระบบ',
                text: 'คุณต้องเข้าสู่ระบบก่อนจึงจะสามารถซื้อสินค้าได้',
                confirmButtonText: 'เข้าสู่ระบบ',
                showCancelButton: true,
                cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '?page=login';
                }
            });
            return;
        <?php endif; ?>

            const totalPrice = productPrice * qty;
            const finalPrice = Math.max(0, totalPrice - discountAmount);
            const discountLine = discountAmount > 0
                ? `<p class="text-success"><strong>ส่วนลด:</strong> -${discountAmount.toLocaleString()} บาท</p>`
                : '';

        Swal.fire({
            title: 'ยืนยันการสั่งซื้อ',
            html: `
            <div class="text-start">
                <p><strong>สินค้า:</strong> ${productName}</p>
                <p><strong>จำนวน:</strong> ${qty} ชิ้น</p>
                <p><strong>ราคารวม:</strong> ${totalPrice.toLocaleString()} บาท</p>
                ${discountLine}
                <p><strong>ยอดชำระสุทธิ:</strong> ${finalPrice.toLocaleString()} บาท</p>
            </div>
        `,
                        icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'ยืนยันซื้อ',
            cancelButtonText: 'ยกเลิก',
            confirmButtonColor: '#ffb300',
            cancelButtonColor: '#64748b',
            customClass: {
                popup: 'xez-purchase-confirm-popup',
                confirmButton: 'xez-confirm-button',
                cancelButton: 'xez-cancel-button'
            }

        }).then((result) => {
            if (result.isConfirmed) {
                // Send purchase request
                $.ajax({
                    type: 'POST',
                    url: 'system/buybox.php',
                    data: {
                        id: productId,
                        count: qty,
                        discount_code: $('#discount-code').val().trim()
                    },
                    dataType: 'json'
                }).done(function (res) {
                    if (res.salt === 'prize') {
                        Swal.fire({
                            icon: 'success',
                            title: 'สำเร็จ!',
                            html: res.message,
                            confirmButtonText: 'ตกลง'
                        }).then(() => {
                            window.location.href = '?page=profile&subpage=buyhis';
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'ผิดพลาด',
                            text: res.message
                        });
                    }
                }).fail(function (xhr) {
                    try {
                        const res = JSON.parse(xhr.responseText);
                        Swal.fire({
                            icon: 'error',
                            title: 'ผิดพลาด',
                            text: res.message || 'เกิดข้อผิดพลาดในการเชื่อมต่อ'
                        });
                    } catch (e) {
                        Swal.fire({
                            icon: 'error',
                            title: 'ผิดพลาด',
                            text: 'เกิดข้อผิดพลาดในการเชื่อมต่อ'
                        });
                    }
                });
            }
        });
    }

    function copyProductLink() {
        navigator.clipboard.writeText(window.location.href);
        Swal.fire({
            icon: 'success',
            title: 'คัดลอกลิงก์แล้ว!',
            toast: true,
            position: 'top-end',
            timer: 2000,
            showConfirmButton: false
        });
    }

    function shareProduct() {
        if (navigator.share) {
            navigator.share({
                title: productName,
                url: window.location.href
            });
        } else {
            copyProductLink();
        }
    }
</script>

<style id="product-buy-red-theme">
.product-buy-btn{background:linear-gradient(135deg,#ef4444,#b91c1c)!important;border:1px solid #f87171!important;color:#fff!important;box-shadow:0 8px 20px rgba(239,68,68,.28)!important}.product-buy-btn:hover{background:linear-gradient(135deg,#f87171,#dc2626)!important;border-color:#fecaca!important;color:#fff!important;box-shadow:0 12px 28px rgba(239,68,68,.45)!important}.xez-purchase-confirm-popup .xez-confirm-button{background:linear-gradient(135deg,#ef4444,#b91c1c)!important;border:1px solid #f87171!important;color:#fff!important}.xez-purchase-confirm-popup .xez-confirm-button:hover{background:#dc2626!important}
</style>
