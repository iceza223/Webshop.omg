<?php
if (!isset($_SESSION['id'])) {
    echo '<div class="container-sm mt-5"><div class="alert alert-warning text-center">กรุณาสมัครสมาชิกหรือเข้าสู่ระบบก่อนดาวน์โหลด</div><div class="text-center"><a class="btn xez-btn-primary" href="?page=register">สมัครสมาชิก</a> <a class="btn btn-outline-secondary" href="?page=login">เข้าสู่ระบบ</a></div></div>';
    return;
}

$vip_apps = [
    ['version' => 'V4', 'label' => 'THLIVE-OMGMOD V4', 'description' => 'เวอร์ชันล่าสุด พร้อมใช้งานสำหรับ Android', 'url' => 'https://www.mediafire.com/file/f8gotso3x3quef9/THLIVE-OMGMOD-4.apk/file', 'latest' => true],
    ['version' => 'V3', 'label' => 'THLIVE-OMGMOD V3', 'description' => 'ดาวน์โหลดแอป VIP เวอร์ชัน V3', 'url' => 'https://www.mediafire.com/file/w4j5ba8v6ktlhwc/THLIVE-OMGMOD-V3.apk/file', 'latest' => false],
    ['version' => 'V2', 'label' => 'THLIVE-OMGMOD V2', 'description' => 'ดาวน์โหลดแอป VIP เวอร์ชัน V2', 'url' => 'https://www.mediafire.com/file/3v1huvt532nr8rb/THLIVE-OMGMOD-V2.apk/file', 'latest' => false],
    ['version' => 'FREE', 'label' => 'DOWNLOAD APKMOD', 'description' => 'ดาวน์โหลดและดูรายละเอียดเวอร์ชัน APK', 'url' => 'view/apkmodfree.php', 'button_label' => 'Download (THLIVE-MOD-FREE)', 'latest' => false],
];
?>
<style>
.vip-download-page{max-width:760px;margin:0 auto;padding:28px 14px 48px}.vip-download-hero{position:relative;overflow:hidden;padding:28px 20px 24px;margin-bottom:18px;border:1px solid rgba(255,179,0,.45);border-radius:24px;background:radial-gradient(circle at 85% 0%,rgba(255,109,0,.2),transparent 42%),linear-gradient(145deg,#21130b,#0b090b 70%);box-shadow:0 14px 38px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.06);text-align:center}.vip-download-hero:after{content:"";position:absolute;width:150px;height:150px;right:-65px;top:-70px;border:1px solid rgba(255,179,0,.25);border-radius:50%;box-shadow:0 0 0 18px rgba(255,179,0,.04),0 0 0 36px rgba(255,179,0,.03)}.vip-download-icon{display:inline-grid;place-items:center;width:64px;height:64px;border-radius:20px;color:#211000;background:linear-gradient(145deg,#ffe082,#ff9800);box-shadow:0 8px 22px rgba(255,152,0,.28);font-size:30px}.vip-download-title{position:relative;z-index:1;margin:15px 0 6px;color:#fff8e6;font-size:clamp(25px,6vw,38px);font-weight:800}.vip-download-subtitle{position:relative;z-index:1;margin:0;color:#d8c9b4;font-size:14px}.vip-download-card{position:relative;margin:14px 0;padding:22px 16px 16px;border:1px solid rgba(255,179,0,.35);border-radius:22px;background:linear-gradient(145deg,rgba(35,22,18,.98),rgba(17,12,15,.98));box-shadow:0 10px 28px rgba(0,0,0,.22);text-align:center}.vip-download-card.latest{border-color:#ffb300;box-shadow:0 0 0 1px rgba(255,179,0,.15),0 12px 32px rgba(255,136,0,.13)}.vip-latest-badge{position:absolute;top:14px;right:14px;padding:5px 10px;border-radius:999px;color:#281500;background:#ffca28;font-size:11px;font-weight:800}.vip-version-icon{display:inline-grid;place-items:center;width:56px;height:56px;border:1px solid rgba(255,202,40,.55);border-radius:18px;color:#ffc107;background:rgba(255,179,0,.08);font-size:25px}.vip-download-card h3{margin:13px 0 5px;color:#fff8e6;font-size:21px;font-weight:800}.vip-download-card p{min-height:22px;margin:0 0 16px;color:#cdbda8;font-size:13px}.vip-download-button{display:flex;align-items:center;justify-content:center;min-height:56px;width:100%;border:0;border-radius:14px;color:#241300!important;background:linear-gradient(110deg,#ffd54f,#ffb300 52%,#ff7b00);box-shadow:0 8px 20px rgba(255,152,0,.25);font-size:16px;font-weight:800;text-decoration:none;transition:transform .15s ease,filter .15s ease}.vip-download-button:hover,.vip-download-button:focus-visible{color:#241300!important;filter:brightness(1.08);transform:translateY(-1px)}.vip-download-button:active{transform:scale(.98)}.vip-download-note{margin:20px 0 0;color:#a99a8c;font-size:12px;text-align:center}@media(min-width:700px){.vip-download-page{padding-top:42px}.vip-download-card{padding:26px 24px 20px}}
</style>
<main class="vip-download-page">
    <section class="vip-download-hero" aria-labelledby="vip-download-heading">
        <div class="vip-download-icon" aria-hidden="true"><i class="fa-solid fa-mobile-screen-button"></i></div>
        <h1 id="vip-download-heading" class="vip-download-title">ดาวน์โหลดแอป VIP</h1>
        <p class="vip-download-subtitle">เลือกเวอร์ชันที่ต้องการดาวน์โหลดสำหรับ Android</p>
    </section>
    <?php foreach ($vip_apps as $app): ?>
        <article class="vip-download-card<?= $app['latest'] ? ' latest' : '' ?>">
            <?php if ($app['latest']): ?><span class="vip-latest-badge">เวอร์ชันล่าสุด</span><?php endif; ?>
            <div class="vip-version-icon" aria-hidden="true"><i class="fa-solid fa-download"></i></div>
            <h3><?= htmlspecialchars($app['label'], ENT_QUOTES, 'UTF-8') ?></h3>
            <p><?= htmlspecialchars($app['description'], ENT_QUOTES, 'UTF-8') ?></p>
            <a class="vip-download-button" href="<?= htmlspecialchars($app['url'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer"><i class="fa-solid fa-download me-2" aria-hidden="true"></i><?= htmlspecialchars($app['button_label'] ?? ('ดาวน์โหลด ' . $app['version']), ENT_QUOTES, 'UTF-8') ?></a>
        </article>
    <?php endforeach; ?>
    <p class="vip-download-note"><i class="fa-brands fa-android me-1"></i>รองรับอุปกรณ์ Android • ระบบจะเปิดหน้า MediaFire ในแท็บใหม่</p>
</main>
