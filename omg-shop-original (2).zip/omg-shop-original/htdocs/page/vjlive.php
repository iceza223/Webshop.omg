<?php
// VJ Live page: display the THLive application inside the main website.
$vj_live_url = 'https://vjthliveomgvip.fwh.is/';
?>
<div class="container-sm py-3 py-md-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <div>
            <h2 class="fw-bold mb-1"><i class="fa-solid fa-video text-danger me-2"></i>VJ ที่กำลังไลฟ์</h2>
            <p class="text-muted mb-0">รับชม VJ ที่กำลังไลฟ์ได้ภายในเว็บไซต์</p>
        </div>
        <a class="btn xez-btn-outline" href="<?= htmlspecialchars($vj_live_url, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener">
            <i class="fa-solid fa-up-right-from-square me-1"></i>เปิดเต็มหน้าจอ
        </a>
    </div>
    <div class="xez-card overflow-hidden" style="background:#071323; border:1px solid rgba(255,255,255,.12);">
        <iframe
            src="<?= htmlspecialchars($vj_live_url, ENT_QUOTES, 'UTF-8') ?>"
            title="VJ ที่กำลังไลฟ์"
            loading="eager"
            allow="fullscreen"
            referrerpolicy="strict-origin-when-cross-origin"
            style="display:block;width:100%;height:min(78vh,900px);min-height:620px;border:0;background:#071323;"
        ></iframe>
    </div>
</div>
