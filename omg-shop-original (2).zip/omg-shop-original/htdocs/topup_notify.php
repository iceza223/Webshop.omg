<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/discord_webhook.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Allow: POST');
    jsonResponse(405, ['ok' => false, 'error' => 'POST required']);
}

$providedKey = (string)($_SERVER['HTTP_X_NOTIFY_KEY'] ?? '');
if (NOTIFY_API_KEY === '' || $providedKey === '' || !hash_equals(NOTIFY_API_KEY, $providedKey)) {
    jsonResponse(401, ['ok' => false, 'error' => 'Unauthorized']);
}

try {
    $data = requestData();
    $username = cleanText($data['username'] ?? '', 100);
    $amountRaw = $data['amount'] ?? null;
    $amount = filter_var($amountRaw, FILTER_VALIDATE_FLOAT);

    if ($username === '' || $amount === false || $amount < 0 || $amount > 100000000) {
        jsonResponse(422, ['ok' => false, 'error' => 'กรุณาระบุชื่อผู้ใช้และจำนวนเงินให้ถูกต้อง']);
    }

    $amountText = number_format((float)$amount, 2) . ' บาท';
    $webhook = new DiscordWebhook(DISCORD_WEBHOOK_URL, 'ระบบแจ้งเตือนการเติมเงิน');
    $webhook->sendEmbed(
        'มีการเติมเงินเข้าเว็บไซต์',
        'ระบบได้รับข้อมูลการเติมเงินรายการใหม่',
        [
            ['name' => 'ชื่อผู้ใช้', 'value' => $username, 'inline' => true],
            ['name' => 'จำนวนเงิน', 'value' => $amountText, 'inline' => true],
            ['name' => 'เว็บไซต์', 'value' => 'omgvip.shop', 'inline' => true],
        ],
        5763719
    );

    jsonResponse(200, ['ok' => true, 'message' => 'ส่งแจ้งเตือนการเติมเงินแล้ว']);
} catch (Throwable $e) {
    error_log('[topup-notify] ' . $e->getMessage());
    jsonResponse(502, ['ok' => false, 'error' => 'ส่งการแจ้งเตือนไม่สำเร็จ']);
}
