<?php
// Admin PIN hash. The plaintext PIN is intentionally not stored on the server.
$admin_pin_hash = '791dbc9c43d764790ca3172d94b3a6d7f8192a028ff3b648d28b77d9799c9e0d';
