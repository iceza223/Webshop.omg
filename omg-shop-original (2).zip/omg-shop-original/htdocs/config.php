<?php
declare(strict_types=1);

// ใส่ Discord Webhook URL ใหม่ที่สร้างด้วย Regenerate URL
const DISCORD_WEBHOOK_URL = 'https://discord.com/api/webhooks/REPLACE_WITH_NEW_ID/REPLACE_WITH_NEW_TOKEN';

// ค่านี้เป็นคีย์ลับสำหรับเรียก topup_notify.php
const NOTIFY_API_KEY = 'a0e2d2390866acf186ecc0d88023bcaf4c699ce0ab880523b83e7051b5c8bc39';
