<?php
require_once __DIR__ . '/system/a_func.php';
header('Content-Type: application/json; charset=utf-8');

function chat_json($ok, $message = '', $extra = [])
{
    if (!headers_sent()) { http_response_code($ok ? 200 : (isset($extra['login_required']) ? 401 : 400)); }
    echo json_encode(array_merge(['ok' => (bool)$ok, 'message' => (string)$message], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}
if (!isset($_SESSION['id']) || !is_numeric($_SESSION['id'])) {
    http_response_code(401); chat_json(false, 'กรุณาเข้าสู่ระบบก่อนใช้งานแชท', ['login_required' => true]);
}
try {
    if (($config['chat_status'] ?? 'on') !== 'on') {
        chat_json(false, 'ขณะนี้ระบบแชทปิดให้บริการ', ['chat_disabled' => true]);
    }
    $conn->exec("CREATE TABLE IF NOT EXISTS admin_chat_messages (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        sender ENUM('user','admin') NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_chat_user_created (user_id, created_at),
        INDEX idx_chat_sender (sender)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    try { $conn->exec("ALTER TABLE admin_chat_messages ADD COLUMN admin_read_at TIMESTAMP NULL DEFAULT NULL, ADD COLUMN user_read_at TIMESTAMP NULL DEFAULT NULL"); } catch (Throwable $migrationError) {}
    $userId = (int)$_SESSION['id'];
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $markRead = $conn->prepare("UPDATE admin_chat_messages SET user_read_at=NOW() WHERE user_id=? AND sender='admin' AND user_read_at IS NULL");
        $markRead->execute([$userId]);
        $stmt = $conn->prepare('SELECT id, sender, message, created_at FROM admin_chat_messages WHERE user_id=? ORDER BY id ASC LIMIT 200');
        $stmt->execute([$userId]); chat_json(true, '', ['messages' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); chat_json(false, 'Method ไม่ได้รับอนุญาต'); }
    $message = trim((string)($_POST['message'] ?? ''));
    if ($message === '' || mb_strlen($message) > 3000) chat_json(false, 'กรุณาพิมพ์ข้อความไม่เกิน 3,000 ตัวอักษร');
    $last = $conn->prepare("SELECT created_at FROM admin_chat_messages WHERE user_id=? AND sender='user' ORDER BY id DESC LIMIT 1");
    $last->execute([$userId]); $lastAt = $last->fetchColumn();
    if ($lastAt && time() - strtotime((string)$lastAt) < 3) chat_json(false, 'กรุณารอสักครู่ก่อนส่งข้อความอีกครั้ง');
    $stmt = $conn->prepare("INSERT INTO admin_chat_messages (user_id, sender, message) VALUES (?, 'user', ?)");
    $stmt->execute([$userId, $message]); chat_json(true, 'ส่งข้อความแล้ว');
} catch (Exception $e) { http_response_code(500); chat_json(false, 'ระบบแชทขัดข้องชั่วคราว กรุณาลองใหม่อีกครั้ง'); }
