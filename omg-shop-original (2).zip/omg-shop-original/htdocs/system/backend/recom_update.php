<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../a_func.php';

function dd_return($status, $message)
{
    $json = ['message' => $message];
    if ($status) {
        http_response_code(200);
        die(json_encode($json, JSON_UNESCAPED_UNICODE));
    }

    http_response_code(400);
    die(json_encode($json, JSON_UNESCAPED_UNICODE));
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dd_return(false, "Method '{$_SERVER['REQUEST_METHOD']}' not allowed!");
}

if (!isset($_SESSION['id'])) {
    dd_return(false, 'เข้าสู่ระบบก่อน');
}

$q_user = dd_q('SELECT * FROM users WHERE id = ? AND rank = 1 LIMIT 1', [(int) $_SESSION['id']]);
if (!$q_user || $q_user->rowCount() < 1) {
    session_destroy();
    dd_return(false, 'เซสชั่นผิดพลาด โปรดล็อกอินใหม่');
}

$recommendations = [];
for ($i = 1; $i <= 10; $i++) {
    $key = 'pop_' . $i;
    $recommendations[$i] = isset($_POST[$key]) ? max(0, (int) $_POST[$key]) : 0;
}

$enabled = isset($_POST['recom_enabled']) && (string) $_POST['recom_enabled'] === '1';

$check = dd_q('SELECT COUNT(*) AS total FROM recom');
$existing = $check ? (int) ($check->fetch(PDO::FETCH_ASSOC)['total'] ?? 0) : 0;

if ($existing > 0) {
    $update = dd_q(
        'UPDATE recom SET recom_1 = ?, recom_2 = ?, recom_3 = ?, recom_4 = ?, recom_5 = ?, recom_6 = ?, recom_7 = ?, recom_8 = ?, recom_9 = ?, recom_10 = ? LIMIT 1',
        array_values($recommendations)
    );
} else {
    $update = dd_q(
        'INSERT INTO recom (recom_1, recom_2, recom_3, recom_4, recom_5, recom_6, recom_7, recom_8, recom_9, recom_10) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        array_values($recommendations)
    );
}

if (!$update) {
    dd_return(false, 'SQL ผิดพลาด ไม่สามารถบันทึกสินค้าแนะนำได้');
}

// Keep the toggle separate from the recommendation slots so turning the section off does not delete selections.
$flag_dir = dirname(__DIR__, 2) . '/system/sessions';
$flag_file = $flag_dir . '/recom_enabled.flag';
$flag_value = $enabled ? '1' : '0';
if (!is_dir($flag_dir) || @file_put_contents($flag_file, $flag_value, LOCK_EX) === false) {
    dd_return(false, 'บันทึกสินค้าแล้ว แต่ไม่สามารถบันทึกสถานะเปิด/ปิดได้');
}

$status_text = $enabled ? 'เปิดการแสดงสินค้าแนะนำแล้ว' : 'ปิดการแสดงสินค้าแนะนำแล้ว';
dd_return(true, "บันทึกสำเร็จ: {$status_text}");
?>
