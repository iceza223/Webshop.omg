<?php
header('Content-Type: application/json');
require_once '../../system/a_func.php';
// Keep the endpoint usable when the popup migration has not been executed yet.
dd_q("CREATE TABLE IF NOT EXISTS popup_announcements (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255) NOT NULL, content TEXT NULL, image_url VARCHAR(500) NULL, button_text VARCHAR(100) NOT NULL DEFAULT 'ถัดไป', button_link VARCHAR(500) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, show_order INT NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

if (!isset($_SESSION['id']) || $user['rank'] != '1') {
    echo json_encode(['status' => 'error', 'message' => 'ไม่มีสิทธิ์เข้าถึง']);
    exit;
}

$title = trim($_POST['title'] ?? '');
$content = trim($_POST['content'] ?? '');
$image = trim($_POST['image'] ?? '');
$button_text = trim($_POST['button_text'] ?? 'ถัดไป');
$button_link = trim($_POST['button_link'] ?? '');
$active = intval($_POST['active'] ?? 1);

if (empty($title)) {
    echo json_encode(['status' => 'error', 'message' => 'กรุณากรอกหัวข้อประกาศ']);
    exit;
}

$result = dd_q(
    "INSERT INTO popup_announcements (title, content, image_url, button_text, button_link, is_active) VALUES (?, ?, ?, ?, ?, ?)",
    [$title, $content, $image ?: null, $button_text, $button_link ?: null, $active]
);

if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'เพิ่มประกาศสำเร็จ!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'เกิดข้อผิดพลาด']);
}
