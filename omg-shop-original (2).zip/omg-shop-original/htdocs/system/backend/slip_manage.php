<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../a_func.php';

function dd_return($status, $message)
{
    $json = ['message' => $message];
    if ($status) {
        http_response_code(200);
        die(json_encode($json));
    } else {
        http_response_code(400);
        die(json_encode($json));
    }
}

//////////////////////////////////////////////////////////////////////////

header('Content-Type: application/json; charset=utf-8;');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_SESSION['id'])) {

        if ($_POST['fname'] != "" AND $_POST['lname'] != "" AND $_POST['bnum'] != "" AND $_POST['tname'] != "") {
            $q_1 = dd_q('SELECT * FROM users WHERE id = ? AND rank = 1 ', [$_SESSION['id']]);
            if ($q_1->rowCount() >= 1) {
                // Older databases do not have the optional PromptPay column yet.
                dd_q("ALTER TABLE bank ADD COLUMN IF NOT EXISTS promptpay_id VARCHAR(100) NULL AFTER bnum");
                $update = dd_q("UPDATE bank SET fname = ? , lname = ? , bnum = ?, tname = ?, promptpay_id = ?", [$_POST['fname'], $_POST['lname'], $_POST['bnum'], $_POST['tname'], $_POST['promptpay_id']]);
                if ($update) {
                    dd_return(true, "บันทึกสำเร็จ");
                } else {
                    dd_return(false, "SQL ผิดพลาด");
                }
            } else {
                dd_return(false, "เซสชั่นผิดพลาด โปรดล็อกอินใหม่");
                session_destroy();
            }
        } else {
            dd_return(false, "กรุณากรอกข้อมูลให้ครบ");
        }
    } else {
        dd_return(false, "เข้าสู่ระบบก่อน");
    }
} else {
    dd_return(false, "Method '{$_SERVER['REQUEST_METHOD']}' not allowed!");
}
