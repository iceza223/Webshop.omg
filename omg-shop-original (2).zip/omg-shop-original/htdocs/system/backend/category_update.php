<?php
error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once '../a_func.php';
header('Content-Type: application/json; charset=utf-8');

function dd_return($status, $message) {
    http_response_code($status ? 200 : 400);
    die(json_encode(['message' => $message], JSON_UNESCAPED_UNICODE));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dd_return(false, 'Method ไม่ถูกต้อง');
}

if (!isset($_SESSION['id'])) {
    dd_return(false, 'เข้าสู่ระบบก่อน');
}

$admin = dd_q('SELECT id FROM users WHERE id = ? AND rank = 1 LIMIT 1', [$_SESSION['id']]);
if (!$admin || $admin->rowCount() < 1) {
    session_destroy();
    dd_return(false, 'เซสชั่นหมดอายุหรือไม่มีสิทธิ์ผู้ดูแลระบบ โปรดล็อกอินใหม่');
}

$id = trim((string)($_POST['c_id'] ?? ''));
$name = trim((string)($_POST['c_name'] ?? ''));
$description = trim((string)($_POST['des'] ?? ''));
$image = trim((string)($_POST['img'] ?? ''));

if ($id === '' || !ctype_digit($id) || (int)$id < 1) {
    dd_return(false, 'รหัสหมวดหมู่ไม่ถูกต้อง');
}
if ($name === '' || $description === '' || $image === '') {
    dd_return(false, 'กรุณากรอกชื่อหมวดหมู่ คำอธิบาย และ URL รูปภาพให้ครบ');
}
if (strlen($name) > 255 || strlen($description) > 1000 || strlen($image) > 1000) {
    dd_return(false, 'ข้อมูลยาวเกินขนาดที่ระบบรองรับ');
}

$existing = dd_q('SELECT c_id FROM category WHERE c_id = ? LIMIT 1', [(int)$id]);
if (!$existing || $existing->rowCount() < 1) {
    dd_return(false, 'ไม่พบหมวดหมู่ที่ต้องการแก้ไข');
}

$duplicate = dd_q('SELECT c_id FROM category WHERE c_name = ? AND c_id <> ? LIMIT 1', [$name, (int)$id]);
if (!$duplicate) {
    dd_return(false, 'ไม่สามารถตรวจสอบชื่อหมวดหมู่ได้');
}
if ($duplicate->rowCount() > 0) {
    dd_return(false, 'มีชื่อหมวดหมู่นี้อยู่แล้ว กรุณาใช้ชื่ออื่น');
}

$update = dd_q('UPDATE category SET c_name = ?, des = ?, img = ? WHERE c_id = ?', [$name, $description, $image, (int)$id]);
if (!$update) {
    dd_return(false, 'บันทึกการแก้ไขไม่สำเร็จ กรุณาตรวจสอบฐานข้อมูลหรือข้อมูลที่กรอก');
}

dd_return(true, 'แก้ไขหมวดหมู่สำเร็จ');
?>
