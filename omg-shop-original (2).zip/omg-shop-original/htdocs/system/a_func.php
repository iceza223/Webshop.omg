<?php
date_default_timezone_set('Asia/Bangkok');
// Keep session lifetime consistent on shared hosting; the heartbeat can
// refresh active sessions without being removed by a short PHP default.
ini_set('session.gc_maxlifetime', '2592000');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'lifetime' => 2592000,
        'path' => '/',
        'httponly' => true,
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'samesite' => 'Lax'
    ]);
    session_start();
}
error_reporting(0);
ini_set('display_errors', '0');
$host = '127.0.0.1';
$db_user = 'preview';
$db_pass = 'preview';
$db = 'preview';
// Stable MySQL connection for shared hosting.
function db_connect()
{
    global $host, $db, $db_user, $db_pass;
    $dsn = "mysql:host={$host};port=3306;dbname={$db};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_TIMEOUT => 8,
        PDO::ATTR_PERSISTENT => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
    ];
    try {
        $pdo = new PDO($dsn, $db_user, $db_pass, $options);
        try { $pdo->exec("SET time_zone = '+07:00'"); } catch (PDOException $e) { error_log('MySQL timezone setup failed: ' . $e->getMessage()); }
        return $pdo;
    } catch (PDOException $e) {
        error_log('MySQL connection failed: ' . $e->getMessage());
        http_response_code(503);
        exit('Database service is temporarily unavailable. Please try again shortly.');
    }
}
$conn = db_connect();
//end connect to database
//function query
function dd_q($str, $arr = [])
{
    global $conn;
    for ($attempt = 0; $attempt < 2; $attempt++) {
        try {
            $exec = $conn->prepare($str);
            $exec->execute($arr);
            return $exec;
        } catch (PDOException $e) {
            $driverCode = (int)($e->errorInfo[1] ?? 0);
            $retryable = in_array($driverCode, [2006, 2013, 2055], true);
            if ($attempt === 0 && $retryable) {
                $conn = db_connect();
                continue;
            }
            error_log('MySQL query failed: ' . $e->getMessage());
            return false;
        }
    }
    return false;
}
//end function query

//function check login
function check_login()
{
    if (!isset($_SESSION['id'])) {
        return false;
    } else {
        return true;
    }
}
function checknull($var = [])
{
    foreach ($var as $key => $value) {
        if ($value == "" || empty($value) || !isset($value)) {
            return false;
        }
    }
    return true;
}
// Google reCAPTCHA v2 test keys: temporary testing only; replace before production.
$conf['sitekey'] = "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI";
$conf['secretkey'] = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe";
// Preview sandbox only: do not copy this flag to production.
$preview_mode = true;
function base_url()
{
    return "";
}
$get_setting = dd_q("SELECT * FROM setting");
$config = $get_setting->fetch(PDO::FETCH_ASSOC);

$byshop = dd_q("SELECT * FROM byshop")->fetch(PDO::FETCH_ASSOC);
$byshop_status = $byshop["status"];
$byshop_key = $byshop["apikey"];
$byshop_cost = $byshop["cost"];


if (isset($_SESSION['id'])) {
    $q1 = dd_q("SELECT * FROM users WHERE id = ? LIMIT 1", [$_SESSION['id']]);
    $user = $q1->fetch(PDO::FETCH_ASSOC);
}
