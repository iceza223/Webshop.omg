<?php
require_once __DIR__ . '/a_func.php';
if (!isset($_SESSION['id'])) {
    header('Location: ../?page=register');
    exit;
}
$name = basename((string)($_GET['file'] ?? ''));
$base = realpath(__DIR__ . '/../download/files');
$path = $base !== false ? realpath($base . DIRECTORY_SEPARATOR . $name) : false;
if ($base === false || $path === false || dirname($path) !== $base || !is_file($path)) {
    http_response_code(404);
    exit('ไม่พบไฟล์ดาวน์โหลด');
}
$download_name = str_replace(["\r", "\n", '"'], '_', $name);
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $download_name . '"');
header('Content-Length: ' . (string)filesize($path));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($path);
exit;
