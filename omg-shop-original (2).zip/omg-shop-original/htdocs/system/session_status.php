<?php
// Lightweight session status endpoint for the client-side heartbeat.
require_once __DIR__ . '/a_func.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function session_status_response($loggedIn, $message = '') {
    http_response_code($loggedIn ? 200 : 401);
    exit(json_encode([
        'logged_in' => $loggedIn,
        'message' => $message
    ], JSON_UNESCAPED_UNICODE));
}

if (empty($_SESSION['id'])) {
    session_status_response(false, 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่');
}

// Passive heartbeats must not extend an idle session. The browser sends
// touch=1 only after real user activity or an explicit "ใช้งานต่อ" action.
$sessionTimeout = 600;
$lastActivity = (int) ($_SESSION['LAST_ACTIVITY'] ?? 0);
if ($lastActivity > 0 && (time() - $lastActivity) >= $sessionTimeout) {
    $_SESSION = [];
    session_destroy();
    session_status_response(false, 'ไม่มีการใช้งานครบ 10 นาที กรุณาเข้าสู่ระบบใหม่');
}

// Respect the application's one-active-session-per-account rule. A temporary
// read failure must not be treated as a login from another device.
$sessionFile = dirname(__DIR__) . '/system/sessions/' . (int) $_SESSION['id'] . '.token';
$tokenRead = is_file($sessionFile) ? @file_get_contents($sessionFile) : false;
$activeToken = $tokenRead === false ? null : trim((string) $tokenRead);
if (!empty($_SESSION['single_session_token']) && $activeToken !== null &&
    ($activeToken === '' || !hash_equals($activeToken, (string) $_SESSION['single_session_token']))) {
    $_SESSION = [];
    session_destroy();
    session_status_response(false, 'บัญชีนี้ถูกเข้าสู่ระบบจากอุปกรณ์อื่น');
}

$userCheck = dd_q('SELECT id FROM users WHERE id = ? LIMIT 1', [(int) $_SESSION['id']]);
// A temporary database failure is not proof that the account disappeared.
// Keep the session alive and let the next heartbeat retry.
if ($userCheck === false) {
    if (isset($_GET['touch']) && $_GET['touch'] === '1') {
        $_SESSION['LAST_ACTIVITY'] = time();
    }
    session_write_close();
    session_status_response(true);
}
if (!$userCheck->fetch(PDO::FETCH_ASSOC)) {
    $_SESSION = [];
    session_destroy();
    session_status_response(false, 'ไม่พบผู้ใช้ในระบบ');
}

if (isset($_GET['touch']) && $_GET['touch'] === '1') {
    $_SESSION['LAST_ACTIVITY'] = time();
}
session_write_close();
session_status_response(true);
?>
