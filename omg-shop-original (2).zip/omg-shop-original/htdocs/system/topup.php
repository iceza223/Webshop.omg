<?php
error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once 'a_func.php';
require_once __DIR__ . '/discord_notify.php';

function dd_return($status, $message)
{
    if ($status) {
        $json = ['status' => 'success', 'message' => $message];
        http_response_code(200);
        die(json_encode($json, JSON_UNESCAPED_UNICODE));
    }

    $json = ['status' => 'fail', 'message' => $message];
    http_response_code(400);
    die(json_encode($json, JSON_UNESCAPED_UNICODE));
}

/**
 * Redeem a TrueMoney voucher through the new public API.
 * The endpoint expects JSON: {"phone":"...", "voucher":"..."}.
 */
function wallet($link, $phone)
{
    $apiUrl = 'https://omg-wallet.lovable.app/api/public/truemoney';
    $payload = json_encode(
        [
            'phone' => (string) $phone,
            'voucher' => (string) $link,
        ],
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    );

    if ($payload === false) {
        return ['ok' => false, 'message' => 'ไม่สามารถเตรียมข้อมูลสำหรับ API ได้'];
    }

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $apiUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Accept: application/json',
        ],
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $body = curl_exec($curl);
    $curlError = curl_error($curl);
    $curlErrno = curl_errno($curl);
    $httpCode = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    if ($body === false) {
        error_log('TrueMoney API connection failed (' . $curlErrno . '): ' . $curlError);
        return ['ok' => false, 'message' => 'ไม่สามารถเชื่อมต่อ TrueMoney API ได้ กรุณาลองใหม่อีกครั้ง'];
    }

    $response = json_decode($body, true);
    if (!is_array($response)) {
        error_log('TrueMoney API returned invalid JSON with HTTP status ' . $httpCode);
        return ['ok' => false, 'message' => 'TrueMoney API ส่งข้อมูลไม่ถูกต้อง'];
    }

    $status = $response['status'] ?? null;
    $statusCode = is_array($status) ? strtoupper((string) ($status['code'] ?? '')) : '';
    $statusMessage = is_array($status)
        ? (string) ($status['message'] ?? '')
        : (string) ($response['message'] ?? '');

    if ($statusCode === 'SUCCESS') {
        $amountRaw = $response['data']['voucher']['amount_baht'] ?? null;
        if (!is_numeric($amountRaw) || (float) $amountRaw <= 0) {
            error_log('TrueMoney API success response has invalid amount');
            return ['ok' => false, 'message' => 'API ตอบว่าสำเร็จแต่ไม่พบจำนวนเงินที่ถูกต้อง'];
        }

        return ['ok' => true, 'amount' => (float) $amountRaw];
    }

    $knownMessages = [
        'VOUCHER_OUT_OF_STOCK' => 'ซองอั่งเปานี้ถูกใช้ครบแล้ว',
        'VOUCHER_REDEEMED' => 'ซองอั่งเปานี้ถูกใช้ไปแล้ว',
        'VOUCHER_NOT_FOUND' => 'ไม่พบซองอั่งเปานี้',
        'VOUCHER_EXPIRED' => 'ซองอั่งเปานี้หมดอายุแล้ว',
        'TARGET_USER_NOT_FOUND' => 'ไม่พบหมายเลข TrueWallet ที่ตั้งค่าไว้',
        'BAD_REQUEST' => 'ข้อมูลซองอั่งเปาหรือหมายเลข TrueWallet ไม่ถูกต้อง',
    ];

    if (isset($knownMessages[$statusCode])) {
        return ['ok' => false, 'message' => $knownMessages[$statusCode]];
    }

    if ($statusMessage !== '') {
        return ['ok' => false, 'message' => $statusMessage];
    }

    return ['ok' => false, 'message' => 'TrueMoney API ปฏิเสธรายการ (HTTP ' . $httpCode . ')'];
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dd_return(false, "Method '{$_SERVER['REQUEST_METHOD']}' not allowed!");
}

if (!isset($_SESSION['id'])) {
    dd_return(false, 'เข้าสู่ระบบก่อนดำเนินการครับ');
}

$link = trim((string) ($_POST['link'] ?? ''));
if ($link === '') {
    dd_return(false, 'กรุณาใส่ลิงก์ซองของขวัญ');
}

$phone = preg_replace('/\D+/', '', (string) ($config['wallet'] ?? ''));
if (!is_string($phone) || !preg_match('/^\d{10}$/', $phone)) {
    dd_return(false, 'กรุณาตั้งค่าหมายเลข TrueWallet 10 หลักในระบบหลังบ้านก่อนใช้งาน');
}

$res = wallet($link, $phone);
if (!($res['ok'] ?? false)) {
    dd_return(false, (string) ($res['message'] ?? 'ไม่สามารถตรวจสอบซองอั่งเปาได้'));
}

$amount = (float) ($res['amount'] ?? 0);
if ($amount <= 0) {
    dd_return(false, 'จำนวนเงินที่ได้รับไม่ถูกต้อง');
}

$plr = dd_q('SELECT * FROM users WHERE id = ?', [$_SESSION['id']])->fetch(PDO::FETCH_ASSOC);
if (!$plr) {
    dd_return(false, 'ไม่พบข้อมูลผู้ใช้');
}

$update = dd_q(
    'UPDATE users SET point = ?, total = ? WHERE id = ?',
    [$plr['point'] + $amount, $plr['total'] + $amount, $_SESSION['id']]
);
$insert = dd_q(
    'INSERT INTO topup_his (link, amount, date, uid, uname) VALUES (?, ?, NOW(), ?, ?)',
    [$link, $amount, $plr['id'], $plr['username']]
);

if ($update && $insert) {
    send_discord_transaction_notification(
        'topup',
        'มีการเติมเงินใหม่',
        'เติมเงินผ่าน TrueMoney Gift สำเร็จ',
        [
            ['name' => 'ชื่อผู้ใช้', 'value' => (string) ($plr['username'] ?? '-')],
            ['name' => 'จำนวนเงิน', 'value' => number_format($amount, 2) . ' บาท'],
            ['name' => 'ยอดเงินหลังเติม', 'value' => number_format((float) $plr['point'] + $amount, 2) . ' บาท'],
        ],
        5763719
    );
    dd_return(true, 'คุณได้รับเงินจำนวน ' . $amount . ' บาท');
}

dd_return(false, 'ไม่สามารถบันทึกประวัติการเติมเงินได้');
