<?php

require_once __DIR__ . '/../discord_webhook.php';

/**
 * Send a transaction notification to the configured Discord webhook.
 * Notification failures are logged and never interrupt the transaction response.
 */
function send_discord_transaction_notification(
    string $event,
    string $title,
    string $description,
    array $fields = [],
    int $color = 5763719
): bool {
    global $config;

    $settingKey = match ($event) {
        'topup' => 'discord_topup_notify',
        'purchase' => 'discord_purchase_notify',
        default => null,
    };

    if ($settingKey === null || (($config[$settingKey] ?? 'on') !== 'on')) {
        return false;
    }

    $webhookUrl = trim((string) ($config['webhook_dc'] ?? ''));
    if ($webhookUrl === '' || $webhookUrl === '#') {
        return false;
    }

    try {
        $webhook = new DiscordWebhook(
            $webhookUrl,
            (string) ($config['name'] ?? 'เว็บไซต์ OMGVIP')
        );
        $webhook->sendEmbed($title, $description, $fields, $color);
        return true;
    } catch (Throwable $exception) {
        error_log('Discord transaction notification failed: ' . $exception->getMessage());
        return false;
    }
}
