<?php
error_reporting(0);
ini_set('display_errors', '0');
require_once 'a_func.php';

function login_return($status, $message)
{
    http_response_code(200);
    echo json_encode([
        'status' => $status ? 'success' : 'fail',
        'message' => $message
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    login_return(false, 'Method ไม่ได้รับอนุญาต');
}
if (isset($_SESSION['id'])) {
    login_return(false, 'ออกจากระบบก่อน');
}

$user_login = trim((string) ($_POST['user'] ?? ''));
$pwd_login = (string) ($_POST['pass'] ?? '');
if ($user_login === '' || $pwd_login === '' || strlen($user_login) > 100 || strlen($pwd_login) > 255) {
    login_return(false, 'กรุณากรอกข้อมูลให้ครบถ้วน');
}

$secret = $conf['secretkey'] ?? '';
$preview_mode = $preview_mode ?? false;
$captcha_response = (string) ($_POST['captcha'] ?? '');
if (!$preview_mode) {
    if ($secret === '' || $captcha_response === '') {
        login_return(false, 'กรุณายืนยันตัวตน');
    }

    $ch = curl_init('https://www.google.com/recaptcha/api/siteverify');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query(['secret' => $secret, 'response' => $captcha_response]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
    ]);
    $verify = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);
    $captcha_success = $verify ? json_decode($verify, true) : null;
    if (!$captcha_success || ($captcha_success['success'] ?? false) !== true) {
        login_return(false, $curl_error ? 'ไม่สามารถตรวจสอบ reCAPTCHA ได้ชั่วคราว' : 'กรุณายืนยันตัวตน');
    }

}
$q = dd_q('SELECT * FROM users WHERE username = ? LIMIT 1', [$user_login]);
if (!$q || $q->rowCount() !== 1) {
    login_return(false, 'ไม่พบผู้ใช้นี้ / รหัสผ่านไม่ถูกต้อง');
}

$account = $q->fetch(PDO::FETCH_ASSOC);
$stored_password = (string) ($account['password'] ?? '');
$valid = password_verify($pwd_login, $stored_password);
$legacy = false;
if (!$valid && hash_equals($stored_password, md5($pwd_login))) {
    $valid = true;
    $legacy = true;
}
if (!$valid && hash_equals($stored_password, hash('sha256', hash('sha256', $pwd_login)))) {
    $valid = true;
    $legacy = true;
}
if (!$valid) {
    login_return(false, 'ไม่พบผู้ใช้นี้ / รหัสผ่านไม่ถูกต้อง');
}

if ($legacy || password_needs_rehash($stored_password, PASSWORD_DEFAULT)) {
    dd_q('UPDATE users SET password = ? WHERE id = ?', [password_hash($pwd_login, PASSWORD_DEFAULT), $account['id']]);
}

session_regenerate_id(true);

// One active session per account: the newest login replaces the previous token.
$session_dir = __DIR__ . '/sessions';
if (!is_dir($session_dir) && !mkdir($session_dir, 0700, true) && !is_dir($session_dir)) {
    login_return(false, 'ระบบเซสชันไม่พร้อมใช้งาน');
}
$session_token = bin2hex(random_bytes(32));
$session_file = $session_dir . '/' . (int) $account['id'] . '.token';
if (file_put_contents($session_file, $session_token, LOCK_EX) === false) {
    login_return(false, 'ระบบเซสชันไม่พร้อมใช้งาน');
}
$_SESSION['single_session_token'] = $session_token;
$_SESSION['id'] = (int) $account['id'];
login_return(true, 'เข้าสู่ระบบสำเร็จ');
