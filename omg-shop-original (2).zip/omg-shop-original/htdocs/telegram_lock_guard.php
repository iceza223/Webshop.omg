<?php
declare(strict_types=1);

require_once __DIR__ . '/telegram_lock_config.php';

function telegram_lock_state(): array
{
    $default = ['locked' => false, 'updated_at' => null, 'updated_by' => null];
    if (!is_file(TELEGRAM_LOCK_STATE_FILE)) {
        return $default;
    }
    $raw = @file_get_contents(TELEGRAM_LOCK_STATE_FILE);
    $state = is_string($raw) ? json_decode($raw, true) : null;
    return is_array($state) ? array_merge($default, $state) : $default;
}

$telegram_lock_state = telegram_lock_state();
if (!empty($telegram_lock_state['locked'])) {
    http_response_code(503);
    header('Retry-After: 300');
    if (PHP_SAPI !== 'cli') {
        while (ob_get_level() > 0) { @ob_end_clean(); }
    }
    $updated = htmlspecialchars((string)($telegram_lock_state['updated_at'] ?? ''), ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>เว็บไซต์ปิดชั่วคราว</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#08070a;color:#fff6df;font-family:Arial,sans-serif}.box{width:min(92vw,520px);padding:42px 28px;text-align:center;background:#160d17;border:1px solid #6b2145;border-radius:22px;box-shadow:0 15px 50px #000}h1{margin:14px 0 8px;font-size:28px}p{color:#d7c5a5;line-height:1.7}.lock{font-size:58px}</style></head><body><main class="box"><div class="lock">🔒</div><h1>เว็บไซต์ปิดให้บริการชั่วคราว</h1><p>กรุณากลับมาใหม่ภายหลัง</p><small>อัปเดตล่าสุด: ' . $updated . '</small></main></body></html>';
    exit;
}
