<?php
// Keep users signed in during normal periods of inactivity on the shared host.
// The application timeout below is the authoritative timeout; PHP's garbage
// collector is also extended so the server does not remove the session early.
ini_set('session.gc_maxlifetime', '2592000');
session_set_cookie_params([
    'lifetime' => 2592000,
    'path' => '/',
    'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();
// Telegram-controlled maintenance lock. The webhook endpoint remains available so the owner can unlock.
require_once __DIR__ . '/telegram_lock_guard.php';
// Auto logout after 10 minutes of inactivity.
$session_timeout = 600;
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - (int)$_SESSION['LAST_ACTIVITY']) > $session_timeout) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    header('Location: ?page=login&timeout=1');
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();

error_reporting(0);
// Buffer output so server-side redirects still work after shared-host templates begin rendering.
ob_start();
require_once("system/a_func.php");
require_once __DIR__ . '/admin_pin_config.php';
// Enforce one active login session per account.
if (isset($_SESSION['id'])) {
    $session_file = __DIR__ . '/system/sessions/' . (int) $_SESSION['id'] . '.token';
    $token_read = is_file($session_file) ? @file_get_contents($session_file) : false;
    $active_token = $token_read === false ? null : trim((string) $token_read);
    if (empty($_SESSION['single_session_token'])) {
        if ($active_token !== null && $active_token !== '') {
            $_SESSION['single_session_token'] = $active_token;
        } elseif ($active_token === '') {
            $new_token = bin2hex(random_bytes(32));
            if (file_put_contents($session_file, $new_token, LOCK_EX) !== false) {
                $_SESSION['single_session_token'] = $new_token;
                $active_token = $new_token;
            }
        }
    } elseif ($active_token !== null && ($active_token === '' || !hash_equals($active_token, (string) $_SESSION['single_session_token']))) {
        $_SESSION = [];
        session_destroy();
        $_GET['page'] = 'login';
    }
}
if (isset($_SESSION['id'])) {
    $q1 = dd_q("SELECT * FROM users WHERE id = ? LIMIT 1", [$_SESSION['id']]);
    if ($q1->rowCount() == 1) {
        $user = $q1->fetch(PDO::FETCH_ASSOC);
    } else {
        session_destroy();
        $_GET['page'] = "login";
    }
}
if (($_GET['page'] ?? '') === 'admin_chat_api') {
    header('Content-Type: application/json; charset=utf-8');
    if (!isset($_SESSION['id']) || !is_numeric($_SESSION['id'])) { http_response_code(401); echo json_encode(['ok'=>false,'login_required'=>true,'message'=>'กรุณาเข้าสู่ระบบก่อนใช้งานแชท'], JSON_UNESCAPED_UNICODE); exit; }
    if (($config['chat_status'] ?? 'on') !== 'on') { http_response_code(503); echo json_encode(['ok'=>false,'chat_disabled'=>true,'message'=>'ขณะนี้ระบบแชทปิดให้บริการ'], JSON_UNESCAPED_UNICODE); exit; }
    try {
        $conn->exec("CREATE TABLE IF NOT EXISTS admin_chat_messages (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,sender ENUM('user','admin') NOT NULL,message TEXT NOT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX idx_chat_user_created (user_id,created_at),INDEX idx_chat_sender (sender)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        try { $conn->exec("ALTER TABLE admin_chat_messages ADD COLUMN admin_read_at TIMESTAMP NULL DEFAULT NULL, ADD COLUMN user_read_at TIMESTAMP NULL DEFAULT NULL"); } catch (Throwable $migrationError) {}
        try { $conn->exec("CREATE INDEX IF NOT EXISTS idx_chat_user_id ON admin_chat_messages (user_id, id)"); } catch (Throwable $indexError) {}
        try { $conn->exec("CREATE INDEX IF NOT EXISTS idx_chat_admin_unread ON admin_chat_messages (sender, admin_read_at)"); } catch (Throwable $indexError) {}
        try { $conn->exec("CREATE INDEX IF NOT EXISTS idx_chat_user_unread ON admin_chat_messages (user_id, sender, user_read_at)"); } catch (Throwable $indexError) {}
        try { $conn->exec("CREATE INDEX IF NOT EXISTS idx_chat_user_admin_read ON admin_chat_messages (user_id, sender, admin_read_at)"); } catch (Throwable $indexError) {}

        $uid=(int)$_SESSION['id'];
        if ($_SERVER['REQUEST_METHOD']==='GET') { $markRead=$conn->prepare("UPDATE admin_chat_messages SET user_read_at=NOW() WHERE user_id=? AND sender='admin' AND user_read_at IS NULL"); $markRead->execute([$uid]); $q=$conn->prepare('SELECT id,sender,message,created_at FROM admin_chat_messages WHERE user_id=? ORDER BY id ASC LIMIT 200'); $q->execute([$uid]); echo json_encode(['ok'=>true,'messages'=>$q->fetchAll(PDO::FETCH_ASSOC)],JSON_UNESCAPED_UNICODE); exit; }
        $msg=trim((string)($_POST['message']??'')); if($msg===''||mb_strlen($msg)>3000){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'กรุณาพิมพ์ข้อความไม่เกิน 3,000 ตัวอักษร'],JSON_UNESCAPED_UNICODE);exit;}
        $q=$conn->prepare("INSERT INTO admin_chat_messages (user_id,sender,message) VALUES (?,'user',?)");$q->execute([$uid,$msg]);echo json_encode(['ok'=>true,'message'=>'ส่งข้อความแล้ว'],JSON_UNESCAPED_UNICODE);exit;
    } catch (Exception $e) { http_response_code(500); echo json_encode(['ok'=>false,'message'=>'ระบบแชทขัดข้องชั่วคราว'],JSON_UNESCAPED_UNICODE); exit; }
}
if (($_GET['page'] ?? '') === 'admin_chat_unread') {
    header('Content-Type: application/json; charset=utf-8');
    if (!isset($_SESSION['id'], $user) || ($user['rank'] ?? '') != '1') { http_response_code(403); echo json_encode(['ok'=>false], JSON_UNESCAPED_UNICODE); exit; }
    try {
        $conn->exec("CREATE TABLE IF NOT EXISTS admin_chat_messages (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,sender ENUM('user','admin') NOT NULL,message TEXT NOT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX idx_chat_user_created (user_id,created_at),INDEX idx_chat_sender (sender)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        try { $conn->exec("ALTER TABLE admin_chat_messages ADD COLUMN admin_read_at TIMESTAMP NULL DEFAULT NULL, ADD COLUMN user_read_at TIMESTAMP NULL DEFAULT NULL"); } catch (Throwable $migrationError) {}
        $count=(int)$conn->query("SELECT COUNT(*) FROM admin_chat_messages WHERE sender='user' AND admin_read_at IS NULL")->fetchColumn();
        echo json_encode(['ok'=>true,'unread'=>$count],JSON_UNESCAPED_UNICODE); exit;
    } catch (Exception $e) { http_response_code(500); echo json_encode(['ok'=>false,'unread'=>0],JSON_UNESCAPED_UNICODE); exit; }
}
if (($_GET['page'] ?? '') === 'truemoney_card_unread') {
    header('Content-Type: application/json; charset=utf-8');
    if (!isset($_SESSION['id'], $user) || ($user['rank'] ?? '') != '1') { http_response_code(403); echo json_encode(['ok'=>false], JSON_UNESCAPED_UNICODE); exit; }
    try {
        $q = $conn->query("SELECT COUNT(*) FROM truemoney_card_requests WHERE status='pending'");
        echo json_encode(['ok'=>true,'pending'=>(int)$q->fetchColumn()], JSON_UNESCAPED_UNICODE); exit;
    } catch (Throwable $e) {
        echo json_encode(['ok'=>true,'pending'=>0], JSON_UNESCAPED_UNICODE); exit;
    }
}
if (($_GET['page'] ?? '') === 'user_chat_unread') {
    header('Content-Type: application/json; charset=utf-8');
    if (!isset($_SESSION['id']) || !is_numeric($_SESSION['id'])) { http_response_code(401); echo json_encode(['ok'=>false], JSON_UNESCAPED_UNICODE); exit; }
    if (($config['chat_status'] ?? 'on') !== 'on') { echo json_encode(['ok'=>true,'unread'=>0,'chat_disabled'=>true], JSON_UNESCAPED_UNICODE); exit; }
    try {
        $uid=(int)$_SESSION['id'];
        $q=$conn->prepare("SELECT COUNT(*) FROM admin_chat_messages a WHERE a.user_id=? AND a.sender='admin' AND a.user_read_at IS NULL");
        $q->execute([$uid]); echo json_encode(['ok'=>true,'unread'=>(int)$q->fetchColumn()],JSON_UNESCAPED_UNICODE); exit;
    } catch (Exception $e) { http_response_code(500); echo json_encode(['ok'=>false,'unread'=>0],JSON_UNESCAPED_UNICODE); exit; }
}
$get_static = dd_q("SELECT * FROM static");
$static = $get_static->fetch(PDO::FETCH_ASSOC);
$site_logo = $config['logo'] ?? 'assets/omg-logo-animated.gif';
// SEO: use the live canonical domain and prevent private/account routes from indexing.
$seo_page = (string)($_GET['page'] ?? '');
$seo_public_pages = ['', 'home', 'shop', 'product'];
$seo_is_public = in_array($seo_page, $seo_public_pages, true);
$seo_site_name = trim((string)($config['name'] ?? 'OMG VIP')) ?: 'OMG VIP';
$seo_description = trim((string)($config['des'] ?? 'ร้าน OMGVIPSHOP บริการสินค้าและดาวน์โหลดแอป พร้อมระบบสมาชิกออนไลน์')) ?: 'ร้าน OMGVIPSHOP บริการสินค้าและดาวน์โหลดแอป พร้อมระบบสมาชิกออนไลน์';
$seo_title = 'OMGVIPSHOP | ดาวน์โหลด MOD และเข้ากลุ่ม VIP';
if ($seo_page === 'shop') {
    $seo_title = 'ร้าน OMGVIPSHOP | ดาวน์โหลด MOD และสินค้าออนไลน์';
} elseif ($seo_page === 'product') {
    $seo_title = 'รายละเอียดสินค้า MOD และแอป | OMGVIPSHOP';
} elseif ($seo_page === 'download') {
    $seo_title = 'ดาวน์โหลดแอปและไฟล์ | OMGVIPSHOP';
}
// Treat / and ?page=home as one public URL to avoid duplicate indexing.
$seo_canonical = 'https://omg-vip.online/';
if ($seo_page !== '' && $seo_page !== 'home') {
    $seo_canonical .= '?page=' . rawurlencode($seo_page);
    if ($seo_page === 'product' && isset($_GET['id']) && ctype_digit((string)$_GET['id'])) {
        $seo_canonical .= '&id=' . (int)$_GET['id'];
    }
}
$seo_robots = $seo_is_public ? 'index,follow,max-image-preview:large' : 'noindex,nofollow';
// Use a local logo when the configured URL points to the retired external domain.
if (preg_match('#^https?://(?:www\.)?omgvip\.shop/#i', (string)$site_logo)) {
    $site_logo = 'assets/omg-logo-transparent.webp';
}
$requested_page_for_assets = $_GET['page'] ?? '';
$needs_recaptcha = in_array($requested_page_for_assets, ['login', 'register'], true) && !($preview_mode ?? false);
$datatable_pages = ['user_edit', 'category_manage', 'product_manage', 'stock_manage', 'code_manage', 'discount_manage', 'popup_manage', 'notification_manage', 'backend_buy_history', 'backend_topup_history', 'carousel_manage'];
$needs_datatables = in_array($requested_page_for_assets, $datatable_pages, true);
if (in_array($site_logo, ['assets/omg-logo-new.webp', 'assets/omg-logo-animated.gif', 'assets/omg-logo-blue.webp', 'assets/omg-logo.webp', 'assets/omg-logo.png', 'assets/omg-logo-new.png'], true)) {
    $site_logo = 'assets/omg-logo-transparent.webp';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= htmlspecialchars($seo_description, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="robots" content="<?= $seo_robots ?>">
    <link rel="canonical" href="<?= htmlspecialchars($seo_canonical, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars($seo_site_name, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:title" content="<?= htmlspecialchars($seo_title, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:type" content="<?= $seo_page === 'product' ? 'product' : 'website' ?>">
    <meta property="og:url" content="<?= htmlspecialchars($seo_canonical, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:image" content="<?= htmlspecialchars((strpos($site_logo, 'http') === 0 ? $site_logo : 'https://omg-vip.online/' . ltrim($site_logo, '/')), ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:description" content="<?= htmlspecialchars($seo_description, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:locale" content="th_TH">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($seo_title, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($seo_description, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars((strpos($site_logo, 'http') === 0 ? $site_logo : 'https://omg-vip.online/' . ltrim($site_logo, '/')), ENT_QUOTES, 'UTF-8') ?>">
    <title><?= htmlspecialchars($seo_title, ENT_QUOTES, 'UTF-8') ?></title>
    <?php if ($seo_is_public): ?>
    <script type="application/ld+json">{
      "@context":"https://schema.org","@type":"WebSite",
      "name":<?= json_encode($seo_site_name, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,
      "url":"https://omg-vip.online/","description":<?= json_encode($seo_description, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>
    }</script>
    <?php endif; ?>
    <link rel="shortcut icon" href="<?php echo htmlspecialchars($site_logo, ENT_QUOTES, 'UTF-8'); ?>" type="image/png" sizes="16x16">
    <link rel="stylesheet" href="system/css/second.css?v=20260902-navfix">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"
        integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <?php if ($needs_datatables): ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <?php endif; ?>
    <link href="https://kit-pro.fontawesome.com/releases/v6.2.0/css/pro.min.css" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if ($needs_recaptcha): ?><script src="https://www.google.com/recaptcha/api.js" async defer></script><?php endif; ?>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php
    $font_options = [
        'kanit' => ['url' => 'Kanit:wght@400;500;600;700', 'family' => "'Kanit', sans-serif"],
        'prompt' => ['url' => 'Prompt:wght@400;500;600;700', 'family' => "'Prompt', sans-serif"],
        'sarabun' => ['url' => 'Sarabun:wght@400;500;600;700', 'family' => "'Sarabun', sans-serif"],
        'ibm_plex_sans_thai' => ['url' => 'IBM+Plex+Sans+Thai:wght@400;500;600;700', 'family' => "'IBM Plex Sans Thai', sans-serif"],
    ];
    $selected_font = $font_options[$config['font_family'] ?? 'kanit'] ?? $font_options['kanit'];
    // OMGVIPSHOP default theme; database values override these fallbacks.
    $brand_main_color = strtolower(trim($config['main_color'] ?? '#8d3cff'));
    $brand_secondary_color = strtolower(trim($config['sec_color'] ?? '#a855f7'));
    $brand_border_color = strtolower(trim($config['border_color'] ?? '#8543be'));
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $brand_border_color) || in_array($brand_border_color, ['#ff0000', '#1e3a8a'], true)) {
        $brand_border_color = '#8543be';
    }
    $theme_colors = [
        'text_color' => '#f5efff',
        'bg_color' => '#080510',
        'card_color' => '#140a22',
        'button_color' => '#8d3cff',
        'success_color' => '#a855f7',
        'warning_color' => '#a855f7',
        'danger_color' => '#ff4d4d',
        'info_color' => '#a855f7',
    ];
    foreach ($theme_colors as $color_key => $color_fallback) {
        $color_value = strtolower(trim($config[$color_key] ?? $color_fallback));
        $theme_colors[$color_key] = preg_match('/^#[0-9a-fA-F]{6}$/', $color_value) ? $color_value : $color_fallback;
    }
    $legacy_palette = [
        ['#ff0000', '#ff0000'],
        ['#facc15', '#16a34a'],
        ['#2563eb', '#06b6d4'],
        ['#00d4ff', '#ff0080'],
    ];
    foreach ($legacy_palette as $legacy_colors) {
        if ($brand_main_color === $legacy_colors[0] && $brand_secondary_color === $legacy_colors[1]) {
            $brand_main_color = '#8d3cff';
            $brand_secondary_color = '#a855f7';
            break;
        }
    }
    // Migrate the previous blue/cyan and other legacy defaults to the logo-matched palette.
    if ($theme_colors['button_color'] === '#2563eb') {
        $theme_colors['button_color'] = '#b8d82e';
    }
    if ($theme_colors['bg_color'] === '#060b1a') {
        $theme_colors['bg_color'] = '#08070a';
    }
    if ($theme_colors['card_color'] === '#0f172a') {
        $theme_colors['card_color'] = '#0b160d';
    }
    if ($theme_colors['text_color'] === '#e2e8f0') {
        $theme_colors['text_color'] = '#f3ffe1';
    }
    if ($theme_colors['success_color'] === '#22c55e') {
        $theme_colors['success_color'] = '#b8d82e';
    }
    if ($theme_colors['warning_color'] === '#f59e0b') {
        $theme_colors['warning_color'] = '#b8d82e';
    }
    if ($theme_colors['danger_color'] === '#ef4444') {
        $theme_colors['danger_color'] = '#ff4d4d';
    }
    if ($theme_colors['info_color'] === '#38bdf8') {
        $theme_colors['info_color'] = '#7cff4d';
    }
    $font_url = 'https://fonts.googleapis.com/css2?family=' . $selected_font['url'] . '&display=swap';
    ?>
    <link href="<?= htmlspecialchars($font_url, ENT_QUOTES, 'UTF-8') ?>" rel="stylesheet">
    <link rel="stylesheet" href="system/css/option.css?v=20260902-navfix">
    <style>
        <?php
        function hexToRgb($hex)
        {
            $hex = str_replace("#", "", $hex);
            if (strlen($hex) == 3) {
                $r = hexdec(substr($hex, 0, 1) . substr($hex, 0, 1));
                $g = hexdec(substr($hex, 1, 1) . substr($hex, 1, 1));
                $b = hexdec(substr($hex, 2, 1) . substr($hex, 2, 1));
            } else {
                $r = hexdec(substr($hex, 0, 2));
                $g = hexdec(substr($hex, 2, 2));
                $b = hexdec(substr($hex, 4, 2));
            }
            return "$r, $g, $b";
        }
        ?>
        /* Dynamic Color Injection from Database */
        :root {
            --xez-primary:
                <?= htmlspecialchars($brand_main_color, ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-primary-rgb:
                <?= hexToRgb($brand_main_color) ?>
            ;
            --xez-secondary:
                <?= htmlspecialchars($brand_secondary_color, ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-text-color:
                <?= htmlspecialchars($theme_colors['text_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-border:
                <?= htmlspecialchars($brand_border_color, ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-bg:
                <?= htmlspecialchars($theme_colors['bg_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-card:
                <?= htmlspecialchars($theme_colors['card_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-button:
                <?= htmlspecialchars($theme_colors['button_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-success:
                <?= htmlspecialchars($theme_colors['success_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-success-rgb:
                <?= hexToRgb($theme_colors['success_color']) ?>
            ;
            --xez-warning:
                <?= htmlspecialchars($theme_colors['warning_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-danger:
                <?= htmlspecialchars($theme_colors['danger_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-info:
                <?= htmlspecialchars($theme_colors['info_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
        }
        .theme-light,
        body:not(.theme-dark) {
            --bg-body: var(--xez-bg);
            --bg-card: var(--xez-card);
            --bg-card-alt: var(--xez-card);
            --bg-input: var(--xez-card);
            --bg-secondary: var(--xez-card);
            --border-main: var(--xez-border);
            --border-light: var(--xez-border);
            --border-color: var(--xez-border);
        }
        .theme-dark {
            --bg-body: var(--xez-bg);
            --bg-card: var(--xez-card);
            --bg-card-alt: var(--xez-card);
            --bg-input: var(--xez-card);
            --bg-secondary: var(--xez-card);
            --border-main: var(--xez-border);
            --border-light: var(--xez-border);
            --border-color: var(--xez-border);
        }
        .xez-btn-cyan,
        .btn-login,
        .bg-main {
            background: var(--xez-button) !important;
            border-color: var(--xez-button) !important;
        }
        .btn-navbar-register {
            background: linear-gradient(135deg, var(--xez-button), var(--xez-secondary)) !important;
        }
        .xez-btn-cyan:hover,
        .btn-login:hover {
            background: var(--xez-secondary) !important;
        }
        /* Shop action buttons: warm gold/orange palette. */
        .xez-detail-btn {
            background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%) !important;
            border-color: #f59e0b !important;
            color: #1c1917 !important;
            box-shadow: 0 0 14px rgba(249, 115, 22, 0.28);
        }
        .xez-detail-btn:hover,
        .xez-order-btn:hover {
            background: linear-gradient(135deg, #fbbf24 0%, #fb923c 100%) !important;
            border-color: #fbbf24 !important;
            color: #1c1917 !important;
        }
        .xez-order-btn {
            background: linear-gradient(135deg, #facc15 0%, #f97316 100%) !important;
            border-color: #facc15 !important;
            color: #1c1917 !important;
            box-shadow: 0 0 16px rgba(250, 204, 21, 0.32);
        }
        .xez-soldout-btn {
            background: #991b1b !important;
            border-color: #7f1d1d !important;
            color: #fff !important;
            opacity: 1 !important;
        }
        .bg-success,
        .btn-success {
            background-color: var(--xez-success) !important;
            border-color: var(--xez-success) !important;
        }
        .bg-warning,
        .btn-warning {
            background-color: var(--xez-warning) !important;
            border-color: var(--xez-warning) !important;
        }
        .bg-danger,
        .btn-danger {
            background-color: var(--xez-danger) !important;
            border-color: var(--xez-danger) !important;
        }
        .bg-info,
        .btn-info {
            background-color: var(--xez-info) !important;
            border-color: var(--xez-info) !important;
        }
        .text-success { color: var(--xez-success) !important; }
        .text-warning { color: var(--xez-warning) !important; }
        .text-danger { color: var(--xez-danger) !important; }
        .text-info { color: var(--xez-info) !important; }
        body {
            color: var(--xez-text-color);
        }
        .text-dark {
            color: var(--xez-text-color) !important;
        }
        *:not(i) {
            font-family: <?= $selected_font['family'] ?> !important;
        }
        body {
            font-size: <?= max(14, min(20, (int) ($config['font_size'] ?? 16))) ?>px;
        }
        /* Keep the logged-in account summary visible beside the mobile menu button. */
        .navbar-user-mobile {
            min-width: 112px;
            max-width: 190px;
            padding: 0.3rem 0.55rem;
            line-height: 1.15;
            border: 1px solid rgba(255, 209, 102, 0.72);
            border-radius: 10px;
            background: rgba(22, 13, 23, 0.94);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.18);
        }
        .navbar-user-mobile .nav-user-mobile-name {
            display: block;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: #ffffff !important;
            font-size: 0.9em;
        }
        .navbar-user-mobile .nav-user-mobile-balance {
            display: block;
            white-space: nowrap;
            color: #ffd166 !important;
            font-size: 0.82em;
        }
        @media (max-width: 575.98px) {
            .navbar-brand {
                min-width: 0;
                flex: 1 1 auto;
            }
            .navbar-brand img {
                max-width: 36px;
                height: auto;
            }
            .navbar-text-brand {
                min-width: 0;
                max-width: 38vw;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                font-size: 0.88em;
            }
            .navbar-user-mobile {
                flex: 0 1 auto;
                min-width: 100px;
                max-width: 36vw;
                padding: 0.28rem 0.45rem;
                margin-left: 0.3rem !important;
                margin-right: 0.3rem !important;
            }
            .navbar-user-mobile .nav-user-mobile-name {
                font-size: 0.8em;
            }
            .navbar-user-mobile .nav-user-mobile-balance {
                font-size: 0.74em;
            }
            .navbar-toggler {
                flex: 0 0 auto;
                padding: 0.25rem 0.45rem;
                color: #ffd166 !important;
                background: rgba(255, 179, 0, 0.12) !important;
                border: 1px solid rgba(255, 209, 102, 0.72) !important;
                border-radius: 8px;
            }
        }
    </style>
</head>

<body class="theme-<?= $config['theme_mode'] ?? 'light' ?>">
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader-content">
            <div class="loader-logo">
                <img src="<?= htmlspecialchars($site_logo, ENT_QUOTES, 'UTF-8') ?>" alt="Logo">
            </div>
            <div class="loader-bar">
                <div class="loader-progress"></div>
            </div>
            <p class="loader-text mt-3 fw-bold"><?= $config['name'] ?></p>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg sticky-top main-navbar">
        <div class="container container-sm">
            <a class="navbar-brand d-flex align-items-center" href="/?page=home">
                <img src="<?= htmlspecialchars($site_logo, ENT_QUOTES, 'UTF-8') ?>" height="40px" width="auto" class="me-2">
                <span class="navbar-text-brand fw-bold"><?= $config['name'] ?></span>
            </a>
            <?php if (isset($_SESSION['id']) && isset($user)): ?>
                <div class="navbar-user-mobile d-lg-none text-end" aria-label="ข้อมูลบัญชีผู้ใช้">
                    <span class="nav-user-mobile-name fw-bold"><?= htmlspecialchars($user['username'] ?? '', ENT_QUOTES, 'UTF-8') ?></span>
                    <span class="nav-user-mobile-balance text-xez-primary fw-bold">ยอดเงิน ฿<?= number_format((float) ($user['point'] ?? 0), 2) ?></span>
                </div>
            <?php endif; ?>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="/?page=home">
                            <i class="fa-solid fa-house me-1"></i> หน้าหลัก
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="/?page=topup">
                            <i class="fa-solid fa-coins me-1"></i> เติมเงิน
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="/?page=home">
                            <i class="fa-solid fa-shopping-basket me-2"></i> ร้านค้า
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="<?= isset($_SESSION['id']) ? '?page=profile&subpage=buyhis' : '?page=login' ?>">
                            <i class="fa-solid fa-clock-rotate-left me-1"></i> ประวัติการซื้อ
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link-xez nav-link dropdown-toggle" href="#" id="contactDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fa-solid fa-phone me-1"></i> ติดต่อ
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end border-0 shadow-sm" style="border-radius: 15px;">
                            <?php if(($config['contact_facebook'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_facebook'] ?>" target="_blank"><i class="fa-brands fa-facebook text-primary me-2"></i> Facebook</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact_line'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_line'] ?>" target="_blank"><i class="fa-brands fa-line text-success me-2"></i> Line Official</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact_discord'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_discord'] ?>" target="_blank"><i class="fa-brands fa-discord text-info me-2"></i> Discord</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact_messenger'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_messenger'] ?>" target="_blank"><i class="fa-brands fa-facebook-messenger text-primary me-2"></i> Messenger</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact_telegram1'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_telegram1'] ?>" target="_blank"><i class="fa-brands fa-telegram text-info me-2"></i> Telegram 1</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact_telegram2'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_telegram2'] ?>" target="_blank"><i class="fa-brands fa-telegram text-info me-2"></i> Telegram 2</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact'] ?? '#') != '#' && ($config['contact_facebook'] ?? '#') == '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact'] ?>" target="_blank"><i class="fa-solid fa-link me-2"></i> ช่องทางอื่นๆ</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="nav-separator mx-3 d-none d-lg-block"></div>
                    <?php if (!isset($_SESSION['id'])): ?>
                        <a href="?page=login" class="nav-link-xez nav-link fw-bold me-3">
                            <i class="fa-solid fa-sign-in me-1"></i> เข้าสู่ระบบ
                        </a>
                        <a href="?page=register" class="btn btn-navbar-register">
                            <i class="fa-solid fa-user-plus me-1"></i> สมัครสมาชิก
                        </a>
                    <?php else: ?>
                        <?php if (($config['chat_status'] ?? 'on') === 'on'): ?>
                        <?php if (($user['rank'] ?? '') == '1'): ?>
                            <a href="?page=admin_chat" id="adminChatBell" class="nav-link position-relative me-2" aria-label="ข้อความแชทใหม่" title="ข้อความแชทใหม่"><i class="fa-solid fa-bell"></i><span id="adminChatBellBadge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">0</span></a>
                            <a href="?page=truemoney_card_requests" id="cardRequestBell" class="nav-link position-relative me-2 text-warning" aria-label="บัตร TrueMoney ใหม่" title="มีคำขอบัตร TrueMoney ใหม่"><i class="fa-solid fa-credit-card"></i><span id="cardRequestBellBadge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">0</span></a>
                        <?php else: ?>
                            <a href="#" id="userChatBell" class="nav-link position-relative me-2" aria-label="ข้อความจากแอดมิน" title="ข้อความจากแอดมิน"><i class="fa-solid fa-bell"></i><span id="userChatBellBadge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">0</span></a>
                            <a href="#" id="userChatNotifyFab" class="user-chat-notify-fab" aria-label="แอดมินตอบแชทแล้ว" title="แอดมินตอบแชทแล้ว"><i class="fa-solid fa-user-tie"></i><span id="userChatNotifyLabel" class="user-chat-notify-label">แอดมินตอบแชท</span><span id="userChatNotifyBadge" class="user-chat-notify-badge d-none">0</span></a>
                        <?php endif; ?>
                        <?php endif; ?>
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle fw-bold" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown">
                                <i class="fa-solid fa-circle-user me-1"></i>
                                <span class="nav-user-summary d-inline-flex align-items-center flex-wrap gap-2">
                                    <span class="nav-user-name"><?= htmlspecialchars($user["username"], ENT_QUOTES, 'UTF-8') ?></span>
                                    <span class="nav-user-balance bg-primary-soft text-xez-primary px-2 py-1 rounded-pill" title="ยอดเงินคงเหลือ">
                                        ยอดเงิน ฿<?= number_format((float) ($user['point'] ?? 0), 2) ?>
                                    </span>
                                </span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0 p-2">
                                <li><a class="dropdown-item rounded-3 mb-1" href="?page=profile"><i
                                            class="fa-solid fa-user me-2"></i> โปรไฟล์</a></li>
                                <li><a class="dropdown-item rounded-3 mb-1" href="?page=profile&subpage=buyhis"><i
                                            class="fa-solid fa-clock-rotate-left me-2"></i> ประวัติการสั่งซื้อ</a></li>
                                <?php if ($user["rank"] == "1"): ?>
                                    <li><a class="dropdown-item text-primary rounded-3 mb-1" href="?page=backend"><i
                                                class="fa-solid fa-shield-halved me-2"></i> จัดการหลังร้าน</a></li>
                                <?php endif; ?>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item text-danger rounded-3" href="?page=logout"><i
                                            class="fa-solid fa-sign-out me-2"></i> ออกจากระบบ</a></li>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <?php
    function admin($user)
    {
        return (isset($_SESSION['id']) && $user["rank"] == "1");
    }

    $page = $_GET['page'] ?? '';
    $backend_pages = ['backend', 'home_menu', 'theme_manage', 'font_manage', 'user_edit', 'category_manage', 'product_manage', 'stock_manage', 'code_manage', 'discount_manage', 'popup_manage', 'notification_manage', 'backend_buy_history', 'backend_topup_history', 'truemoney_card_requests', 'slip_requests', 'admin_password', 'admin_pin', 'website', 'carousel_manage', 'recom_manage', 'crecom_manage', 'apibyshop', 'apibyshop_his', 'slip_manage', 'contact_messages', 'admin_chat'];

    // Require a 6-digit PIN only for rank-1 administrators entering the backend.
    if (isset($_SESSION['id'], $user) && ($user['rank'] ?? '') == '1' && in_array($page, $backend_pages, true) && empty($_SESSION['admin_pin_verified'])) {
        $admin_pin_error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_pin'])) {
            $admin_pin = preg_replace('/\D+/', '', (string) $_POST['admin_pin']);
            if (hash_equals($admin_pin_hash, hash('sha256', $admin_pin))) {
                $_SESSION['admin_pin_verified'] = true;
                header('Location: ?page=backend');
                exit;
            }
            $admin_pin_error = 'รหัส PIN ไม่ถูกต้อง';
        }
        ob_clean();
        ?>
        <!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ยืนยัน PIN Admin</title>
        <style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#08070a;font-family:Arial,sans-serif}.pin-box{width:min(92vw,360px);padding:32px 24px;text-align:center;background:#160d17;color:#fff6df;border:1px solid #6b2145;border-radius:20px;box-shadow:0 15px 50px #000}.pin-box h2{margin:10px 0 8px}.pin-box p{color:#d7c5a5}.pin-input{width:100%;padding:14px 8px;box-sizing:border-box;text-align:center;font-size:28px;letter-spacing:12px;border-radius:10px;border:1px solid #ffb300;background:#08070a;color:#fff;outline:none}.pin-btn{margin-top:18px;width:100%;padding:13px;border:0;border-radius:10px;background:linear-gradient(135deg,#facc15,#f97316);font-weight:bold;font-size:16px;cursor:pointer}.error{color:#ff6b81;margin:12px 0}</style></head><body><main class="pin-box"><div style="font-size:42px">🔒</div><h2>ยืนยันสิทธิ์ Admin</h2><p>กรุณากรอกรหัส PIN 6 หลัก<br>เพื่อเข้าสู่หน้าจัดการหลังบ้าน</p><?php if ($admin_pin_error): ?><div class="error"><?= htmlspecialchars($admin_pin_error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?><form method="post"><input class="pin-input" name="admin_pin" type="password" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" minlength="6" autocomplete="one-time-code" autofocus required><button class="pin-btn" type="submit">เข้าสู่หลังบ้าน</button></form></main></body></html>
<style id="omgvip-effect-color-runtime">
:root{--omg-effect-dark:<?= htmlspecialchars($glow_dark_color, ENT_QUOTES, 'UTF-8') ?>;--omg-effect-light:<?= htmlspecialchars($glow_light_color, ENT_QUOTES, 'UTF-8') ?>}
<?php if (($config['glow_enabled'] ?? 'on') === 'on'): ?>
body:has(.home-hero-banner) .product-card::before,body:has(.home-hero-banner) .cat-card-horizontal::before,body:has(.home-hero-banner) .home-nav-card::before{background:conic-gradient(from 0deg,transparent 0deg,transparent 235deg,var(--omg-effect-dark) 280deg,var(--omg-effect-light) 315deg,var(--omg-effect-dark) 342deg,transparent 360deg)!important;display:block!important}
<?php else: ?>
body:has(.home-hero-banner) .product-card::before,body:has(.home-hero-banner) .product-card::after,body:has(.home-hero-banner) .cat-card-horizontal::before,body:has(.home-hero-banner) .cat-card-horizontal::after,body:has(.home-hero-banner) .home-nav-card::before,body:has(.home-hero-banner) .home-nav-card::after{display:none!important}
<?php endif; ?>
</style>

        <?php
        exit;
    }

    // Backend access is protected by the existing rank-1 administrator session.
    $backend_locked = false;

    if ($page == "" || $page == "landing") {
        // หน้า Landing (http://localhost/)
        require_once('page/landing.php');
    } elseif ($page == "home") {
        // หน้า Home (http://localhost/?page=home)
        require_once('page/simple.php');
    } elseif ($page == "download") {
        require_once('download_page.php');
    } elseif ($page == "login" && !isset($_SESSION['id'])) {
        require_once('page/login.php');
    } elseif ($page == "register" && !isset($_SESSION['id'])) {
        require_once('page/register.php');
    } elseif ($page == "logout" && isset($_SESSION['id'])) {
        session_destroy();
        echo "<script>window.location.href = './';</script>";
    } elseif ($page == "profile" && isset($_SESSION['id'])) {
        require_once('page/profile.php');
    } elseif ($page == "buyhis" && isset($_SESSION['id'])) {
        $_GET['page'] = 'profile';
        $_GET['subpage'] = 'buyhis';
        require_once('page/profile.php');
    } elseif ($page == "topuphis" && isset($_SESSION['id'])) {
        $_GET['page'] = 'profile';
        $_GET['subpage'] = 'topuphis';
        require_once('page/profile.php');
    } elseif ($page == "topup" && isset($_SESSION['id'])) {
        require_once('page/topup.php');
    } elseif ($page == "slip" && isset($_SESSION['id'])) {
        if (($config['topup_slip_status'] ?? 'on') === 'on') {
            require_once('page/slip.php');
        } else {
            echo '<div class="container-sm mt-5"><div class="alert alert-warning text-center">ช่องทางเติมเงินนี้ถูกปิดให้บริการชั่วคราว</div></div>';
        }
    } elseif ($page == "redeem" && isset($_SESSION['id'])) {
        if (($config['topup_redeem_status'] ?? 'on') === 'on') {
            require_once('page/redeem.php');
        } else {
            echo '<div class="container-sm mt-5"><div class="alert alert-warning text-center">ช่องทางเติมเงินนี้ถูกปิดให้บริการชั่วคราว</div></div>';
        }
    } elseif ($page == "vjlive") {
        require_once('page/vjlive.php');
    } elseif ($page == "download") {
        require_once('page/member_download.php');
    } elseif ($page == "shop") {
        require_once('page/shop.php');
    } elseif ($page == "product" && isset($_GET['id'])) {
        require_once('page/product.php');
    } elseif (admin($user) && in_array($page, $backend_pages, true)) {
        require_once('page/backend/menu_manage.php');
    } else {
        require_once('page/landing.php');
    }
    ?>

    <!-- Modal Buy -->
    <div class="modal fade" id="buy_count" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content" style="border-radius: 15px; border: none;">
                <div class="modal-header border-0">
                    <h5 class="modal-title fw-bold" id="modal_title">สั่งซื้อสินค้า</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <!-- ล็อกและซ่อนจำนวนสินค้า: ซื้อได้ครั้งละ 1 ชิ้น -->
                    <input type="hidden" id="b_count" value="1">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="text-muted small">คงเหลือ: <span id="s" class="fw-bold text-dark">0</span>
                            ชิ้น</span>
                        <span class="badge bg-primary px-3 py-2" style="font-size: 1rem;">ราคา <span id="b">0</span>
                            ฿</span>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn xez-btn-cyan w-100" onclick="buybox()">ยืนยันการสั่งซื้อ</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Popup system removed -->

    <style>
        /* Multi-Page Popup Styles */
        .popup-content {
            border-radius: 24px !important;
            border: none !important;
            overflow: hidden;
            background: var(--bg-card);
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.3);
        }

        .popup-slides {
            position: relative;
            overflow: hidden;
        }

        .popup-slide {
            display: none;
            animation: slideIn 0.4s ease;
        }

        .popup-slide.active {
            display: block;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(30px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .popup-image {
            max-height: 200px;
            overflow: hidden;
        }

        .popup-image img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .popup-body {
            padding: 24px;
            text-align: center;
        }

        .popup-badge {
            display: inline-block;
            background: linear-gradient(135deg, var(--xez-primary), var(--xez-secondary));
            color: #fff;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-bottom: 12px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.05);
            }
        }

        .popup-title {
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text-heading);
        }

        .popup-text {
            color: var(--text-body);
            margin-bottom: 0;
        }

        .popup-indicators {
            display: flex;
            justify-content: center;
            gap: 8px;
            padding: 0 24px 16px;
        }

        .indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: var(--border-main);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .indicator.active {
            width: 28px;
            border-radius: 10px;
            background: var(--xez-primary);
        }

        .popup-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 24px;
            background: var(--bg-card-alt);
            border-top: 1px solid var(--border-light);
        }

        .popup-btn {
            background: linear-gradient(135deg, var(--xez-primary), var(--xez-secondary));
            color: #fff;
            border: none;
            padding: 10px 24px;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .popup-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(var(--xez-primary-rgb), 0.4);
            color: #fff;
        }

        /* ปรับกล่องประกาศให้กะทัดรัดบนมือถือ */
        @media (max-width: 576px) {
            #xez_popup .modal-dialog {
                width: calc(100% - 24px);
                max-width: 420px;
                margin: 12px auto;
            }

            #xez_popup .modal-content {
                max-height: 78vh;
                border-radius: 18px !important;
                overflow-y: auto;
            }

            #xez_popup .modal-header {
                padding: 12px 16px;
            }

            #xez_popup .modal-title {
                font-size: 1.15rem;
            }

            #xez_popup img.popup-image {
                width: 100%;
                height: auto !important;
                max-height: none !important;
                object-fit: contain !important;
                display: block;
            }

            #xez_popup .popup-slide > div {
                padding: 16px !important;
            }

            #xez_popup .popup-slide h3 {
                font-size: 1.3rem;
                margin-bottom: 6px;
            }

            #xez_popup .popup-text {
                font-size: 0.95rem;
                line-height: 1.5;
            }

            #xez_popup .popup-footer {
                padding: 12px 16px;
                gap: 10px;
            }

            #xez_popup .popup-btn {
                padding: 8px 16px;
                font-size: 0.95rem;
            }
        }

        @media (max-width: 380px) {
            #xez_popup .modal-content {
                max-height: 82vh;
            }

            #xez_popup img.popup-image {
                height: auto !important;
                max-height: none !important;
            }

            #xez_popup .popup-slide h3 {
                font-size: 1.15rem;
            }
        }

        /* Floating Particles Effect */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
            overflow: hidden;
        }

        .particle {
            position: absolute;
            width: 8px;
            height: 8px;
            background: var(--xez-primary);
            border-radius: 50%;
            opacity: 0.15;
            animation: float 15s infinite;
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(100vh) rotate(0deg);
                opacity: 0;
            }

            10% {
                opacity: 0.15;
            }

            90% {
                opacity: 0.15;
            }

            100% {
                transform: translateY(-100vh) rotate(720deg);
                opacity: 0;
            }
        }
    </style>

    <?php
    // Load active announcements for the homepage popup.
    $popup_rows = dd_q("SELECT * FROM popup_announcements WHERE is_active = 1 ORDER BY show_order ASC, id DESC");
    $popup_items = $popup_rows ? $popup_rows->fetchAll(PDO::FETCH_ASSOC) : [];
    if (!empty($popup_items)):
    ?>
    <div class="modal fade" id="xez_popup" tabindex="-1" aria-labelledby="xez_popup_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content overflow-hidden">
                <div class="modal-header border-0">
                    <h5 class="modal-title popup-title" id="xez_popup_title">
                        <i class="fa-solid fa-bullhorn text-xez-primary me-2"></i>ประกาศจากเว็บไซต์
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
                </div>
                <div class="popup-slides">
                    <?php foreach ($popup_items as $popup_index => $popup): ?>
                        <div class="popup-slide <?= $popup_index === 0 ? 'active' : '' ?>" data-slide="<?= $popup_index + 1 ?>">
                            <?php if (!empty($popup['image_url'])): ?>
                                <img src="<?= htmlspecialchars($popup['image_url'], ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($popup['title'], ENT_QUOTES, 'UTF-8') ?>" class="img-fluid w-100 popup-image">
                            <?php endif; ?>
                            <div class="p-4 p-md-5">
                                <h3 class="popup-title"><?= htmlspecialchars($popup['title'], ENT_QUOTES, 'UTF-8') ?></h3>
                                <p class="popup-text"><?= nl2br(htmlspecialchars($popup['content'] ?? '', ENT_QUOTES, 'UTF-8')) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if (count($popup_items) > 1): ?>
                    <div class="popup-indicators">
                        <?php foreach ($popup_items as $popup_index => $popup): ?>
                            <button type="button" class="indicator <?= $popup_index === 0 ? 'active' : '' ?>" data-target="<?= $popup_index + 1 ?>" aria-label="ประกาศที่ <?= $popup_index + 1 ?>"></button>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <div class="popup-footer">
                    <label class="form-check small mb-0">
                        <input class="form-check-input" type="checkbox" id="dontShowAgain">
                        <span class="form-check-label">ไม่ต้องแสดงอีก 1 ชั่วโมง</span>
                    </label>
                    <button type="button" class="popup-btn" id="popupNextBtn" data-total="<?= count($popup_items) ?>">
                        <span class="btn-text"><?= count($popup_items) > 1 ? 'ถัดไป' : 'ปิด' ?></span>
                        <i class="fa-solid <?= count($popup_items) > 1 ? 'fa-arrow-right' : 'fa-times' ?> ms-2"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script>
        $(document).ready(function () {
            // Only show popup on home page
            const urlParams = new URLSearchParams(window.location.search);
            const currentPage = urlParams.get('page') || 'home';
            let currentSlide = 1;
            const totalSlides = parseInt($('#popupNextBtn').data('total')) || 1;

            if (currentPage === 'home') {
                const popupShown = localStorage.getItem('xez_popup_shown_v2');
                const now = new Date().getTime();
                if (!popupShown || now > parseInt(popupShown)) {
                    setTimeout(() => {
                        if ($('#xez_popup').length) {
                            new bootstrap.Modal('#xez_popup').show();
                        }
                    }, 500);
                }

                // Add floating particles
                createParticles();
            }

            // Popup navigation
            $('#popupNextBtn').click(function () {
                // If only 1 popup or on last slide, close it
                if (totalSlides === 1 || currentSlide >= totalSlides) {
                    // Save preference
                    if ($('#dontShowAgain').is(':checked')) {
                        localStorage.setItem('xez_popup_shown_v2', new Date().getTime() + (3600 * 1000));
                    }
                    bootstrap.Modal.getInstance('#xez_popup').hide();
                } else {
                    // Go to next slide
                    currentSlide++;
                    updateSlide();
                }
            });

            // Indicator clicks
            $('.indicator').click(function () {
                currentSlide = parseInt($(this).data('target'));
                updateSlide();
            });

            function updateSlide() {
                // Update slides
                $('.popup-slide').removeClass('active');
                $(`.popup-slide[data-slide="${currentSlide}"]`).addClass('active');

                // Update indicators
                $('.indicator').removeClass('active');
                $(`.indicator[data-target="${currentSlide}"]`).addClass('active');

                // Update button text
                if (currentSlide === totalSlides) {
                    $('#popupNextBtn .btn-text').text('ปิด');
                    $('#popupNextBtn i').removeClass('fa-arrow-right').addClass('fa-times');
                } else {
                    $('#popupNextBtn .btn-text').text('ถัดไป');
                    $('#popupNextBtn i').removeClass('fa-times').addClass('fa-arrow-right');
                }
            }

            // Create floating particles
            function createParticles() {
                const container = $('<div class="particles"></div>');
                for (let i = 0; i < 15; i++) {
                    const particle = $('<div class="particle"></div>');
                    particle.css({
                        left: Math.random() * 100 + '%',
                        animationDelay: Math.random() * 15 + 's',
                        animationDuration: (15 + Math.random() * 10) + 's',
                        width: (4 + Math.random() * 8) + 'px',
                        height: (4 + Math.random() * 8) + 'px'
                    });
                    container.append(particle);
                }
                $('body').append(container);
            }
        });

        function tobuy(id, name, s, b) {
            $("#modal_title").text(name);
            $("#shop-btn").attr("data-id", id);
            $("#s").text(s);
            $("#b").text(b);
            $("#b_count").val(1);
            new bootstrap.Modal('#buy_count').show();
        }

        function buybox() {
            const formData = new FormData();
            formData.append('id', $("#shop-btn").attr("data-id"));
            formData.append('count', 1);
            Swal.fire({
                title: 'ยืนยันการสั่งซื้อ?',
                text: "คุณต้องการสั่งซื้อสินค้านี้ใช่หรือไม่",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'ซื้อเลย',
                cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: 'POST',
                        url: 'system/buybox.php',
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function (res) {
                            if (res.status == "success") {
                                Swal.fire('สำเร็จ', res.message, 'success').then(() => window.location.reload());
                            } else {
                                Swal.fire('ล้มเหลว', res.message, 'error');
                            }
                        }
                    });
                }
            });
        }
        AOS.init();

        // Real-time login monitor: refresh the server-side activity timestamp
        // and detect an expired/replaced session without waiting for a click.
        <?php if (isset($_SESSION['id'])): ?>
        (function () {
            let sessionAlertShown = false;
            let authFailures = 0;
            let lastInteraction = Date.now();
            let lastTouchSent = 0;
            let warningShown = false;
            const IDLE_LIMIT = 10 * 60 * 1000;
            const WARNING_AT = 8 * 60 * 1000;
            async function checkLoginStatus(touch = false) {
                try {
                    const response = await fetch('system/session_status.php?touch=' + (touch ? '1' : '0') + '&_=' + Date.now(), {
                        method: 'GET',
                        credentials: 'same-origin',
                        cache: 'no-store',
                        headers: {'X-Requested-With': 'XMLHttpRequest'}
                    });
                    const result = await response.json();
                    if (!response.ok || !result.logged_in) {
                        authFailures++;
                        // Shared hosting can briefly return an incomplete
                        // response. Require several consecutive failures.
                        if (authFailures < 3) return;
                        if (sessionAlertShown) return;
                        sessionAlertShown = true;
                        Swal.fire({
                            icon: 'warning',
                            title: 'เซสชันสิ้นสุดแล้ว',
                            text: result.message || 'กรุณาเข้าสู่ระบบใหม่',
                            confirmButtonText: 'เข้าสู่ระบบใหม่',
                            allowOutsideClick: false
                        }).then(() => { window.location.href = '?page=login'; });
                    } else {
                        authFailures = 0;
                        if (touch) lastTouchSent = Date.now();
                    }
                } catch (error) {
                    // Do not log the user out on a temporary network failure.
                    console.debug('Login heartbeat temporarily unavailable');
                }
            }
            function recordActivity() {
                lastInteraction = Date.now();
                if (warningShown) {
                    warningShown = false;
                    if (typeof Swal !== 'undefined') Swal.close();
                }
                if (Date.now() - lastTouchSent > 15000) checkLoginStatus(true);
            }
            ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'].forEach((eventName) => {
                window.addEventListener(eventName, recordActivity, {passive: true});
            });
            function showTimeoutWarning() {
                if (warningShown || sessionAlertShown) return;
                warningShown = true;
                const remaining = Math.max(0, Math.ceil((IDLE_LIMIT - (Date.now() - lastInteraction)) / 1000));
                Swal.fire({
                    icon: 'warning',
                    title: 'ใกล้หมดเวลาเซสชัน',
                    text: 'ไม่มีการใช้งาน ระบบจะออกจากระบบในประมาณ ' + Math.ceil(remaining / 60) + ' นาที',
                    confirmButtonText: 'ใช้งานต่อ',
                    showCancelButton: true,
                    cancelButtonText: 'ออกจากระบบ',
                    allowOutsideClick: false
                }).then((result) => {
                    if (result.isConfirmed) recordActivity();
                    else if (result.dismiss === Swal.DismissReason.cancel) window.location.href = '?page=logout';
                });
            }
            checkLoginStatus(false);
            setInterval(() => {
                const idle = Date.now() - lastInteraction;
                if (idle >= WARNING_AT && idle < IDLE_LIMIT) showTimeoutWarning();
                checkLoginStatus(false);
            }, 30000);
        })();
        <?php endif; ?>
    </script>

    <!-- Floating contact admin button -->
    <?php if (($config['chat_status'] ?? 'on') === 'on' && $page !== 'backend' && $page !== 'contact_messages' && $page !== 'admin_chat'): ?>
    <button type="button" id="contactAdminFab" aria-label="แชทกับแอดมิน"><i class="fa-solid fa-headset"></i><span>แชทกับแอดมิน</span><b id="contactAdminBadge" class="contact-admin-badge d-none">0</b></button>
    <div class="modal fade" id="contactAdminModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered"><div class="modal-content">
            <div class="modal-header chat-modal-header"><div class="chat-admin-title"><span class="chat-admin-avatar"><i class="fa-solid fa-user-tie"></i></span><span><strong>แชทกับแอดมิน</strong><small id="adminChatStatus">พร้อมให้บริการ</small></span></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <?php if (!isset($_SESSION['id'])): ?>
            <div class="modal-body text-center py-4"><i class="fa-solid fa-lock fs-1 text-warning mb-3"></i><p class="mb-3">กรุณาเข้าสู่ระบบก่อนจึงจะส่งข้อความถึงแอดมินได้</p><a class="btn btn-primary" href="?page=login">เข้าสู่ระบบ</a></div>
            <?php else: ?>
            <div class="modal-body chat-modal-body"><div class="chat-reply-banner"><i class="fa-solid fa-bolt"></i><span>เมื่อแอดมินตอบกลับ จะแจ้งเตือนที่ไอคอนและปุ่มแชท</span></div><div id="adminChatMessages" class="chat-messages-box"><div class="text-center text-muted small">กำลังโหลดแชท...</div></div></div>
            <form id="adminChatForm" class="chat-composer"><div class="modal-footer"><input class="form-control" name="message" maxlength="3000" placeholder="พิมพ์ข้อความถึงแอดมิน..." required><button class="btn btn-primary" type="submit"><i class="fa-solid fa-paper-plane"></i><span>ส่ง</span></button></div></form>
            <?php endif; ?>
        </div></div>
    </div>
    <style>#contactAdminFab{position:fixed;left:14px;bottom:18px;z-index:2147483000;border:0;border-radius:999px;padding:10px 15px;background:linear-gradient(135deg,#ffb300,#ff6b35);color:#fff;font-weight:700;box-shadow:0 8px 22px rgba(0,0,0,.28);display:flex;align-items:center;gap:8px;cursor:pointer}#contactAdminFab:hover{transform:translateY(-2px)}#contactAdminModal{z-index:2147483001}#contactAdminModal.modal.show{display:block;background:rgba(0,0,0,.45)}@media(max-width:480px){#contactAdminFab{padding:11px;width:48px;height:48px;justify-content:center}#contactAdminFab span{display:none}}</style>
    <script>(function(){function ready(fn){if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',fn);else fn();}ready(function(){var fab=document.getElementById('contactAdminFab'),modalEl=document.getElementById('contactAdminModal'),form=document.getElementById('adminChatForm'),box=document.getElementById('adminChatMessages'),api='index.php?page=admin_chat_api';if(!fab||!modalEl)return;function loadChat(){if(!box)return;fetch(api,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(r){if(r.login_required){location.href='?page=login';return;}box.innerHTML='';(r.messages||[]).forEach(function(m){var row=document.createElement('div');row.className='d-flex mb-2 '+(m.sender==='user'?'justify-content-end':'justify-content-start');var bubble=document.createElement('div');bubble.className='p-2 rounded-3 '+(m.sender==='user'?'bg-primary text-white':'bg-white border');bubble.style.cssText='max-width:80%;white-space:pre-wrap';bubble.textContent=m.message;var time=document.createElement('small');time.className='d-block opacity-75';time.textContent=m.created_at;bubble.appendChild(time);row.appendChild(bubble);box.appendChild(row);});box.scrollTop=box.scrollHeight;}).catch(function(){box.innerHTML='<div class="text-center text-danger small">โหลดแชทไม่สำเร็จ</div>';});}function openChat(){modalEl.classList.add('show');modalEl.setAttribute('aria-hidden','false');document.body.classList.add('modal-open');loadChat();}function closeChat(){modalEl.classList.remove('show');modalEl.setAttribute('aria-hidden','true');document.body.classList.remove('modal-open');}fab.addEventListener('click',openChat);modalEl.querySelectorAll('[data-bs-dismiss="modal"],.btn-close').forEach(function(b){b.addEventListener('click',closeChat);});if(form)form.addEventListener('submit',function(e){e.preventDefault();var btn=form.querySelector('button[type=submit]');btn.disabled=true;fetch(api,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(new FormData(form))}).then(function(r){return r.json();}).then(function(r){if(r.login_required){location.href='?page=login';return;}if(!r.ok){alert(r.message);return;}form.reset();loadChat();}).catch(function(){alert('ไม่สามารถส่งข้อความได้');}).finally(function(){btn.disabled=false;});});});})();</script>
    <?php endif; ?>

    <!-- Footer Section -->
    <?php if ($page != "" && $page != "landing"): ?>
        <footer class="site-footer" id="contact-section">
            <div class="container">
                <div class="row g-4">
                    <!-- Logo & Description -->
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-brand">
                            <img src="<?= htmlspecialchars($site_logo, ENT_QUOTES, 'UTF-8') ?>" alt="Logo" class="footer-logo">
                            <h4 class="footer-title">
                                <?= $config['name'] ?>
                            </h4>
                            <p class="footer-desc">
                                <?= $config['des'] ?>
                            </p>
                        </div>
                    </div>

                    <!-- Menu Links -->
                    <div class="col-lg-2 col-md-6">
                        <h5 class="footer-heading">เมนูหลัก</h5>
                        <ul class="footer-links">
                            <li><a href="?page=home"><i class="fa-solid fa-home me-2"></i>หน้าหลัก</a></li>
                            <li><a href="?page=shop"><i class="fa-solid fa-shopping-bag me-2"></i>สินค้า</a></li>
                            <li><a href="?page=topup"><i class="fa-solid fa-wallet me-2"></i>เติมเงิน</a></li>
                            <li><a href="?page=login"><i class="fa-solid fa-sign-in me-2"></i>เข้าสู่ระบบ</a></li>
                        </ul>
                    </div>

                    <!-- History Links -->
                    <div class="col-lg-2 col-md-6">
                        <h5 class="footer-heading">ประวัติต่างๆ</h5>
                        <ul class="footer-links">
                            <li><a href="?page=profile&subpage=buyhis"><i class="fa-solid fa-history me-2"></i>ประวัติซื้อสินค้า</a></li>
                            <li><a href="?page=profile&subpage=topuphis"><i class="fa-solid fa-receipt me-2"></i>ประวัติเติมเงิน</a></li>
                        </ul>
                    </div>

                    <!-- Social Widgets -->
                    <div class="col-lg-4 col-md-6">
                        <h5 class="footer-heading">ติดตามเรา</h5>
                        <div class="social-widgets d-flex gap-2 mb-3">
                            <?php if(($config['contact_facebook'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_facebook'] ?>" class="btn btn-primary btn-sm rounded-circle" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-facebook"></i></a>
                            <?php endif; ?>
                            <?php if(($config['contact_line'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_line'] ?>" class="btn btn-success btn-sm rounded-circle" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-line"></i></a>
                            <?php endif; ?>
                            <?php if(($config['contact_discord'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_discord'] ?>" class="btn btn-info btn-sm rounded-circle text-white" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-discord"></i></a>
                            <?php endif; ?>
                            <?php if(($config['contact_messenger'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_messenger'] ?>" class="btn btn-primary btn-sm rounded-circle" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-facebook-messenger"></i></a>
                            <?php endif; ?>
                            <?php if(($config['contact_telegram1'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_telegram1'] ?>" class="btn btn-info btn-sm rounded-circle text-white" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-telegram"></i></a>
                            <?php endif; ?>
                            <?php if(($config['contact_telegram2'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_telegram2'] ?>" class="btn btn-info btn-sm rounded-circle text-white" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-telegram"></i></a>
                            <?php endif; ?>
                        </div>
                        <?php if(($config['discord_widget_status'] ?? 'off') === 'on' && ($config['discord_server'] ?? '') != ''): ?>
                        <div class="widget-content">
                            <iframe src="https://discord.com/widget?id=<?= $config['discord_server'] ?>&theme=dark"
                                width="100%" height="400" allowtransparency="true" frameborder="0"
                                sandbox="allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"></iframe>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            </div>

            <!-- Copyright -->
            <div class="footer-bottom">
                <p>&copy;
                    <?= date('Y') ?>
                    <?= $config['name'] ?>. All rights reserved.
                </p>
                <p class="small opacity-75">Powered by OMGVIPSHOP</p>
            </div>
            </div>
        </footer>
    <?php endif; ?>

    <style>
        /* Footer Styles */
        .site-footer {
            background: linear-gradient(135deg, var(--xez-primary) 0%, var(--xez-secondary) 100%);
            padding: 60px 0 30px;
            margin-top: 60px;
            color: #fff;
        }

        .footer-brand .footer-logo {
            width: 80px;
            height: 80px;
            object-fit: contain;
            margin-bottom: 15px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .footer-title {
            font-weight: 700;
            color: #fff;
            margin-bottom: 10px;
        }

        .footer-desc {
            color: #94a3b8;
            font-size: 0.9rem;
            line-height: 1.6;
        }

        .footer-heading {
            color: var(--xez-primary);
            font-weight: 600;
            margin-bottom: 20px;
            font-size: 1rem;
        }

        .footer-links {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: #94a3b8;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .footer-links a:hover {
            color: var(--xez-primary);
            padding-left: 5px;
        }

        .widget-box {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            overflow: hidden;
            margin-bottom: 15px;
        }

        .widget-header {
            background: linear-gradient(135deg, #5865F2, #7289da);
            padding: 10px 15px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .widget-header i {
            font-size: 1.2rem;
        }

        .widget-content iframe {
            display: block;
        }

        .footer-bottom {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            margin-top: 40px;
            padding-top: 30px;
            text-align: center;
            color: #64748b;
        }

        .footer-bottom p {
            margin: 5px 0;
        }
    </style>
    <script>
        AOS.init({
            duration: 800,
            once: true
        });

        // Optimized Preloader Logic
        (function () {
            const preloader = document.getElementById('preloader');
            const progress = document.querySelector('.loader-progress');

            // Initial progress animation
            if (progress) {
                setTimeout(() => progress.style.width = '30%', 100);
                setTimeout(() => progress.style.width = '70%', 500);
            }

            function hidePreloader() {
                if (!preloader || preloader.style.display === 'none') return;

                if (progress) progress.style.width = '100%';

                setTimeout(() => {
                    preloader.classList.add('fade-out');
                    setTimeout(() => {
                        preloader.style.display = 'none';
                    }, 400);
                }, 200);
            }

            // Hide when loaded or after a safe timeout
            window.addEventListener('load', hidePreloader);
            setTimeout(hidePreloader, 1000); // 2.5s absolute maximum wait
        })();
    </script>

<?php if (($config['chat_status'] ?? 'on') === 'on' && ($user['rank'] ?? '') == '1'): ?>
<script>(function(){var bell=document.getElementById('adminChatBell'),badge=document.getElementById('adminChatBellBadge'),last=0;if(!bell||!badge)return;function check(){fetch('index.php?page=admin_chat_unread',{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(x){if(!x.ok)return;var n=parseInt(x.unread||0,10);badge.textContent=n>99?'99+':n;badge.classList.toggle('d-none',n<1);if(n>last&&last>0){bell.classList.add('text-danger');setTimeout(function(){bell.classList.remove('text-danger')},1800);}last=n;}).catch(function(){});}check();setInterval(check,10000);})();</script>
<script>(function(){var bell=document.getElementById('cardRequestBell'),badge=document.getElementById('cardRequestBellBadge'),last=0;if(!bell||!badge)return;function check(){fetch('index.php?page=truemoney_card_unread',{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(x){if(!x.ok)return;var n=parseInt(x.pending||0,10);badge.textContent=n>99?'99+':n;badge.classList.toggle('d-none',n<1);if(n>last&&last>0){bell.classList.add('text-danger');setTimeout(function(){bell.classList.remove('text-danger')},2200);}last=n;}).catch(function(){});}check();setInterval(check,10000);})();</script>
<?php else: ?>
<script>(function(){var bell=document.getElementById('userChatBell'),badge=document.getElementById('userChatBellBadge'),notify=document.getElementById('userChatNotifyFab'),notifyBadge=document.getElementById('userChatNotifyBadge'),fabBadge=document.getElementById('contactAdminBadge'),last=0;if(!bell||!badge)return;function openChat(e){if(e)e.preventDefault();var fab=document.getElementById('contactAdminFab');if(fab)fab.click();else location.href='?page=home';}bell.addEventListener('click',openChat);if(notify)notify.addEventListener('click',openChat);function check(){fetch('index.php?page=user_chat_unread',{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(x){if(!x.ok)return;var n=parseInt(x.unread||0,10),label=n>99?'99+':n;badge.textContent=label;badge.classList.toggle('d-none',n<1);bell.classList.toggle('chat-reply-unread',n>0);bell.setAttribute('aria-label',n>0?'แอดมินตอบแชทแล้ว '+label+' ข้อความ':'ข้อความจากแอดมิน');if(notifyBadge){notifyBadge.textContent=label;notifyBadge.classList.toggle('d-none',n<1);}if(fabBadge){fabBadge.textContent=label;fabBadge.classList.toggle('d-none',n<1);}if(n>last&&last>0){bell.classList.add('text-danger');if(notify)notify.classList.add('is-new');setTimeout(function(){bell.classList.remove('text-danger');if(notify)notify.classList.remove('is-new')},2200);}last=n;}).catch(function(){});}check();setInterval(check,10000);})();</script>
<?php endif; ?>
<script>
(function(){var timeout=300000,timer;function reset(){clearTimeout(timer);timer=setTimeout(function(){window.location.href='?page=login&timeout=1';},timeout);}['click','mousemove','keydown','scroll','touchstart','input'].forEach(function(e){document.addEventListener(e,reset,{passive:true});});reset();})();
</script>
</body>

</html>
<style>
/* OMGVIP black-red theme */
:root{--omg-red:#e50914;--omg-red-dark:#8b0000;--omg-red-soft:#ff3340;--omg-black:#070707;--omg-panel:#141414;--omg-panel-2:#1d1011;--omg-border:#4a171b;--omg-text:#f7f7f7;--omg-muted:#a7a7a7}
html,body{background:radial-gradient(circle at 50% -12%,#3b0b10 0,#0a0809 42%,#030303 100%)!important;color:var(--omg-text)!important}
body{background-color:var(--omg-black)!important}
.navbar,.main-navbar,header{background:linear-gradient(90deg,#090909,#260b0e 50%,#090909)!important;border-bottom:1px solid var(--omg-red)!important}
.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:linear-gradient(145deg,#211112,#0f0f0f)!important;border:1px solid var(--omg-border)!important;border-radius:16px!important;box-shadow:0 16px 36px rgba(0,0,0,.38)!important}
.card:hover,.product-card:hover,.category-card:hover{border-color:#8f2028!important;box-shadow:0 0 24px rgba(229,9,20,.16)!important}
.btn,.btn-primary,.btn-success,.button-primary,.bg-main{background:linear-gradient(135deg,#e50914,#8b0000)!important;border-color:#ff3340!important;color:#fff!important;border-radius:10px!important}
.btn:hover,.btn-primary:hover,.btn-success:hover{background:linear-gradient(135deg,#ff3340,#b30000)!important;filter:brightness(1.08)}
.btn-secondary,.btn-outline-primary,.btn-outline-danger{background:#171010!important;border-color:#a51d27!important;color:#ff6970!important}
.btn-warning{background:linear-gradient(135deg,#e50914,#8b0000)!important;color:#fff!important;border-color:#ff3340!important}
.btn-danger{background:#b30000!important;border-color:#ff3340!important}
.form-control,.form-select,textarea,input{background:#121212!important;color:#fff!important;border:1px solid #552024!important;border-radius:9px!important}
.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:#e50914!important;box-shadow:0 0 0 .2rem rgba(229,9,20,.2)!important}
a{color:#ff6970!important}a:hover{color:#ffb0b4!important}h1,h2,h3,h4,h5,h6{color:#fff!important;text-shadow:0 0 16px rgba(229,9,20,.22)}
.badge,.hot,.tag{background:#e50914!important;color:#fff!important;border-color:#ff3340!important}
.alert,.toast,.latest-order-notification,.order-notification,.purchase-notification,.recent-order-toast{background:linear-gradient(135deg,#241012,#120c0d)!important;color:#fff!important;border:1px solid #7d2028!important;border-radius:14px!important}
.table{color:#eee!important}.table thead{background:#211012!important}.table tbody tr{border-color:#3e191c!important}.table tbody tr:hover{background:rgba(229,9,20,.08)!important}
footer{background:#050505!important;border-top:1px solid #4a171b!important}
.omg-order-toggle{background:#160c0d!important;border-color:#7d2028!important}.omg-order-toggle i{background:#e50914!important;box-shadow:0 0 10px #e50914!important}
@media(max-width:600px){.card,.product-card,.category-card{border-radius:13px!important}}

</style>
<style>
/* OMGVIP modern premium layer */
:root{--modern-red:#ef233c;--modern-red-2:#b7091b;--modern-bg:#070708;--modern-surface:rgba(22,18,20,.82);--modern-surface-2:#171214;--modern-border:rgba(255,82,99,.24);--modern-text:#f8fafc;--modern-muted:#a9a3a6}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif!important;letter-spacing:.005em!important;background:radial-gradient(900px 480px at 50% -80px,rgba(239,35,60,.22),transparent 62%),linear-gradient(180deg,#0b0809 0,#050505 55%,#020202 100%)!important;color:var(--modern-text)!important}body:before{content:"";position:fixed;inset:0;pointer-events:none;opacity:.18;background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);background-size:34px 34px;mask-image:linear-gradient(to bottom,#000,transparent 80%);z-index:-1}.navbar,.main-navbar,header{background:rgba(7,7,8,.78)!important;backdrop-filter:blur(18px) saturate(140%);-webkit-backdrop-filter:blur(18px) saturate(140%);border-bottom:1px solid rgba(239,35,60,.32)!important;box-shadow:0 8px 30px rgba(0,0,0,.22)!important}.navbar-brand,.navbar a{font-weight:600}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:linear-gradient(145deg,rgba(35,22,25,.92),rgba(12,11,12,.94))!important;border:1px solid var(--modern-border)!important;border-radius:20px!important;box-shadow:0 18px 50px rgba(0,0,0,.32),inset 0 1px rgba(255,255,255,.035)!important;transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease!important}.card:hover,.product-card:hover,.category-card:hover,.shop-card:hover{transform:translateY(-3px);border-color:rgba(239,35,60,.6)!important;box-shadow:0 22px 56px rgba(0,0,0,.42),0 0 28px rgba(239,35,60,.1)!important}.btn,.btn-primary,.btn-success,.button-primary,.bg-main{font-weight:700!important;letter-spacing:.01em;background:linear-gradient(135deg,var(--modern-red),var(--modern-red-2))!important;border:1px solid rgba(255,116,126,.6)!important;border-radius:12px!important;box-shadow:0 8px 18px rgba(183,9,27,.22)!important;transition:transform .18s ease,filter .18s ease,box-shadow .18s ease!important}.btn:hover,.btn-primary:hover,.btn-success:hover{filter:brightness(1.12);transform:translateY(-2px);box-shadow:0 12px 24px rgba(183,9,27,.35)!important}.form-control,.form-select,textarea,input{background:rgba(14,13,14,.9)!important;color:#fff!important;border:1px solid rgba(255,255,255,.12)!important;border-radius:12px!important;padding-top:.7rem!important;padding-bottom:.7rem!important}.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:var(--modern-red)!important;box-shadow:0 0 0 4px rgba(239,35,60,.12)!important}.badge,.hot,.tag{border-radius:999px!important;padding:.45em .75em!important;background:linear-gradient(135deg,var(--modern-red),var(--modern-red-2))!important;color:#fff!important}.table{--bs-table-bg:transparent!important;color:#f4f4f5!important}.table thead{background:rgba(239,35,60,.1)!important}.table tbody tr{border-color:rgba(255,255,255,.08)!important}.table tbody tr:hover{background:rgba(239,35,60,.08)!important}.alert,.toast,.latest-order-notification,.order-notification,.purchase-notification,.recent-order-toast{border-radius:16px!important;background:linear-gradient(135deg,rgba(42,16,20,.96),rgba(15,11,12,.96))!important;border:1px solid rgba(239,35,60,.42)!important;box-shadow:0 16px 40px rgba(0,0,0,.35)!important}footer{background:#030303!important;border-top:1px solid rgba(239,35,60,.25)!important;color:var(--modern-muted)!important}.omg-order-toggle{backdrop-filter:blur(14px);background:rgba(25,10,12,.86)!important;border-color:rgba(239,35,60,.5)!important;border-radius:999px!important;box-shadow:0 12px 30px rgba(0,0,0,.35)!important}@media(max-width:768px){.container,.container-fluid{padding-left:16px!important;padding-right:16px!important}.card,.product-card,.category-card,.feature-card,.shop-card{border-radius:16px!important}.btn{min-height:44px}.navbar{padding-top:.65rem!important;padding-bottom:.65rem!important}}
</style>
<style>
/* OMGVIP performance layer */
html{scroll-behavior:auto!important}body:before{display:none!important}.navbar,.main-navbar,header{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{transition:none!important;box-shadow:0 10px 24px rgba(0,0,0,.24)!important}.card:hover,.product-card:hover,.category-card:hover,.shop-card:hover{transform:none!important;box-shadow:0 12px 28px rgba(0,0,0,.3)!important}.btn,.btn-primary,.btn-success,.button-primary,.bg-main{transition:filter .12s ease!important;box-shadow:0 5px 12px rgba(183,9,27,.18)!important}.btn:hover,.btn-primary:hover,.btn-success:hover{transform:none!important}.omg-order-toggle{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}img{content-visibility:auto;image-rendering:auto}iframe{loading:lazy} @media(max-width:768px){body{background:#050505!important}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{box-shadow:0 6px 16px rgba(0,0,0,.24)!important}.navbar,.main-navbar,header{background:#090708!important}} @media(prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important;scroll-behavior:auto!important}}
</style>
<style>
/* OMGVIP ruby wine palette */
:root{--ruby:#d81b45;--ruby-deep:#831b36;--wine:#260d18;--wine-2:#3a1423;--rose:#f08b9e;--gold:#e6b873;--ink:#080609;--surface:#171016;--line:rgba(240,139,158,.24)}
body{background:radial-gradient(900px 420px at 50% -100px,rgba(216,27,69,.22),transparent 65%),linear-gradient(180deg,#120a0f 0,#070608 55%,#030304 100%)!important;color:#fbf4f6!important}.navbar,.main-navbar,header{background:rgba(13,7,11,.94)!important;border-bottom-color:rgba(216,27,69,.55)!important}.navbar-brand,.navbar a{color:#fff!important}.navbar a:hover{color:var(--rose)!important}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:linear-gradient(145deg,rgba(58,20,35,.9),rgba(16,10,15,.96))!important;border-color:var(--line)!important}.card:hover,.product-card:hover,.category-card:hover,.shop-card:hover{border-color:rgba(240,139,158,.6)!important;box-shadow:0 12px 28px rgba(216,27,69,.18)!important}.btn,.btn-primary,.btn-success,.button-primary,.bg-main{background:linear-gradient(135deg,var(--ruby),var(--ruby-deep))!important;border-color:#f08b9e!important;color:#fff!important}.btn:hover,.btn-primary:hover,.btn-success:hover{background:linear-gradient(135deg,#ed4066,#a62248)!important}.btn-secondary,.btn-outline-primary,.btn-outline-danger{background:#21121a!important;border-color:#9e3654!important;color:#f08b9e!important}.btn-warning{background:linear-gradient(135deg,#c91843,#7e1733)!important;color:#fff!important;border-color:#f08b9e!important}.form-control,.form-select,textarea,input{background:#110b10!important;color:#fff!important;border-color:#5f263c!important}.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:var(--rose)!important;box-shadow:0 0 0 4px rgba(216,27,69,.14)!important}.badge,.hot,.tag{background:linear-gradient(135deg,var(--ruby),var(--ruby-deep))!important;color:#fff!important}.alert,.toast,.latest-order-notification,.order-notification,.purchase-notification,.recent-order-toast{background:linear-gradient(135deg,#351421,#160b12)!important;border-color:#963650!important;color:#fff!important}.table thead{background:rgba(216,27,69,.13)!important}.table tbody tr:hover{background:rgba(216,27,69,.08)!important}h1,h2,h3,h4,h5,h6{color:#fff!important}footer{background:#050406!important;border-top-color:rgba(216,27,69,.38)!important}.omg-order-toggle{background:rgba(38,13,24,.94)!important;border-color:#9e3654!important}.omg-order-toggle i{background:var(--ruby)!important;box-shadow:0 0 10px rgba(216,27,69,.65)!important}.admin-chat-page .col-lg-8 h5+div .bg-primary{background:linear-gradient(135deg,#d81b45,#831b36)!important;border-color:#f08b9e!important}.admin-chat-page .col-lg-8 form .btn{background:linear-gradient(135deg,#d81b45,#831b36)!important}
</style>

<style id="admin-theme-overrides">
:root{--admin-main:<?= htmlspecialchars($brand_main_color, ENT_QUOTES, 'UTF-8') ?>;--admin-secondary:<?= htmlspecialchars($brand_secondary_color, ENT_QUOTES, 'UTF-8') ?>;--admin-border:<?= htmlspecialchars($brand_border_color, ENT_QUOTES, 'UTF-8') ?>;--admin-text:<?= htmlspecialchars($theme_colors['text_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-bg:<?= htmlspecialchars($theme_colors['bg_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-card:<?= htmlspecialchars($theme_colors['card_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-button:<?= htmlspecialchars($theme_colors['button_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-success:<?= htmlspecialchars($theme_colors['success_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-warning:<?= htmlspecialchars($theme_colors['warning_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-danger:<?= htmlspecialchars($theme_colors['danger_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-info:<?= htmlspecialchars($theme_colors['info_color'], ENT_QUOTES, 'UTF-8') ?>}
body{background:var(--admin-bg)!important;color:var(--admin-text)!important}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:var(--admin-card)!important;border-color:var(--admin-border)!important}.btn,.btn-primary,.button-primary,.bg-main{background:var(--admin-button)!important;border-color:var(--admin-border)!important}.btn-success{background:var(--admin-success)!important}.btn-warning{background:var(--admin-warning)!important}.btn-danger{background:var(--admin-danger)!important}.alert-info{border-color:var(--admin-info)!important}.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:var(--admin-main)!important;box-shadow:0 0 0 .2rem color-mix(in srgb,var(--admin-main) 20%,transparent)!important}a{color:var(--admin-main)!important}.badge{background:var(--admin-main)!important}
/* OMGVIP admin dynamic theme */
</style>

<?php $glow_speed = max(1, min(10, (int)($config['glow_speed'] ?? 5))); $glow_duration = number_format(3.8 - (($glow_speed - 1) * 0.28), 2, '.', ''); ?>
<style id="glow-settings-runtime">.product-card::before,.category-card::before,.shop-card::before,.card.product-card::before,.card.category-card::before,.card.shop-card::before,.product-card::after,.category-card::after,.shop-card::after,.card.product-card::after,.card.category-card::after,.card.shop-card::after{animation-duration:<?= $glow_duration ?>s!important}<?php if (($config['glow_enabled'] ?? 'on') !== 'on'): ?>.product-card::before,.category-card::before,.shop-card::before,.card.product-card::before,.card.category-card::before,.card.shop-card::before,.product-card::after,.category-card::after,.shop-card::after,.card.product-card::after,.card.category-card::after,.card.shop-card::after{display:none!important}<?php endif; ?></style>
<?php $rain_density = max(20, min(130, (int)($config['rain_density'] ?? 70))); ?>
<?php $rain_white_color = preg_match('/^#[0-9a-fA-F]{6}$/', (string)($config['rain_white_color'] ?? '')) ? $config['rain_white_color'] : '#ffffff'; ?>
<?php $rain_gray_color = preg_match('/^#[0-9a-fA-F]{6}$/', (string)($config['rain_gray_color'] ?? '')) ? $config['rain_gray_color'] : '#aeb2b8'; ?>
<?php $glow_dark_color = preg_match('/^#[0-9a-fA-F]{6}$/', (string)($config['glow_dark_color'] ?? '')) ? $config['glow_dark_color'] : '#34363a'; ?>
<?php $glow_light_color = preg_match('/^#[0-9a-fA-F]{6}$/', (string)($config['glow_light_color'] ?? '')) ? $config['glow_light_color'] : '#ffffff'; ?>
<?php if (($config['rain_enabled'] ?? 'on') === 'on'): ?>
<!-- เอฟเฟกต์ฝนตก -->
<canvas id="rainCanvas" aria-hidden="true"></canvas>
<style>
#rainCanvas{position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:9999;opacity:.82;mix-blend-mode:normal}
@media(prefers-reduced-motion:reduce){#rainCanvas{display:none}}
</style>
<script>
(function(){
  const canvas=document.getElementById('rainCanvas');
  if(!canvas)return;
  const ctx=canvas.getContext('2d');
  let drops=[],width=0,height=0,dpr=1;
  function resizeCanvas(){
    dpr=Math.min(window.devicePixelRatio||1,2);
    width=window.innerWidth;height=window.innerHeight;
    canvas.width=Math.floor(width*dpr);canvas.height=Math.floor(height*dpr);
    canvas.style.width=width+'px';canvas.style.height=height+'px';
    ctx.setTransform(dpr,0,0,dpr,0,0);
    createRain();
  }
  function createRain(){
    drops=[];
    const amount=<?= $rain_density ?>;
    for(let i=0;i<amount;i++)drops.push({
      x:Math.random()*width,y:Math.random()*height,
      length:Math.random()*45+15,speed:Math.random()*4+3,
      opacity:Math.random()*.55+.35,width:Math.random()*1.6+.7,tone:Math.random()<.5?'white':'gray'
    });
  }
  function drawRain(){
    ctx.clearRect(0,0,width,height);
    ctx.shadowBlur=0;
    for(const drop of drops){
      ctx.beginPath();ctx.moveTo(drop.x,drop.y);ctx.lineTo(drop.x-1,drop.y+drop.length);
      ctx.strokeStyle=drop.tone==='gray'?'rgba(174,178,183,'+drop.opacity+')':'rgba(255,255,255,'+drop.opacity+')';ctx.lineWidth=drop.width;ctx.stroke();
      drop.y+=drop.speed;
      if(drop.y>height+drop.length){drop.y=-drop.length;drop.x=Math.random()*width;}
    }
    requestAnimationFrame(drawRain);
  }
  let resizeTimer;window.addEventListener('resize',function(){clearTimeout(resizeTimer);resizeTimer=setTimeout(resizeCanvas,120)});
  resizeCanvas();drawRain();
})();
</script>
<?php endif; ?>

<style>
/* OMGVIP modern ocean blue theme */
:root{--ocean:#168cff;--ocean-deep:#075bd8;--cyan:#27d7ff;--navy:#071322;--navy-2:#0d1d32;--blue-line:rgba(39,215,255,.28);--blue-text:#e8f7ff}
body{background:radial-gradient(900px 440px at 50% -100px,rgba(22,140,255,.25),transparent 65%),linear-gradient(180deg,#071322 0,#04080f 58%,#020407 100%)!important;color:var(--blue-text)!important}.navbar,.main-navbar,header{background:rgba(4,12,24,.94)!important;border-bottom-color:rgba(39,215,255,.48)!important}.navbar-brand,.navbar a{color:#f3fbff!important}.navbar a:hover{color:var(--cyan)!important}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:linear-gradient(145deg,rgba(13,39,68,.92),rgba(5,14,27,.97))!important;border-color:var(--blue-line)!important}.card:hover,.product-card:hover,.category-card:hover,.shop-card:hover{border-color:rgba(39,215,255,.65)!important;box-shadow:0 14px 32px rgba(22,140,255,.2)!important}.btn,.btn-primary,.btn-success,.button-primary,.bg-main{background:linear-gradient(135deg,var(--ocean),var(--ocean-deep))!important;border-color:#67e5ff!important;color:#fff!important}.btn:hover,.btn-primary:hover,.btn-success:hover{background:linear-gradient(135deg,#39b6ff,#1266ed)!important}.btn-secondary,.btn-outline-primary,.btn-outline-danger{background:#0d2138!important;border-color:#277eff!important;color:#8eeaff!important}.btn-warning{background:linear-gradient(135deg,#168cff,#075bd8)!important;color:#fff!important;border-color:#67e5ff!important}.form-control,.form-select,textarea,input{background:#071523!important;color:#fff!important;border-color:#1e5685!important}.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:var(--cyan)!important;box-shadow:0 0 0 4px rgba(39,215,255,.14)!important}.badge,.hot,.tag{background:linear-gradient(135deg,var(--ocean),var(--ocean-deep))!important;color:#fff!important}.alert,.toast,.latest-order-notification,.order-notification,.purchase-notification,.recent-order-toast{background:linear-gradient(135deg,#102d4a,#071523)!important;border-color:#277eff!important;color:#fff!important}.table thead{background:rgba(22,140,255,.16)!important}.table tbody tr:hover{background:rgba(22,140,255,.1)!important}h1,h2,h3,h4,h5,h6{color:#f3fbff!important}footer{background:#02060b!important;border-top-color:rgba(39,215,255,.4)!important}.omg-order-toggle{background:rgba(7,29,50,.95)!important;border-color:#277eff!important}.omg-order-toggle i{background:var(--ocean)!important;box-shadow:0 0 12px rgba(39,215,255,.7)!important}.admin-chat-page .col-lg-8 h5+div .bg-primary{background:linear-gradient(135deg,#168cff,#075bd8)!important;border-color:#67e5ff!important}.admin-chat-page .col-lg-8 form .btn{background:linear-gradient(135deg,#168cff,#075bd8)!important}
/* blue hover glow */
.product-card:hover::before,.category-card:hover::before,.shop-card:hover::before,.card.product-card:hover::before,.card.category-card:hover::before,.card.shop-card:hover::before{background:conic-gradient(from 0deg,transparent 0deg,transparent 35deg,#27d7ff 70deg,#168cff 100deg,transparent 140deg,transparent 360deg)!important;filter:drop-shadow(0 0 4px #27d7ff) drop-shadow(0 0 12px #168cff)!important}.product-card:hover::after,.category-card:hover::after,.shop-card:hover::after,.card.product-card:hover::after,.card.category-card:hover::after,.card.shop-card:hover::after{background:conic-gradient(from 0deg,transparent,rgba(39,215,255,.6),transparent 25%)!important}

</style>

<style id="force-order-red-final">
.xez-order-btn,.product-buy-btn{background:linear-gradient(135deg,#ef4444,#b91c1c)!important;border:1px solid #f87171!important;color:#fff!important;box-shadow:0 0 16px rgba(239,68,68,.3)!important}.xez-order-btn:hover,.product-buy-btn:hover{background:linear-gradient(135deg,#f87171,#dc2626)!important;border-color:#fecaca!important;color:#fff!important;box-shadow:0 0 20px rgba(239,68,68,.45)!important}
</style>

<style>
.user-chat-notify-fab{position:fixed;right:20px;bottom:92px;width:58px;height:58px;display:flex;align-items:center;justify-content:center;border-radius:18px;background:linear-gradient(145deg,#ffb300 0%,#e50914 70%,#8b0000 100%);color:#fff!important;box-shadow:0 10px 28px rgba(229,9,20,.45),inset 0 1px 0 rgba(255,255,255,.3);z-index:1060;text-decoration:none;transition:transform .2s,filter .2s,box-shadow .2s}
.user-chat-notify-fab:hover,.user-chat-notify-fab.is-new{transform:translateY(-3px) scale(1.06);filter:brightness(1.15);box-shadow:0 14px 34px rgba(229,9,20,.6),inset 0 1px 0 rgba(255,255,255,.35)}
.user-chat-notify-fab.is-new:before{content:'';position:absolute;inset:-5px;border:2px solid rgba(255,179,0,.65);border-radius:22px;animation:chatNotifyPulse 1.6s ease-out infinite}
.user-chat-notify-fab i{font-size:22px;filter:drop-shadow(0 2px 2px rgba(0,0,0,.3))}
@keyframes chatNotifyPulse{0%{transform:scale(.92);opacity:.9}100%{transform:scale(1.2);opacity:0}}
.user-chat-notify-label{position:absolute;right:68px;white-space:nowrap;bottom:12px;padding:7px 10px;border-radius:10px;background:rgba(23,16,16,.96);color:#ffe3a3;font:700 12px/16px Arial,sans-serif;box-shadow:0 5px 16px rgba(0,0,0,.34);border:1px solid rgba(255,179,0,.28)}.user-chat-notify-badge{position:absolute;right:-4px;top:-5px;min-width:21px;height:21px;padding:2px 5px;border-radius:999px;background:#ff1744;color:#fff;font:700 12px/17px Arial,sans-serif;text-align:center;border:2px solid #080808}
@media(max-width:600px){.user-chat-notify-fab{right:14px;bottom:82px;width:48px;height:48px}}
</style>

<style id="admin-chat-background-theme">
#contactAdminModal .modal-dialog{max-width:560px}
#contactAdminModal .modal-content{background:linear-gradient(145deg,#241015 0%,#10090d 48%,#070609 100%)!important;border:1px solid #7d263d!important;border-radius:18px!important;box-shadow:0 24px 80px rgba(0,0,0,.72),0 0 28px rgba(229,9,20,.16)!important;overflow:hidden}
#contactAdminModal .modal-header{background:linear-gradient(90deg,#3a101c,#170b11)!important;border-bottom:1px solid #7d263d!important;color:#fff!important}
#contactAdminModal .modal-title{color:#fff!important;font-weight:700}
#contactAdminModal .modal-body{background:radial-gradient(circle at 15% 10%,rgba(229,9,20,.13),transparent 32%),radial-gradient(circle at 85% 90%,rgba(255,179,0,.08),transparent 28%),#0a080b!important;padding:14px!important}
#contactAdminModal #adminChatMessages{background:linear-gradient(180deg,rgba(33,13,20,.94),rgba(8,7,10,.98))!important;border:1px solid #421827!important;border-radius:13px!important;min-height:280px;max-height:420px!important;padding:14px!important;scrollbar-color:#a52a4d #100b10}
#contactAdminModal #adminChatMessages>div{margin-bottom:10px!important}
#contactAdminModal #adminChatMessages .bg-primary{background:linear-gradient(135deg,#d81b45,#831b36)!important;border:1px solid #f08b9e!important;color:#fff!important;box-shadow:0 5px 14px rgba(216,27,69,.18)}
#contactAdminModal #adminChatMessages .bg-white{background:linear-gradient(135deg,#2b1820,#171015)!important;border:1px solid #6c3044!important;color:#ffeef2!important;box-shadow:0 5px 14px rgba(0,0,0,.22)}
#contactAdminModal #adminChatMessages small{color:rgba(255,255,255,.65)!important}
#contactAdminModal #adminChatForm{background:#160b11!important;border-top:1px solid #5d2034!important;padding-top:12px}
#contactAdminModal #adminChatForm input{background:#0c080c!important;color:#fff!important;border:1px solid #7d263d!important}
#contactAdminModal #adminChatForm input::placeholder{color:#c99aa6!important}
#contactAdminModal #adminChatForm button{background:linear-gradient(135deg,#d81b45,#831b36)!important;border-color:#f08b9e!important;color:#fff!important}
#contactAdminModal .btn-close{filter:invert(1);opacity:.85}
</style>

<style id="member-chat-reply-alert">
#userChatBell.chat-reply-unread{color:#ff6b88!important;filter:drop-shadow(0 0 7px rgba(255,72,112,.8));animation:memberChatBellPulse 1.5s ease-in-out infinite}
#userChatBell.chat-reply-unread i{animation:memberChatBellShake .8s ease-in-out infinite}
@keyframes memberChatBellPulse{0%,100%{opacity:1}50%{opacity:.62}}
@keyframes memberChatBellShake{0%,100%{transform:rotate(0)}25%{transform:rotate(-14deg)}75%{transform:rotate(14deg)}}
</style>

<style id="admin-chat-modern-ui">
#contactAdminFab{padding:11px 16px!important;background:linear-gradient(135deg,#ffb300,#e50914)!important;border:1px solid rgba(255,255,255,.22)!important;box-shadow:0 10px 28px rgba(229,9,20,.42)!important}
#contactAdminFab:hover{transform:translateY(-3px) scale(1.03)!important}
#contactAdminFab .contact-admin-badge{position:absolute;right:-7px;top:-8px;min-width:22px;height:22px;padding:2px 5px;border-radius:999px;background:#ff1744;color:#fff;font:700 12px/18px Arial,sans-serif;border:2px solid #080808;text-align:center}
#contactAdminModal .chat-modal-header{padding:14px 16px!important;background:linear-gradient(135deg,#3a101c,#160b11)!important}
.chat-admin-title{display:flex;align-items:center;gap:10px;color:#fff}.chat-admin-title small{display:block;color:#ffcf8a;font-size:11px;margin-top:2px}.chat-admin-avatar{display:grid;place-items:center;width:38px;height:38px;border-radius:13px;background:linear-gradient(135deg,#ffb300,#d81b45);color:#fff;font-size:18px}
#contactAdminModal .chat-modal-body{padding:12px!important;background:#08070a!important}.chat-reply-banner{display:flex;gap:8px;align-items:center;padding:8px 10px;margin-bottom:10px;border:1px solid rgba(255,179,0,.25);border-radius:10px;background:rgba(255,179,0,.08);color:#ffd166;font-size:11px}.chat-messages-box{height:340px;overflow:auto;background:radial-gradient(circle at 10% 0,rgba(216,27,69,.18),transparent 35%),#100b10!important;border:1px solid #542033;border-radius:14px;padding:14px!important;scrollbar-color:#a52a4d #100b10}
#contactAdminModal .chat-composer{background:#160b11!important;border-top:1px solid #5d2034}.chat-composer .modal-footer{gap:8px;padding:12px!important}.chat-composer input{background:#0b080c!important;color:#fff!important;border:1px solid #7d263d!important}.chat-composer button{border:0!important;background:linear-gradient(135deg,#d81b45,#831b36)!important}.chat-composer button i{margin-right:5px}
@media(max-width:480px){#contactAdminFab{padding:11px!important}.chat-messages-box{height:300px}.chat-reply-banner{font-size:10px}}
</style>

<style id="reference-light-theme">
/* Reference palette: clean white/grey storefront with black and gold accents. */
:root{--ref-black:#111111;--ref-ink:#222222;--ref-muted:#707070;--ref-bg:#f2f2f2;--ref-card:#ffffff;--ref-line:#dedede;--ref-gold:#f2c400;--ref-gold-dark:#b88b00}
html,body{background:var(--ref-bg)!important;color:var(--ref-ink)!important}
body{background-image:linear-gradient(135deg,rgba(255,255,255,.95),rgba(238,238,238,.98))!important;font-family:var(--font-family,'Kanit',sans-serif)!important}
.navbar,.main-navbar,header{background:#fff!important;border-bottom:1px solid #e3e3e3!important;box-shadow:0 2px 12px rgba(0,0,0,.06)!important;color:var(--ref-ink)!important}
.navbar-brand,.navbar a,.nav-link,.navbar .nav-link{color:var(--ref-ink)!important}.navbar a:hover,.nav-link:hover{color:#8b6900!important}
.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:var(--ref-card)!important;color:var(--ref-ink)!important;border:1px solid var(--ref-line)!important;border-radius:18px!important;box-shadow:0 4px 14px rgba(0,0,0,.06)!important}
.card:hover,.product-card:hover,.category-card:hover,.shop-card:hover{border-color:#c7c7c7!important;box-shadow:0 8px 20px rgba(0,0,0,.1)!important}
h1,h2,h3,h4,h5,h6,p,small,.text-muted{color:var(--ref-ink)!important;text-shadow:none!important}.text-muted{color:var(--ref-muted)!important}
.btn,.btn-primary,.btn-success,.button-primary,.bg-main{background:var(--ref-black)!important;border:1px solid var(--ref-black)!important;color:#fff!important;border-radius:10px!important;box-shadow:none!important}
.btn:hover,.btn-primary:hover,.btn-success:hover,.button-primary:hover{background:#333!important;border-color:#333!important;color:#fff!important}
.btn-warning,.xez-order-btn,.xez-detail-btn{background:var(--ref-gold)!important;border-color:var(--ref-gold-dark)!important;color:#111!important}
.btn-secondary,.btn-outline-primary,.btn-outline-danger{background:#fff!important;border-color:#bdbdbd!important;color:var(--ref-ink)!important}
.btn-danger{background:#333!important;border-color:#333!important;color:#fff!important}
.form-control,.form-select,textarea,input{background:#fff!important;color:var(--ref-ink)!important;border:1px solid #cfcfcf!important;border-radius:10px!important}
.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:var(--ref-gold-dark)!important;box-shadow:0 0 0 .2rem rgba(242,196,0,.2)!important}
a{color:#665000!important}a:hover{color:#111!important}.badge,.hot,.tag{background:var(--ref-gold)!important;color:#111!important;border-color:var(--ref-gold-dark)!important}
.alert,.toast,.latest-order-notification,.order-notification,.recent-order-toast{background:#fff!important;color:var(--ref-ink)!important;border:1px solid var(--ref-line)!important;border-radius:14px!important;box-shadow:0 4px 14px rgba(0,0,0,.06)!important}
.table{color:var(--ref-ink)!important}.table thead{background:#eeeeee!important;color:var(--ref-ink)!important}.table tbody tr{border-color:#e4e4e4!important}.table tbody tr:hover{background:#faf7e4!important}
footer{background:#fff!important;color:var(--ref-muted)!important;border-top:1px solid var(--ref-line)!important}.omg-order-toggle{background:#fff!important;border-color:#bdbdbd!important;color:var(--ref-ink)!important}.omg-order-toggle i{background:var(--ref-gold)!important;box-shadow:0 0 8px rgba(242,196,0,.45)!important}
#contactAdminFab,.user-chat-notify-fab{background:var(--ref-black)!important;color:#fff!important;box-shadow:0 6px 16px rgba(0,0,0,.2)!important}.chat-admin-avatar{background:var(--ref-gold)!important;color:#111!important}
#contactAdminModal .chat-modal-header{background:#fff!important;color:var(--ref-ink)!important;border-bottom:1px solid var(--ref-line)!important}#contactAdminModal .chat-modal-body,#contactAdminModal .chat-composer{background:#f5f5f5!important;border-color:var(--ref-line)!important}.chat-reply-banner{background:#fff9d9!important;color:#6f5700!important;border-color:#ead27a!important}.chat-messages-box{background:#fff!important;border-color:#d7d7d7!important;scrollbar-color:#bdbdbd #f5f5f5}.chat-messages-box .bg-primary{background:var(--ref-black)!important}.chat-messages-box .bg-white{background:#f3f3f3!important;color:var(--ref-ink)!important;border-color:#ddd!important}
.admin-sidebar,.admin-content-card,.xez-card{background:#fff!important;border-color:var(--ref-line)!important}.admin-menu-section-title{color:var(--ref-ink)!important}.admin-menu-item{color:var(--ref-ink)!important}.admin-menu-item.active{background:var(--ref-black)!important;color:#fff!important}.admin-menu-item-icon{color:var(--ref-gold-dark)!important;background:#fff9d9!important}
@media(max-width:768px){body{background:#f2f2f2!important}.card,.product-card,.category-card,.feature-card,.shop-card{border-radius:15px!important}}
</style>

<style id="readable-contrast-theme">
/* High-contrast readability pass for mobile and desktop. */
body,.theme-light,.theme-dark{background:#f5f5f5!important;color:#222!important}
.navbar,.main-navbar,header{background:#fff!important;color:#222!important;border-bottom:1px solid #d8d8d8!important}
.navbar-brand,.navbar-text-brand,.navbar a,.nav-link,.navbar .nav-link{color:#1f1f1f!important;text-shadow:none!important}
.navbar .nav-link i,.nav-link-xez i,.navbar-toggler i{color:#e0ad00!important}
.navbar-toggler{background:#fff!important;border:1px solid #d2d2d2!important;border-radius:10px!important;color:#222!important}
.btn-navbar-register{background:#111!important;color:#fff!important;border:1px solid #111!important}.btn-navbar-register i{color:#f2c400!important}
.navbar-collapse{background:#fff!important}.dropdown-menu{background:#fff!important;border:1px solid #ddd!important}.dropdown-menu a{color:#222!important}
.xez-card,.xez-card.card,.login-card{background:#fff!important;color:#222!important;border:1px solid #d8d8d8!important;border-radius:18px!important;box-shadow:0 5px 18px rgba(0,0,0,.08)!important}
.xez-card h1,.xez-card h2,.xez-card h3,.xez-card h4,.xez-card h5,.xez-card h6,.xez-card label,.xez-card .form-label{color:#222!important;text-shadow:none!important}
.xez-card .text-muted,.xez-card p{color:#666!important}.xez-card .bg-primary-soft{background:#fff8d8!important}.xez-card .text-xez-primary{color:#b18400!important}
.xez-card .form-control,.xez-card .form-select,.xez-card textarea{background:#fff!important;color:#222!important;border:1px solid #bdbdbd!important;box-shadow:none!important}
.xez-card .form-control::placeholder,.xez-card .form-select::placeholder{color:#888!important;opacity:1!important}
.xez-card .form-control:focus,.xez-card .form-select:focus,.xez-card textarea:focus{border-color:#c49a00!important;box-shadow:0 0 0 3px rgba(242,196,0,.18)!important}
.xez-card .xez-btn-cyan,.xez-card .btn-login{background:#111!important;border:1px solid #111!important;color:#fff!important}.xez-card .xez-btn-cyan i,.xez-card .btn-login i{color:#f2c400!important}
.xez-card #google-login-button{background:#fff!important;color:#222!important;border:1px solid #c9c9c9!important}.xez-card #google-login-button:hover{background:#f7f7f7!important}
.xez-card .border-top{border-color:#cfcfcf!important}.g-recaptcha{background:#fff!important}
footer{background:#fff!important;color:#666!important}.footer-links a,.footer-secondary-links a{color:#555!important}
</style>

<style id="auth-readable-theme">
/* Dedicated high-contrast auth screens. */
body:has(.auth-card){background:#f4f4f4!important;color:#202020!important}
.auth-card,.xez-card.auth-card,.xdvz-card.auth-card{background:#fff!important;color:#202020!important;border:1px solid #d6d6d6!important;border-radius:20px!important;box-shadow:0 8px 24px rgba(0,0,0,.09)!important}
.auth-card h1,.auth-card h2,.auth-card h3,.auth-card h4,.auth-card h5,.auth-card h6,.auth-card label,.auth-card .form-label{color:#202020!important;text-shadow:none!important}
.auth-card p,.auth-card .text-muted{color:#666!important}.auth-card .bg-primary-soft{background:#fff8d8!important}.auth-card .text-xez-primary,.auth-card .text-xdvz-primary{color:#9b7500!important}
.auth-card .form-control,.auth-card .form-select,.auth-card input{height:50px;background:#fff!important;color:#202020!important;border:1px solid #b8b8b8!important;border-radius:10px!important;box-shadow:none!important;font-size:16px!important}
.auth-card .form-control::placeholder,.auth-card input::placeholder{color:#888!important;opacity:1!important}.auth-card .form-control:focus,.auth-card input:focus{border-color:#bd9200!important;box-shadow:0 0 0 3px rgba(242,196,0,.2)!important}
.auth-card #btn_regis{min-height:52px;background:#111!important;color:#fff!important;border:1px solid #111!important;border-radius:10px!important;font-size:17px!important}.auth-card #btn_regis i{color:#f2c400!important}
.auth-card #google-login-button{min-height:52px;background:#fff!important;color:#202020!important;border:1px solid #bdbdbd!important;border-radius:10px!important}.auth-card #google-login-button:hover{background:#f7f7f7!important}
.auth-card .g-recaptcha{filter:none!important}.auth-card .border-top{border-color:#c7c7c7!important}.auth-card a{color:#8a6800!important;text-decoration:underline;text-underline-offset:2px}
@media(max-width:576px){body:has(.auth-card) .container-sm{padding:22px 14px!important}.auth-card{padding:24px 18px!important;border-radius:16px!important}.auth-card .g-recaptcha{transform-origin:top center!important;margin-bottom:4px!important}}
</style>

<style id="home-readable-theme">
/* Home page readability pass: bright surfaces, dark text, restrained gold accents. */
body:has(.home-hero-banner){background:#f4f4f4!important;color:#222!important}
.home-hero-banner{background:linear-gradient(180deg,#ffffff 0%,#f6f6f6 100%)!important;color:#222!important;border-bottom:1px solid #dedede!important}
.home-hero-title{color:#171717!important;text-shadow:none!important}.home-hero-tagline{color:#555!important}.home-hero-logo{filter:none!important;max-height:100px!important}
.home-btn-primary{background:#111!important;color:#fff!important;border:1px solid #111!important}.home-btn-primary i{color:#f2c400!important}
.home-btn-outline{background:#fff!important;color:#222!important;border:1px solid #a9a9a9!important}.home-btn-outline i{color:#b18400!important}.home-btn-outline:hover{background:#fff9d9!important;color:#222!important}
.home-announcement-bar,.announcement-bar{background:#fff!important;color:#222!important;border:1px solid #d8d8d8!important;box-shadow:0 3px 12px rgba(0,0,0,.06)!important}.home-announcement-bar .announcement-icon,.announcement-bar .announcement-icon{background:#fff3bf!important;color:#a47700!important}
.home-stats-bar{background:#fff!important;border:1px solid #d8d8d8!important;box-shadow:0 4px 14px rgba(0,0,0,.06)!important}.home-stat-label{color:#666!important}.home-stat-value{color:#171717!important}.home-stat-value small{color:#777!important}.home-stat-icon{background:#fff8d8!important;color:#a47700!important}.home-stat-icon i{color:#a47700!important}.home-stat-highlight .home-stat-icon{background:#111!important}.home-stat-highlight .home-stat-icon i{color:#f2c400!important}
body:has(.home-hero-banner) .theme-light .xez-card,body:has(.home-hero-banner) .theme-dark .xez-card,body:has(.home-hero-banner) .xez-card{background:#fff!important;color:#222!important;border:1px solid #d8d8d8!important;box-shadow:0 4px 14px rgba(0,0,0,.06)!important}
body:has(.home-hero-banner) .xez-card h1,body:has(.home-hero-banner) .xez-card h2,body:has(.home-hero-banner) .xez-card h3,body:has(.home-hero-banner) .xez-card h4,body:has(.home-hero-banner) .xez-card h5,body:has(.home-hero-banner) .xez-card h6{color:#222!important;text-shadow:none!important}
body:has(.home-hero-banner) .xez-card .text-muted{color:#666!important}
.cat-card-horizontal,.home-nav-card,.product-card{background:#fff!important;color:#222!important;border-color:#d8d8d8!important;box-shadow:0 4px 14px rgba(0,0,0,.06)!important}.cat-card-horizontal h5,.home-nav-card h6,.product-card h6{color:#222!important}.cat-card-horizontal p,.product-card .text-muted{color:#666!important}.cat-card-action i{color:#b18400!important}.home-nav-icon{background:#fff8d8!important;border:1px solid #ead27a!important}.home-nav-icon i{color:#b18400!important}.product-card .badge{background:#111!important;color:#fff!important;border-color:#111!important}.product-card .text-xez-primary{color:#a47700!important}
.home-hero-particles{opacity:.12!important}.carousel{border:1px solid #d8d8d8!important;border-radius:16px!important;overflow:hidden}.carousel-indicators button.active{background-color:#d0a600!important}
@media(max-width:768px){body:has(.home-hero-banner) .container-sm{padding-left:14px!important;padding-right:14px!important}.home-hero-banner{padding-bottom:28px!important}.home-hero-title{font-size:1.55rem!important}.home-stat-value{font-size:1.35rem!important}.home-nav-card{padding:18px 8px!important}.home-nav-card h6{font-size:.85rem!important}.product-card{padding:10px!important}}
</style>

<style id="neutral-gray-theme">
/* Neutral monochrome palette: light grey, charcoal, white and black. */
:root{--neutral-bg:#eeeeee;--neutral-surface:#ffffff;--neutral-soft:#f7f7f7;--neutral-line:#d1d1d1;--neutral-mid:#777777;--neutral-dark:#333333;--neutral-black:#111111}
html,body{background:var(--neutral-bg)!important;color:var(--neutral-dark)!important}
body{background-image:linear-gradient(180deg,#f7f7f7 0%,#e9e9e9 100%)!important}
.navbar,.main-navbar,header{background:#fff!important;color:#111!important;border-bottom:1px solid var(--neutral-line)!important;box-shadow:0 2px 12px rgba(0,0,0,.07)!important}
.navbar-brand,.navbar-text-brand,.navbar a,.nav-link,.navbar .nav-link{color:#111!important;text-shadow:none!important}.navbar a:hover,.nav-link:hover{color:#666!important}.navbar .nav-link i,.nav-link-xez i,.navbar-toggler i{color:#444!important}.navbar-toggler{background:#fff!important;border:1px solid #bdbdbd!important;color:#111!important}
.navbar-collapse,.dropdown-menu{background:#fff!important}.dropdown-menu{border:1px solid var(--neutral-line)!important}.dropdown-menu a{color:#222!important}
.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content,.xez-card,.xdvz-card{background:#fff!important;color:#222!important;border:1px solid var(--neutral-line)!important;border-radius:16px!important;box-shadow:0 4px 14px rgba(0,0,0,.07)!important}
h1,h2,h3,h4,h5,h6{color:#181818!important;text-shadow:none!important}p,.text-muted{color:#666!important}.text-dark{color:#222!important}a{color:#333!important}a:hover{color:#000!important}
.btn,.btn-primary,.btn-success,.button-primary,.bg-main,.btn-navbar-register{background:#111!important;border:1px solid #111!important;color:#fff!important;border-radius:9px!important;box-shadow:none!important}.btn:hover,.btn-primary:hover,.btn-success:hover,.button-primary:hover,.btn-navbar-register:hover{background:#333!important;border-color:#333!important;color:#fff!important}.btn i,.btn-navbar-register i{color:#fff!important}
.btn-secondary,.btn-light,.btn-outline-primary,.btn-outline-danger,.xez-btn-outline{background:#fff!important;color:#222!important;border:1px solid #aaa!important}.btn-secondary:hover,.btn-light:hover,.btn-outline-primary:hover,.btn-outline-danger:hover,.xez-btn-outline:hover{background:#eeeeee!important;color:#111!important;border-color:#777!important}
.btn-warning,.xez-order-btn,.xez-detail-btn{background:#444!important;color:#fff!important;border-color:#444!important}.btn-danger{background:#333!important;color:#fff!important;border-color:#333!important}
.form-control,.form-select,textarea,input{background:#fff!important;color:#222!important;border:1px solid #bdbdbd!important;border-radius:9px!important}.form-control::placeholder,.form-select::placeholder,input::placeholder,textarea::placeholder{color:#888!important;opacity:1!important}.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:#555!important;box-shadow:0 0 0 3px rgba(0,0,0,.12)!important}
.badge,.hot,.tag{background:#333!important;color:#fff!important;border-color:#333!important}.alert,.toast,.latest-order-notification,.order-notification,.purchase-notification,.recent-order-toast{background:#fff!important;color:#222!important;border:1px solid var(--neutral-line)!important;box-shadow:0 4px 14px rgba(0,0,0,.07)!important}.table{color:#222!important}.table thead{background:#e1e1e1!important;color:#222!important}.table tbody tr{border-color:#ddd!important}.table tbody tr:hover{background:#f3f3f3!important}
footer,.home-footer{background:#333!important;color:#eee!important;border-top:1px solid #222!important}footer a,.home-footer a{color:#fff!important}
/* Home page */
body:has(.home-hero-banner){background:#eeeeee!important;color:#222!important}.home-hero-banner{background:linear-gradient(180deg,#ffffff 0%,#e5e5e5 100%)!important;color:#222!important;border-bottom:1px solid #cfcfcf!important}.home-hero-title{color:#111!important;text-shadow:none!important}.home-hero-tagline{background:#333!important;color:#fff!important;box-shadow:none!important}.home-hero-tagline span{color:#fff!important}.home-hero-logo{filter:none!important}.home-btn-primary{background:#111!important;color:#fff!important;border-color:#111!important;box-shadow:none!important}.home-btn-outline{background:#fff!important;color:#222!important;border:1px solid #999!important}.home-btn-outline:hover{background:#e5e5e5!important;color:#111!important}.home-announcement-bar,.announcement-bar{background:#fff!important;color:#222!important;border-color:#ccc!important;box-shadow:0 3px 10px rgba(0,0,0,.06)!important}.home-announcement-bar .announcement-icon,.announcement-bar .announcement-icon{background:#444!important;color:#fff!important}.announcement-content,.announcement-content marquee{color:#222!important}.home-stats-bar{background:#fff!important;border-color:#ccc!important;box-shadow:0 4px 12px rgba(0,0,0,.06)!important}.home-stat-item{border-color:#ddd!important}.home-stat-label{color:#666!important}.home-stat-value{color:#222!important}.home-stat-value small{color:#777!important}.home-stat-icon{background:#e6e6e6!important}.home-stat-icon i{color:#444!important}.home-stat-highlight .home-stat-icon{background:#333!important}.home-stat-highlight .home-stat-icon i{color:#fff!important}
body:has(.home-hero-banner) .xez-card,body:has(.home-hero-banner) .theme-light .xez-card,body:has(.home-hero-banner) .theme-dark .xez-card{background:#fff!important;color:#222!important;border-color:#d0d0d0!important;box-shadow:0 4px 14px rgba(0,0,0,.07)!important}.cat-card-horizontal h5,.home-nav-card h6,.product-card h6{color:#222!important}.cat-card-horizontal p,.product-card .text-muted{color:#666!important}.cat-card-action i{color:#444!important}.home-nav-icon{background:#e8e8e8!important;border-color:#c5c5c5!important}.home-nav-icon i{color:#333!important}.product-card .badge{background:#333!important;color:#fff!important;border-color:#333!important}.product-card .text-xez-primary{color:#333!important}
/* Auth screens retain strong contrast in the neutral palette. */
.auth-card,.xez-card.auth-card,.xdvz-card.auth-card{background:#fff!important;color:#222!important}.auth-card #btn_regis{background:#111!important;color:#fff!important}.auth-card a{color:#333!important}
@media(max-width:768px){body:has(.home-hero-banner) .container-sm{padding-left:14px!important;padding-right:14px!important}.home-hero-title{font-size:1.7rem!important}.home-nav-card{padding:18px 8px!important}}
</style>

<style id="popup-readable-theme">
/* Announcement popup readability: dark text on white, black footer, orange action. */
#xez_popup .popup-content,#xez_popup .modal-content{background:#fff!important;color:#222!important;border:1px solid #c8c8c8!important;box-shadow:0 18px 50px rgba(0,0,0,.28)!important}
#xez_popup .modal-header{background:#fff!important;border-bottom:1px solid #e0e0e0!important;color:#222!important}#xez_popup .popup-title{color:#222!important;text-shadow:none!important}#xez_popup .popup-title .text-xez-primary{color:#f0a900!important}#xez_popup .btn-close{filter:none!important;opacity:.85!important}
#xez_popup .popup-slides{background:#fff!important}#xez_popup .popup-slide>div{background:#fff!important;color:#222!important}#xez_popup .popup-slide h3.popup-title{color:#222!important;text-shadow:none!important}#xez_popup .popup-text{color:#444!important}#xez_popup .popup-badge{background:#333!important;color:#fff!important}
#xez_popup .popup-indicators{background:#fff!important}#xez_popup .popup-indicators .indicator{background:#bbb!important}#xez_popup .popup-indicators .indicator.active{background:#444!important}
#xez_popup .popup-footer{background:#111!important;color:#fff!important;border-top:1px solid #333!important}#xez_popup .popup-footer .form-check-label{color:#fff!important}#xez_popup .popup-footer .form-check-input{background:#fff!important;border-color:#aaa!important}#xez_popup .popup-btn{background:linear-gradient(135deg,#ffb300,#ff7600)!important;color:#fff!important;border:1px solid #ffcf4a!important;box-shadow:none!important}#xez_popup .popup-btn:hover{background:#e87500!important;color:#fff!important}
</style>

<style id="popup-red-close-button">
#xez_popup .popup-btn{background:#dc2626!important;border-color:#b91c1c!important;color:#fff!important;box-shadow:0 4px 12px rgba(185,28,28,.22)!important}
#xez_popup .popup-btn:hover{background:#b91c1c!important;border-color:#991b1b!important;color:#fff!important}
</style>

<style id="neutral-home-force-theme">
/* Force the neutral palette after legacy theme selectors with higher specificity. */
body.theme-light:has(.home-hero-banner),body.theme-dark:has(.home-hero-banner),body:not(.theme-dark):has(.home-hero-banner){background:#eeeeee!important;color:#222!important}
body.theme-light .home-hero-banner,body.theme-dark .home-hero-banner,body:not(.theme-dark) .home-hero-banner{background:linear-gradient(180deg,#fff 0%,#e5e5e5 100%)!important;color:#222!important;border-color:#cfcfcf!important}
body.theme-light .home-hero-title,body.theme-dark .home-hero-title,body:not(.theme-dark) .home-hero-title{color:#111!important;text-shadow:none!important}body.theme-light .home-hero-tagline,body.theme-dark .home-hero-tagline,body:not(.theme-dark) .home-hero-tagline{background:#333!important;color:#fff!important;box-shadow:none!important}
body.theme-light .home-btn-primary,body.theme-dark .home-btn-primary,body:not(.theme-dark) .home-btn-primary{background:#111!important;color:#fff!important;border-color:#111!important}body.theme-light .home-btn-outline,body.theme-dark .home-btn-outline,body:not(.theme-dark) .home-btn-outline{background:#fff!important;color:#222!important;border-color:#999!important}
body.theme-light .home-stats-bar,body.theme-dark .home-stats-bar,body:not(.theme-dark) .home-stats-bar{background:#fff!important;border-color:#c9c9c9!important;box-shadow:0 4px 12px rgba(0,0,0,.07)!important}body.theme-light .home-stat-label,body.theme-dark .home-stat-label,body:not(.theme-dark) .home-stat-label{color:#666!important}body.theme-light .home-stat-value,body.theme-dark .home-stat-value,body:not(.theme-dark) .home-stat-value{color:#222!important}body.theme-light .home-stat-value small,body.theme-dark .home-stat-value small,body:not(.theme-dark) .home-stat-value small{color:#777!important}body.theme-light .home-stat-icon,body.theme-dark .home-stat-icon,body:not(.theme-dark) .home-stat-icon{background:#e5e5e5!important}body.theme-light .home-stat-icon i,body.theme-dark .home-stat-icon i,body:not(.theme-dark) .home-stat-icon i{color:#444!important}
body.theme-light .xez-card,body.theme-dark .xez-card,body:not(.theme-dark) .xez-card{background:#fff!important;color:#222!important;border-color:#d0d0d0!important;box-shadow:0 4px 14px rgba(0,0,0,.07)!important}body.theme-light .xez-card h1,body.theme-light .xez-card h2,body.theme-light .xez-card h3,body.theme-light .xez-card h4,body.theme-light .xez-card h5,body.theme-light .xez-card h6,body.theme-dark .xez-card h1,body.theme-dark .xez-card h2,body.theme-dark .xez-card h3,body.theme-dark .xez-card h4,body.theme-dark .xez-card h5,body.theme-dark .xez-card h6{color:#222!important;text-shadow:none!important}
body.theme-light .home-nav-card,body.theme-dark .home-nav-card,body:not(.theme-dark) .home-nav-card,body.theme-light .product-card,body.theme-dark .product-card,body:not(.theme-dark) .product-card{background:#fff!important;color:#222!important;border-color:#d0d0d0!important}body.theme-light .home-nav-card h6,body.theme-dark .home-nav-card h6,body:not(.theme-dark) .home-nav-card h6,body.theme-light .product-card h6,body.theme-dark .product-card h6,body:not(.theme-dark) .product-card h6{color:#222!important}
</style>

<!-- MONOCHROME_THEME_OVERRIDE -->
<style id="omgvip-monochrome-theme">
/* OMGVIP monochrome theme override: light gray, dark gray, white, black */
:root {
  --mono-black: #0b0b0c;
  --mono-dark: #17181a;
  --mono-mid: #34363a;
  --mono-gray: #6b7078;
  --mono-light: #e6e7e9;
  --mono-white: #ffffff;
  --mono-line: rgba(255,255,255,.16);
}
html, body {
  background: linear-gradient(180deg, #24262a 0%, #111214 58%, #090a0b 100%) !important;
  color: var(--mono-white) !important;
}
body:before { display: none !important; }
.navbar, .main-navbar, header {
  background: rgba(11,11,12,.97) !important;
  border-bottom: 1px solid #6b7078 !important;
  box-shadow: 0 8px 24px rgba(0,0,0,.28) !important;
}
.navbar-brand, .navbar a, .navbar-text, .nav-link { color: #fff !important; }
.navbar a:hover, .nav-link:hover { color: #e6e7e9 !important; }
.card, .card-body, .glass-card, .product-card, .category-card, .feature-card, .shop-card, .modal-content {
  background: linear-gradient(145deg, #34363a, #17181a) !important;
  border: 1px solid #6b7078 !important;
  box-shadow: 0 12px 30px rgba(0,0,0,.32) !important;
}
.card:hover, .product-card:hover, .category-card:hover, .shop-card:hover {
  border-color: #e6e7e9 !important;
  box-shadow: 0 14px 34px rgba(0,0,0,.42) !important;
}
.btn, .btn-primary, .btn-success, .button-primary, .bg-main, .xez-btn-cyan, .btn-login {
  background: linear-gradient(135deg, #e6e7e9, #aeb2b8) !important;
  border-color: #fff !important;
  color: #0b0b0c !important;
  box-shadow: 0 6px 14px rgba(0,0,0,.24) !important;
}
.btn:hover, .btn-primary:hover, .btn-success:hover, .button-primary:hover, .xez-btn-cyan:hover, .btn-login:hover {
  background: #fff !important;
  color: #000 !important;
}
.btn-secondary, .btn-outline-primary, .btn-outline-danger, .btn-warning, .btn-danger {
  background: #34363a !important;
  border-color: #aeb2b8 !important;
  color: #fff !important;
}
.xez-detail-btn, .xez-order-btn, .btn-navbar-register {
  background: linear-gradient(135deg, #e6e7e9, #aeb2b8) !important;
  border-color: #fff !important;
  color: #0b0b0c !important;
  box-shadow: 0 6px 14px rgba(0,0,0,.24) !important;
}
.form-control, .form-select, textarea, input {
  background: #0f1011 !important;
  color: #fff !important;
  border-color: #6b7078 !important;
}
.form-control:focus, .form-select:focus, textarea:focus, input:focus {
  border-color: #fff !important;
  box-shadow: 0 0 0 .2rem rgba(255,255,255,.16) !important;
}
a { color: #e6e7e9 !important; }
a:hover { color: #fff !important; }
h1, h2, h3, h4, h5, h6 { color: #fff !important; text-shadow: none !important; }
.badge, .hot, .tag { background: #6b7078 !important; color: #fff !important; border-color: #e6e7e9 !important; }
.alert, .toast, .latest-order-notification, .order-notification, .purchase-notification, .recent-order-toast {
  background: #34363a !important; color: #fff !important; border-color: #aeb2b8 !important;
}
.table { color: #fff !important; }
.table thead { background: #34363a !important; }
.table tbody tr { border-color: rgba(255,255,255,.14) !important; }
.table tbody tr:hover { background: rgba(255,255,255,.08) !important; }
footer { background: #0b0b0c !important; border-top-color: #6b7078 !important; color: #c7c9cd !important; }
.omg-order-toggle { background: #17181a !important; border-color: #aeb2b8 !important; }
.omg-order-toggle i { background: #e6e7e9 !important; box-shadow: none !important; color: #0b0b0c !important; }
.navbar-user-mobile { background: #17181a !important; border-color: #aeb2b8 !important; }
.navbar-user-mobile .nav-user-mobile-balance { color: #e6e7e9 !important; }
@media (max-width: 768px) {
  body { background: #111214 !important; }
  .navbar, .main-navbar, header { background: #0b0b0c !important; }
}

</style>
<style id="omgvip-monochrome-contrast-fix">
/* High-contrast fix for light panels and navigation cards */
.modal-content, .offcanvas, .dropdown-menu, .home-nav-card, .xez-card {
  background: #ffffff !important;
  color: #17181a !important;
  border-color: #6b7078 !important;
}
.modal-content *, .offcanvas *, .dropdown-menu *, .home-nav-card *, .xez-card * {
  color: #17181a !important;
  text-shadow: none !important;
}
.modal-content .btn, .modal-content button, .modal-content a,
.offcanvas .btn, .offcanvas button, .offcanvas a,
.dropdown-menu .btn, .dropdown-menu button, .dropdown-menu a,
.home-nav-card, .home-nav-card a, .home-nav-card button,
.xez-card .btn, .xez-card button, .xez-card a {
  background: #e6e7e9 !important;
  color: #111214 !important;
  border: 1px solid #6b7078 !important;
  text-shadow: none !important;
}
.modal-content .btn:hover, .modal-content button:hover, .modal-content a:hover,
.offcanvas .btn:hover, .offcanvas button:hover, .offcanvas a:hover,
.dropdown-menu .btn:hover, .dropdown-menu button:hover, .dropdown-menu a:hover,
.home-nav-card:hover, .home-nav-card a:hover, .home-nav-card button:hover {
  background: #34363a !important;
  color: #ffffff !important;
}
.modal-content hr, .offcanvas hr, .dropdown-menu hr { border-color: #6b7078 !important; opacity: 1 !important; }
</style>
<style id="omgvip-stat-card-contrast-fix">
/* Dashboard statistic cards: readable monochrome contrast */
.stat-card {
  background: linear-gradient(145deg, #34363a, #17181a) !important;
  color: #ffffff !important;
  border: 1px solid #aeb2b8 !important;
  border-radius: 20px !important;
  box-shadow: 0 12px 30px rgba(0,0,0,.34) !important;
}
.stat-card h1, .stat-card h2, .stat-card h3, .stat-card h4, .stat-card h5, .stat-card h6,
.stat-card span, .stat-card strong, .stat-card p, .stat-card small,
.stat-card .text-muted, .stat-card .fw-bold {
  color: #ffffff !important;
  text-shadow: none !important;
}
.stat-card .stat-icon {
  background: #e6e7e9 !important;
  color: #17181a !important;
  border: 1px solid #ffffff !important;
  box-shadow: none !important;
}
.stat-card .stat-icon i { color: #17181a !important; }
</style>
<style id="omgvip-stat-number-white-fix">
/* Force dashboard metric numbers to remain visible on dark cards */
.stat-card h2,
.stat-card h2.fw-bold,
.stat-card h2.mb-1,
.stat-card h2.fw-bold.mb-1,
.stat-card .stat-value,
.stat-card .metric-value {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  opacity: 1 !important;
  text-shadow: none !important;
  visibility: visible !important;
}
</style>
<style id="omgvip-visible-text-final-fix">
/* Final targeted text visibility fix */
.stat-card,
.stat-card * {
  text-shadow: none !important;
}
.stat-card h1, .stat-card h2, .stat-card h3, .stat-card h4, .stat-card h5, .stat-card h6,
.stat-card span, .stat-card strong, .stat-card p, .stat-card small,
.stat-card .text-muted, .stat-card .fw-bold, .stat-card .fw-medium {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  background: transparent !important;
  background-image: none !important;
  opacity: 1 !important;
  visibility: visible !important;
}
.stat-card .stat-icon, .stat-card .stat-icon * {
  color: #17181a !important;
  -webkit-text-fill-color: #17181a !important;
}
</style>
<style id="omgvip-navbar-brand-visible-fix">
/* Make the site name beside the logo visible on the dark top bar */
.navbar .navbar-brand,
.navbar .navbar-brand .navbar-text-brand,
.main-navbar .navbar-brand,
.main-navbar .navbar-brand .navbar-text-brand,
.navbar-text-brand {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  opacity: 1 !important;
  visibility: visible !important;
  text-shadow: 0 1px 2px rgba(0,0,0,.85) !important;
  background: transparent !important;
  background-image: none !important;
}
.navbar .navbar-brand .navbar-text-brand {
  display: inline-block !important;
  font-weight: 700 !important;
  white-space: nowrap !important;
}
@media (max-width: 575.98px) {
  .navbar .navbar-brand .navbar-text-brand,
  .main-navbar .navbar-brand .navbar-text-brand {
    color: #ffffff !important;
    -webkit-text-fill-color: #ffffff !important;
    max-width: 42vw !important;
    overflow: hidden !important;
    text-overflow: ellipsis !important;
  }
}
</style>
<style id="omgvip-chat-admin-button-highlight">
/* Highlight chat and admin controls while keeping the monochrome palette */
#contactAdminFab,
.user-chat-notify-fab {
  background: #ffffff !important;
  color: #111214 !important;
  border: 2px solid #111214 !important;
  box-shadow: 0 8px 24px rgba(0,0,0,.38), 0 0 0 3px rgba(255,255,255,.72) !important;
  font-weight: 800 !important;
  text-shadow: none !important;
}
#contactAdminFab i,
#contactAdminFab span,
.user-chat-notify-fab i,
.user-chat-notify-fab .user-chat-notify-label {
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
}
#contactAdminFab:hover,
.user-chat-notify-fab:hover,
#contactAdminFab:focus-visible,
.user-chat-notify-fab:focus-visible {
  background: #e6e7e9 !important;
  color: #000000 !important;
  border-color: #000000 !important;
  box-shadow: 0 10px 28px rgba(0,0,0,.48), 0 0 0 4px rgba(255,255,255,.9) !important;
  transform: translateY(-2px) scale(1.03) !important;
}
#userChatBell,
#adminChatBell,
#cardRequestBell {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  filter: drop-shadow(0 1px 3px #000) !important;
}
#userChatBell:hover,
#adminChatBell:hover,
#cardRequestBell:hover,
#userChatBell.chat-reply-unread {
  color: #e6e7e9 !important;
  -webkit-text-fill-color: #e6e7e9 !important;
  filter: drop-shadow(0 0 7px rgba(255,255,255,.9)) !important;
}
#contactAdminBadge,
#userChatNotifyBadge,
#userChatBellBadge,
#adminChatBellBadge {
  background: #111214 !important;
  color: #ffffff !important;
  border: 2px solid #ffffff !important;
}
</style>
<style id="omgvip-chat-admin-monochrome-theme">
/* Monochrome chat theme: clear separation for admin and user messages */
#contactAdminModal .modal-content {
  background: #17181a !important;
  color: #ffffff !important;
  border: 1px solid #aeb2b8 !important;
  box-shadow: 0 20px 60px rgba(0,0,0,.55) !important;
}
#contactAdminModal .chat-modal-header {
  background: #0b0b0c !important;
  color: #ffffff !important;
  border-bottom: 1px solid #6b7078 !important;
}
#contactAdminModal .chat-admin-title,
#contactAdminModal .chat-admin-title strong,
#contactAdminModal .chat-admin-title small { color: #ffffff !important; }
#contactAdminModal .chat-admin-title small { color: #e0e2e5 !important; }
#contactAdminModal .chat-admin-avatar {
  background: #e6e7e9 !important;
  color: #111214 !important;
  border: 1px solid #ffffff !important;
}
#contactAdminModal .chat-modal-body,
#contactAdminModal .chat-composer {
  background: #24262a !important;
  color: #ffffff !important;
  border-color: #6b7078 !important;
}
#contactAdminModal .chat-reply-banner {
  background: #34363a !important;
  color: #ffffff !important;
  border-color: #aeb2b8 !important;
}
#contactAdminModal .chat-messages-box {
  background: #0b0b0c !important;
  border: 1px solid #6b7078 !important;
  scrollbar-color: #aeb2b8 #17181a !important;
}
#contactAdminModal #adminChatMessages .bg-primary {
  background: #e6e7e9 !important;
  color: #111214 !important;
  border: 1px solid #ffffff !important;
}
#contactAdminModal #adminChatMessages .bg-white {
  background: #34363a !important;
  color: #ffffff !important;
  border: 1px solid #6b7078 !important;
}
#contactAdminModal #adminChatMessages small { color: #55585d !important; }
#contactAdminModal #adminChatForm input {
  background: #0f1011 !important;
  color: #ffffff !important;
  border: 1px solid #aeb2b8 !important;
}
#contactAdminModal #adminChatForm input::placeholder { color: #c7c9cd !important; }
#contactAdminModal #adminChatForm button {
  background: #ffffff !important;
  color: #111214 !important;
  border: 1px solid #ffffff !important;
  font-weight: 800 !important;
}
/* Admin chat page */
.admin-chat-page {
  color: #ffffff !important;
}
.admin-chat-page h3,
.admin-chat-page h5,
.admin-chat-page strong,
.admin-chat-page .text-muted,
.admin-chat-page small { color: #ffffff !important; }
.admin-chat-page > .alert {
  background: #34363a !important;
  color: #ffffff !important;
  border: 1px solid #aeb2b8 !important;
}
.admin-chat-page .col-lg-4 .list-group {
  background: #17181a !important;
  border: 1px solid #6b7078 !important;
}
.admin-chat-page .col-lg-4 .list-group-item,
.admin-chat-page .chat-user-item {
  color: #ffffff !important;
  border-color: #34363a !important;
}
.admin-chat-page .col-lg-4 .list-group-item:hover,
.admin-chat-page .chat-user-item:hover {
  background: #34363a !important;
  color: #ffffff !important;
}
.admin-chat-page .col-lg-4 .list-group-item.active,
.admin-chat-page .chat-user-item.active {
  background: #e6e7e9 !important;
  color: #111214 !important;
  border-color: #ffffff !important;
}
.admin-chat-page .chat-user-item.active strong,
.admin-chat-page .chat-user-item.active small { color: #111214 !important; }
.admin-chat-page .chat-status-icon.is-unread,
.admin-chat-page .chat-status-icon.is-read {
  background: #e6e7e9 !important;
  color: #111214 !important;
  border-color: #ffffff !important;
}
.admin-chat-page .col-lg-8 > .border {
  background: #17181a !important;
  border-color: #6b7078 !important;
}
.admin-chat-page .col-lg-8 h5 {
  background: #0b0b0c !important;
  color: #ffffff !important;
  border-bottom-color: #6b7078 !important;
}
.admin-chat-page .col-lg-8 h5 + div { background: #0b0b0c !important; }
.admin-chat-page .col-lg-8 h5 + div .bg-primary {
  background: #e6e7e9 !important;
  color: #111214 !important;
  border-color: #ffffff !important;
}
.admin-chat-page .col-lg-8 h5 + div .bg-white {
  background: #34363a !important;
  color: #ffffff !important;
  border-color: #6b7078 !important;
}
.admin-chat-page .col-lg-8 h5 + div small { color: #55585d !important; }
.admin-chat-page .col-lg-8 form {
  background: #24262a !important;
  border-top-color: #6b7078 !important;
}
.admin-chat-page .col-lg-8 form .form-control {
  background: #0f1011 !important;
  color: #ffffff !important;
  border-color: #aeb2b8 !important;
}
.admin-chat-page .col-lg-8 form .form-control::placeholder { color: #c7c9cd !important; }
.admin-chat-page .col-lg-8 form .btn {
  background: #ffffff !important;
  color: #111214 !important;
  border-color: #ffffff !important;
  font-weight: 800 !important;
}
</style>
<style id="omgvip-chat-reply-banner-text-fix">
/* Ensure the chat notification sentence is readable */
#contactAdminModal .chat-reply-banner,
#contactAdminModal .chat-reply-banner span,
#contactAdminModal .chat-reply-banner i {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  opacity: 1 !important;
  visibility: visible !important;
  text-shadow: none !important;
}
#contactAdminModal .chat-reply-banner {
  background: #34363a !important;
  border: 1px solid #aeb2b8 !important;
  font-weight: 600 !important;
}
</style>
<style id="omgvip-chat-close-button-fix">
/* Visible and touch-friendly close button for the admin chat window */
#contactAdminModal .btn-close,
#contactAdminModal .chat-modal-header .btn-close {
  width: 36px !important;
  height: 36px !important;
  padding: 10px !important;
  margin: 0 2px 0 auto !important;
  border: 2px solid #ffffff !important;
  border-radius: 10px !important;
  background-color: #e6e7e9 !important;
  background-size: 14px 14px !important;
  background-position: center !important;
  background-repeat: no-repeat !important;
  filter: none !important;
  opacity: 1 !important;
  box-shadow: 0 2px 8px rgba(0,0,0,.35) !important;
}
#contactAdminModal .btn-close:hover,
#contactAdminModal .btn-close:focus {
  background-color: #ffffff !important;
  border-color: #ffffff !important;
  opacity: 1 !important;
  transform: scale(1.06) !important;
}
</style>
<style id="omgvip-chat-close-button-large-fix">
/* Larger close control with an explicit visible X */
#contactAdminModal .chat-modal-header .btn-close,
#contactAdminModal button.btn-close {
  position: relative !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  flex: 0 0 48px !important;
  width: 48px !important;
  min-width: 48px !important;
  max-width: 48px !important;
  height: 48px !important;
  min-height: 48px !important;
  max-height: 48px !important;
  padding: 0 !important;
  background: #e6e7e9 !important;
  background-image: none !important;
  border: 2px solid #ffffff !important;
  border-radius: 12px !important;
  filter: none !important;
  opacity: 1 !important;
}
#contactAdminModal .chat-modal-header .btn-close::before,
#contactAdminModal button.btn-close::before {
  content: "×" !important;
  display: block !important;
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
  font: 700 34px/42px Arial, sans-serif !important;
  text-align: center !important;
}
#contactAdminModal .chat-modal-header .btn-close:hover,
#contactAdminModal button.btn-close:hover {
  background: #ffffff !important;
  transform: scale(1.08) !important;
}
@media (max-width: 480px) {
  #contactAdminModal .chat-modal-header .btn-close,
  #contactAdminModal button.btn-close {
    flex-basis: 48px !important;
    width: 48px !important;
    min-width: 48px !important;
    height: 48px !important;
    min-height: 48px !important;
  }
}
</style>
<style id="omgvip-chat-close-button-small-fix">
/* Compact close control */
#contactAdminModal .chat-modal-header .btn-close,
#contactAdminModal button.btn-close {
  flex: 0 0 32px !important;
  width: 32px !important;
  min-width: 32px !important;
  max-width: 32px !important;
  height: 32px !important;
  min-height: 32px !important;
  max-height: 32px !important;
  padding: 0 !important;
  border-radius: 8px !important;
  border-width: 1px !important;
}
#contactAdminModal .chat-modal-header .btn-close::before,
#contactAdminModal button.btn-close::before {
  font-size: 25px !important;
  line-height: 28px !important;
}
@media (max-width: 480px) {
  #contactAdminModal .chat-modal-header .btn-close,
  #contactAdminModal button.btn-close {
    flex-basis: 32px !important;
    width: 32px !important;
    min-width: 32px !important;
    height: 32px !important;
    min-height: 32px !important;
  }
}
</style>
<style id="omgvip-notice-popup-close-fix">
/* Visible close button for announcement popup */
#xez_popup .btn-close,
#xez_popup button[data-bs-dismiss="modal"],
#xez_popup .popup-close {
  position: relative !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 32px !important;
  min-width: 32px !important;
  height: 32px !important;
  min-height: 32px !important;
  padding: 0 !important;
  margin: 0 4px 0 auto !important;
  background: #e6e7e9 !important;
  background-image: none !important;
  border: 1px solid #111214 !important;
  border-radius: 8px !important;
  filter: none !important;
  opacity: 1 !important;
  box-shadow: 0 2px 8px rgba(0,0,0,.25) !important;
}
#xez_popup .btn-close::before,
#xez_popup button[data-bs-dismiss="modal"]::before,
#xez_popup .popup-close::before {
  content: "×" !important;
  display: block !important;
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
  font: 700 25px/29px Arial, sans-serif !important;
  text-align: center !important;
}
#xez_popup .btn-close:hover,
#xez_popup button[data-bs-dismiss="modal"]:hover,
#xez_popup .popup-close:hover {
  background: #ffffff !important;
  transform: scale(1.06) !important;
}
</style>
<style id="omgvip-home-recommendations-readable-fix">
/* HOME featured categories/products: bright cards with dark readable text */
body:has(.home-hero-banner) .cat-card-horizontal,
body:has(.home-hero-banner) .product-card {
  background: #ffffff !important;
  color: #17181a !important;
  border: 1px solid #b8bbc0 !important;
  box-shadow: 0 6px 18px rgba(0,0,0,.16) !important;
}
body:has(.home-hero-banner) .cat-card-horizontal h5,
body:has(.home-hero-banner) .cat-card-horizontal .cat-card-info,
body:has(.home-hero-banner) .cat-card-horizontal .cat-card-info p,
body:has(.home-hero-banner) .product-card h6,
body:has(.home-hero-banner) .product-card .text-dark {
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
  opacity: 1 !important;
  text-shadow: none !important;
}
body:has(.home-hero-banner) .cat-card-horizontal p,
body:has(.home-hero-banner) .cat-card-horizontal .text-muted,
body:has(.home-hero-banner) .product-card .text-muted {
  color: #4f5358 !important;
  -webkit-text-fill-color: #4f5358 !important;
  opacity: 1 !important;
}
body:has(.home-hero-banner) .product-card .text-xez-primary {
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
  font-weight: 800 !important;
}
body:has(.home-hero-banner) .cat-card-action i,
body:has(.home-hero-banner) .product-card .cat-card-action i {
  color: #34363a !important;
  -webkit-text-fill-color: #34363a !important;
}
body:has(.home-hero-banner) .cat-card-horizontal:hover,
body:has(.home-hero-banner) .product-card:hover {
  border-color: #34363a !important;
  box-shadow: 0 10px 24px rgba(0,0,0,.22) !important;
}
body:has(.home-hero-banner) .product-card .badge {
  background: #111214 !important;
  color: #ffffff !important;
  border-color: #111214 !important;
}
body:has(.home-hero-banner) .product-card .xez-detail-btn,
body:has(.home-hero-banner) .product-card .xez-order-btn,
body:has(.home-hero-banner) .product-card .xez-soldout-btn {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  background: #34363a !important;
  border: 1px solid #111214 !important;
  opacity: 1 !important;
}
body:has(.home-hero-banner) .product-card .xez-detail-btn:hover,
body:has(.home-hero-banner) .product-card .xez-order-btn:hover {
  background: #111214 !important;
}
body:has(.home-hero-banner) > * .mb-5 > .d-flex h4,
body:has(.home-hero-banner) > * .mb-5 > .d-flex h4 + p {
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
}
</style>
<style id="omgvip-shop-category-readable-fix">
/* Shop category index: readable heading, description, and image overlays */
body:has(.xez-card[style*="height: 200px"]) .container-sm > .text-center.mb-5 h3 {
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
  text-shadow: none !important;
}
body:has(.xez-card[style*="height: 200px"]) .container-sm > .text-center.mb-5 h3 i {
  color: #34363a !important;
  -webkit-text-fill-color: #34363a !important;
}
body:has(.xez-card[style*="height: 200px"]) .container-sm > .text-center.mb-5 p,
body:has(.xez-card[style*="height: 200px"]) .container-sm > .text-center.mb-5 .text-muted {
  color: #34363a !important;
  -webkit-text-fill-color: #34363a !important;
  opacity: 1 !important;
  font-weight: 500 !important;
}
body:has(.xez-card[style*="height: 200px"]) .xez-card[style*="height: 200px"] {
  border: 2px solid #aeb2b8 !important;
  box-shadow: 0 8px 22px rgba(0,0,0,.24) !important;
}
body:has(.xez-card[style*="height: 200px"]) .xez-card[style*="height: 200px"] > .position-absolute {
  background: linear-gradient(to top, rgba(0,0,0,.94) 0%, rgba(0,0,0,.58) 58%, rgba(0,0,0,.08) 100%) !important;
}
body:has(.xez-card[style*="height: 200px"]) .xez-card[style*="height: 200px"] .text-white,
body:has(.xez-card[style*="height: 200px"]) .xez-card[style*="height: 200px"] .text-white h4,
body:has(.xez-card[style*="height: 200px"]) .xez-card[style*="height: 200px"] .text-white p {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  opacity: 1 !important;
  text-shadow: 0 2px 4px rgba(0,0,0,.85) !important;
}
body:has(.xez-card[style*="height: 200px"]) .xez-card[style*="height: 200px"] .text-white h4 {
  font-weight: 800 !important;
}
</style>
<style id="omgvip-website-settings-readable-fix">
/* Website settings page: clear monochrome admin form */
body:has(#site_name) .p-4.p-lg-5 {
  background: #f2f3f4 !important;
  color: #111214 !important;
}
body:has(#site_name) .p-4.p-lg-5 h3,
body:has(#site_name) .p-4.p-lg-5 h6,
body:has(#site_name) .p-4.p-lg-5 label,
body:has(#site_name) .p-4.p-lg-5 .form-label,
body:has(#site_name) .p-4.p-lg-5 .form-check-label {
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
  opacity: 1 !important;
  text-shadow: none !important;
}
body:has(#site_name) .p-4.p-lg-5 > .d-flex p,
body:has(#site_name) .p-4.p-lg-5 .text-muted,
body:has(#site_name) .p-4.p-lg-5 small.text-muted,
body:has(#site_name) .p-4.p-lg-5 .form-check p {
  color: #4f5358 !important;
  -webkit-text-fill-color: #4f5358 !important;
  opacity: 1 !important;
}
body:has(#site_name) .p-4.p-lg-5 .bg-light {
  background: #ffffff !important;
  color: #111214 !important;
  border-color: #b8bbc0 !important;
}
body:has(#site_name) .p-4.p-lg-5 .border,
body:has(#site_name) .p-4.p-lg-5 .form-check.border {
  border-color: #b8bbc0 !important;
}
body:has(#site_name) .p-4.p-lg-5 .form-control,
body:has(#site_name) .p-4.p-lg-5 .form-select,
body:has(#site_name) .p-4.p-lg-5 textarea,
body:has(#site_name) .p-4.p-lg-5 input[type="text"] {
  background: #ffffff !important;
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
  border: 1px solid #8b9097 !important;
  box-shadow: none !important;
  opacity: 1 !important;
}
body:has(#site_name) .p-4.p-lg-5 .form-control::placeholder,
body:has(#site_name) .p-4.p-lg-5 textarea::placeholder {
  color: #5d6268 !important;
  opacity: 1 !important;
}
body:has(#site_name) .p-4.p-lg-5 .form-control:focus,
body:has(#site_name) .p-4.p-lg-5 .form-select:focus,
body:has(#site_name) .p-4.p-lg-5 textarea:focus {
  border-color: #111214 !important;
  box-shadow: 0 0 0 3px rgba(17,18,20,.16) !important;
}
body:has(#site_name) .p-4.p-lg-5 .input-group-text {
  background: #ffffff !important;
  color: #111214 !important;
  border-color: #8b9097 !important;
}
body:has(#site_name) .p-4.p-lg-5 .btn-outline-primary,
body:has(#site_name) .p-4.p-lg-5 .btn-outline-secondary,
body:has(#site_name) .p-4.p-lg-5 .btn-outline-dark,
body:has(#site_name) .p-4.p-lg-5 .btn-outline-warning {
  color: #111214 !important;
  border-color: #34363a !important;
  background: #ffffff !important;
  opacity: 1 !important;
}
body:has(#site_name) .p-4.p-lg-5 .btn-outline-primary:hover,
body:has(#site_name) .p-4.p-lg-5 .btn-outline-secondary:hover,
body:has(#site_name) .p-4.p-lg-5 .btn-outline-dark:hover,
body:has(#site_name) .p-4.p-lg-5 .btn-outline-warning:hover {
  color: #ffffff !important;
  background: #34363a !important;
}
body:has(#site_name) .p-4.p-lg-5 #open_insert,
body:has(#site_name) .p-4.p-lg-5 #btn_regis {
  background: #111214 !important;
  color: #ffffff !important;
  border-color: #111214 !important;
}
body:has(#site_name) .p-4.p-lg-5 .form-check-input {
  border-color: #6b7078 !important;
}
body:has(#site_name) .p-4.p-lg-5 .form-check-input:checked {
  background-color: #111214 !important;
  border-color: #111214 !important;
}
</style>
<style id="omgvip-website-toggle-readable-fix">
/* High-contrast on/off switches for website settings */
body:has(#site_name) .form-switch .form-check-input {
  width: 3.1em !important;
  height: 1.7em !important;
  margin-top: 0 !important;
  background-color: #d5d7da !important;
  background-image: var(--bs-form-switch-bg) !important;
  background-position: left center !important;
  background-size: contain !important;
  border: 2px solid #34363a !important;
  border-radius: 2em !important;
  box-shadow: inset 0 0 0 1px rgba(255,255,255,.55), 0 1px 3px rgba(0,0,0,.2) !important;
  opacity: 1 !important;
}
body:has(#site_name) .form-switch .form-check-input:focus {
  border-color: #111214 !important;
  box-shadow: 0 0 0 3px rgba(17,18,20,.18) !important;
}
body:has(#site_name) .form-switch .form-check-input:checked {
  background-color: #111214 !important;
  background-position: right center !important;
  border-color: #111214 !important;
}
body:has(#site_name) .form-switch .form-check-input:not(:checked) {
  background-color: #d5d7da !important;
  border-color: #34363a !important;
}
body:has(#site_name) .form-switch .form-check-label {
  color: #111214 !important;
  font-weight: 700 !important;
}
</style>
<style id="omgvip-admin-history-readable-fix">
/* Admin purchase/top-up history tables */
body:has(.fa-history) .p-4.p-lg-5,
body:has(.fa-coins) .p-4.p-lg-5 {
  background: #f2f3f4 !important;
  color: #111214 !important;
}
body:has(.fa-history) .p-4.p-lg-5 h3,
body:has(.fa-coins) .p-4.p-lg-5 h3 {
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
}
body:has(.fa-history) .p-4.p-lg-5 > .mb-5 p,
body:has(.fa-coins) .p-4.p-lg-5 > .mb-5 p {
  color: #4f5358 !important;
  -webkit-text-fill-color: #4f5358 !important;
  opacity: 1 !important;
}
body:has(.fa-history) .p-4.p-lg-5 .table-responsive,
body:has(.fa-coins) .p-4.p-lg-5 .table-responsive {
  background: #ffffff !important;
  border: 1px solid #aeb2b8 !important;
  border-radius: 14px !important;
  overflow-x: auto !important;
  box-shadow: 0 6px 18px rgba(0,0,0,.12) !important;
}
body:has(.fa-history) .p-4.p-lg-5 table,
body:has(.fa-coins) .p-4.p-lg-5 table {
  color: #111214 !important;
  margin-bottom: 0 !important;
  min-width: 720px !important;
}
body:has(.fa-history) .p-4.p-lg-5 thead,
body:has(.fa-coins) .p-4.p-lg-5 thead {
  background: #111214 !important;
}
body:has(.fa-history) .p-4.p-lg-5 thead th,
body:has(.fa-coins) .p-4.p-lg-5 thead th {
  background: #111214 !important;
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  border-bottom: 2px solid #6b7078 !important;
  white-space: nowrap !important;
}
body:has(.fa-history) .p-4.p-lg-5 tbody tr,
body:has(.fa-coins) .p-4.p-lg-5 tbody tr {
  background: #ffffff !important;
  color: #111214 !important;
  border-bottom: 1px solid #d0d2d5 !important;
}
body:has(.fa-history) .p-4.p-lg-5 tbody tr:nth-child(even),
body:has(.fa-coins) .p-4.p-lg-5 tbody tr:nth-child(even) {
  background: #f4f5f6 !important;
}
body:has(.fa-history) .p-4.p-lg-5 tbody tr:hover,
body:has(.fa-coins) .p-4.p-lg-5 tbody tr:hover {
  background: #e6e7e9 !important;
}
body:has(.fa-history) .p-4.p-lg-5 tbody td,
body:has(.fa-coins) .p-4.p-lg-5 tbody td {
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
  opacity: 1 !important;
  vertical-align: middle !important;
}
body:has(.fa-history) .p-4.p-lg-5 .text-muted,
body:has(.fa-coins) .p-4.p-lg-5 .text-muted {
  color: #4f5358 !important;
  -webkit-text-fill-color: #4f5358 !important;
  opacity: 1 !important;
}
body:has(.fa-history) .p-4.p-lg-5 .bg-light,
body:has(.fa-history) .p-4.p-lg-5 .bg-light-soft,
body:has(.fa-coins) .p-4.p-lg-5 .bg-light,
body:has(.fa-coins) .p-4.p-lg-5 .bg-light-soft {
  background: #e6e7e9 !important;
  color: #111214 !important;
}
body:has(.fa-history) .p-4.p-lg-5 .badge,
body:has(.fa-coins) .p-4.p-lg-5 .badge {
  color: #111214 !important;
  border: 1px solid #6b7078 !important;
  opacity: 1 !important;
}
body:has(.fa-coins) .p-4.p-lg-5 .text-success {
  color: #111214 !important;
  -webkit-text-fill-color: #111214 !important;
  font-weight: 800 !important;
}
/* DataTables controls and pagination */
body:has(.fa-history) .dataTables_wrapper,
body:has(.fa-coins) .dataTables_wrapper {
  color: #111214 !important;
}
body:has(.fa-history) .dataTables_wrapper label,
body:has(.fa-coins) .dataTables_wrapper label,
body:has(.fa-history) .dataTables_info,
body:has(.fa-coins) .dataTables_info {
  color: #34363a !important;
}
body:has(.fa-history) .dataTables_wrapper input,
body:has(.fa-coins) .dataTables_wrapper input,
body:has(.fa-history) .dataTables_wrapper select,
body:has(.fa-coins) .dataTables_wrapper select {
  background: #ffffff !important;
  color: #111214 !important;
  border: 1px solid #8b9097 !important;
}
body:has(.fa-history) .dataTables_wrapper .paginate_button,
body:has(.fa-coins) .dataTables_wrapper .paginate_button {
  color: #111214 !important;
  border-color: #aeb2b8 !important;
}
</style>
<style id="omgvip-card-running-border-monochrome">
/* Monochrome animated border running around homepage cards */
@keyframes omgvipCardBorderRun {
  to { transform: rotate(360deg); }
}
@media (prefers-reduced-motion: no-preference) {
  body:has(.home-hero-banner) .product-card,
  body:has(.home-hero-banner) .cat-card-horizontal,
  body:has(.home-hero-banner) .home-nav-card {
    position: relative !important;
    isolation: isolate !important;
    overflow: hidden !important;
    border: 0 !important;
    background: #ffffff !important;
  }
  body:has(.home-hero-banner) .product-card::before,
  body:has(.home-hero-banner) .cat-card-horizontal::before,
  body:has(.home-hero-banner) .home-nav-card::before {
    content: "" !important;
    position: absolute !important;
    z-index: -2 !important;
    inset: -75% !important;
    background: conic-gradient(from 0deg, transparent 0deg, transparent 235deg, #aeb2b8 280deg, #ffffff 315deg, #34363a 342deg, transparent 360deg) !important;
    animation: omgvipCardBorderRun 3.8s linear infinite !important;
    pointer-events: none !important;
  }
  body:has(.home-hero-banner) .product-card::after,
  body:has(.home-hero-banner) .cat-card-horizontal::after,
  body:has(.home-hero-banner) .home-nav-card::after {
    content: "" !important;
    position: absolute !important;
    z-index: -1 !important;
    inset: 2px !important;
    border-radius: inherit !important;
    background: #ffffff !important;
    pointer-events: none !important;
  }
  body:has(.home-hero-banner) .product-card > *,
  body:has(.home-hero-banner) .cat-card-horizontal > *,
  body:has(.home-hero-banner) .home-nav-card > * {
    position: relative !important;
    z-index: 1 !important;
  }
  body:has(.home-hero-banner) .product-card:hover::before,
  body:has(.home-hero-banner) .cat-card-horizontal:hover::before,
  body:has(.home-hero-banner) .home-nav-card:hover::before {
    animation-duration: 2.1s !important;
    filter: drop-shadow(0 0 5px rgba(255,255,255,.9)) !important;
  }
}
@media (prefers-reduced-motion: reduce) {
  body:has(.home-hero-banner) .product-card::before,
  body:has(.home-hero-banner) .cat-card-horizontal::before,
  body:has(.home-hero-banner) .home-nav-card::before { display: none !important; }
}
</style>
<style id="omgvip-card-running-border-layer-fix">
/* Keep the animated border above the card background but below its content */
@media (prefers-reduced-motion: no-preference) {
  body:has(.home-hero-banner) .product-card::before,
  body:has(.home-hero-banner) .cat-card-horizontal::before,
  body:has(.home-hero-banner) .home-nav-card::before { z-index: 0 !important; }
  body:has(.home-hero-banner) .product-card::after,
  body:has(.home-hero-banner) .cat-card-horizontal::after,
  body:has(.home-hero-banner) .home-nav-card::after { z-index: 0 !important; }
}
</style>
<style id="omgvip-effect-color-runtime-final">
:root{--omg-effect-dark:<?= htmlspecialchars($glow_dark_color, ENT_QUOTES, 'UTF-8') ?>;--omg-effect-light:<?= htmlspecialchars($glow_light_color, ENT_QUOTES, 'UTF-8') ?>}
<?php if (($config['glow_enabled'] ?? 'on') === 'on'): ?>
body:has(.home-hero-banner) .product-card::before,body:has(.home-hero-banner) .cat-card-horizontal::before,body:has(.home-hero-banner) .home-nav-card::before{background:conic-gradient(from 0deg,transparent 0deg,transparent 235deg,var(--omg-effect-dark) 280deg,var(--omg-effect-light) 315deg,var(--omg-effect-dark) 342deg,transparent 360deg)!important;display:block!important}
<?php else: ?>
body:has(.home-hero-banner) .product-card::before,body:has(.home-hero-banner) .product-card::after,body:has(.home-hero-banner) .cat-card-horizontal::before,body:has(.home-hero-banner) .cat-card-horizontal::after,body:has(.home-hero-banner) .home-nav-card::before,body:has(.home-hero-banner) .home-nav-card::after{display:none!important}
<?php endif; ?>
</style>


<style id="omgvipshop-home-theme-final">
/* OMGVIPSHOP: keep the Home page aligned with the global purple theme. */
body:has(.home-hero-banner){background:var(--xez-bg)!important;color:var(--xez-text-color)!important}
body:has(.home-hero-banner) .home-hero-banner{background:radial-gradient(ellipse 70% 45% at 50% 15%,rgba(var(--xez-primary-rgb),.22),transparent 68%),linear-gradient(180deg,var(--xez-card) 0%,var(--xez-bg) 100%)!important;color:var(--xez-text-color)!important;border-bottom:1px solid var(--xez-border)!important}
body:has(.home-hero-banner) .home-hero-title{color:var(--xez-text-color)!important;text-shadow:0 0 20px rgba(var(--xez-primary-rgb),.45)!important}
body:has(.home-hero-banner) .home-hero-tagline{background:linear-gradient(135deg,var(--xez-primary),var(--xez-secondary))!important;color:#fff!important;box-shadow:0 8px 30px rgba(var(--xez-primary-rgb),.35)!important}
body:has(.home-hero-banner) .home-hero-tagline span{color:#fff!important}
body:has(.home-hero-banner) .home-btn-primary{background:linear-gradient(135deg,var(--xez-primary),var(--xez-secondary))!important;border-color:var(--xez-primary)!important;color:#fff!important}
body:has(.home-hero-banner) .home-btn-outline{background:transparent!important;border:1px solid var(--xez-border)!important;color:var(--xez-text-color)!important}
body:has(.home-hero-banner) .home-btn-outline:hover{background:rgba(var(--xez-primary-rgb),.14)!important;color:var(--xez-text-color)!important}
body:has(.home-hero-banner) .home-announcement-bar,body:has(.home-hero-banner) .announcement-bar{background:rgba(20,10,34,.92)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important;box-shadow:0 4px 18px rgba(0,0,0,.28)!important}
body:has(.home-hero-banner) .home-announcement-bar .announcement-icon,body:has(.home-hero-banner) .announcement-bar .announcement-icon{background:var(--xez-primary)!important;color:#fff!important}
body:has(.home-hero-banner) .announcement-content,body:has(.home-hero-banner) .announcement-content marquee{color:var(--xez-text-color)!important}
body:has(.home-hero-banner) .home-stats-bar{background:rgba(20,10,34,.94)!important;border-color:var(--xez-border)!important;box-shadow:0 4px 18px rgba(0,0,0,.3)!important}
body:has(.home-hero-banner) .home-stat-item{border-color:rgba(var(--xez-primary-rgb),.22)!important}
body:has(.home-hero-banner) .home-stat-label{color:var(--xez-text-color)!important;opacity:.72}
body:has(.home-hero-banner) .home-stat-value{color:var(--xez-text-color)!important}.home-stat-value small{color:var(--xez-secondary)!important}
body:has(.home-hero-banner) .home-stat-icon{background:rgba(var(--xez-primary-rgb),.15)!important}.home-stat-icon i{color:var(--xez-secondary)!important}
body:has(.home-hero-banner) .home-nav-card,body:has(.home-hero-banner) .product-card,body:has(.home-hero-banner) .cat-card-horizontal,body:has(.home-hero-banner) .xez-card{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important;box-shadow:0 8px 22px rgba(0,0,0,.28)!important}
body:has(.home-hero-banner) .home-nav-card h6,body:has(.home-hero-banner) .product-card h6,body:has(.home-hero-banner) .cat-card-horizontal h5{color:var(--xez-text-color)!important}
body:has(.home-hero-banner) .home-nav-card p,body:has(.home-hero-banner) .product-card p,body:has(.home-hero-banner) .cat-card-horizontal p{color:var(--xez-text-color)!important;opacity:.72}
body:has(.home-hero-banner) .home-nav-icon{background:rgba(var(--xez-primary-rgb),.16)!important;border:1px solid var(--xez-border)!important}.home-nav-icon i{color:var(--xez-secondary)!important}
body:has(.home-hero-banner) .product-card .badge{background:var(--xez-primary)!important;color:#fff!important;border-color:var(--xez-primary)!important}
body:has(.home-hero-banner) .product-card::after,body:has(.home-hero-banner) .cat-card-horizontal::after,body:has(.home-hero-banner) .home-nav-card::after{background:var(--xez-card)!important}
body:has(.home-hero-banner) footer,body:has(.home-hero-banner) .home-footer{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
</style>


<style id="omgvipshop-navbar-theme-final">
/* OMGVIPSHOP: remove legacy white navbar overrides on Home and all pages. */
.navbar-collapse{background:rgba(20,10,34,.97)!important;border:1px solid var(--xez-border)!important;border-radius:12px!important}
.navbar,.main-navbar{background:rgba(8,5,16,.97)!important;border-bottom-color:var(--xez-border)!important}
.navbar-brand,.navbar-text-brand,.navbar a,.nav-link,.navbar .nav-link{color:var(--xez-text-color)!important}
.navbar a:hover,.nav-link:hover{color:var(--xez-secondary)!important}
.navbar .nav-link i,.nav-link-xez i,.navbar-toggler i{color:var(--xez-secondary)!important}
.navbar-toggler{background:var(--xez-card)!important;border-color:var(--xez-border)!important;color:var(--xez-text-color)!important}
.btn-navbar-register{background:linear-gradient(135deg,var(--xez-primary),var(--xez-secondary))!important;border-color:var(--xez-primary)!important;color:#fff!important}
.dropdown-menu{background:var(--xez-card)!important;border-color:var(--xez-border)!important}
.dropdown-menu a{color:var(--xez-text-color)!important}.dropdown-menu a:hover{background:rgba(var(--xez-primary-rgb),.16)!important;color:var(--xez-text-color)!important}
</style>


<style id="omgvipshop-home-specificity-fix">
/* Higher-specificity override for legacy neutral/white Home selectors. */
body.theme-dark:has(.home-hero-banner),body.theme-light:has(.home-hero-banner),body:not(.theme-dark):has(.home-hero-banner){background:var(--xez-bg)!important;color:var(--xez-text-color)!important}
body.theme-dark:has(.home-hero-banner) .home-hero-banner,body.theme-light:has(.home-hero-banner) .home-hero-banner,body:not(.theme-dark):has(.home-hero-banner) .home-hero-banner{background:linear-gradient(180deg,var(--xez-card),var(--xez-bg))!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
body.theme-dark:has(.home-hero-banner) .home-hero-title,body.theme-light:has(.home-hero-banner) .home-hero-title,body:not(.theme-dark):has(.home-hero-banner) .home-hero-title{color:var(--xez-text-color)!important;text-shadow:0 0 20px rgba(var(--xez-primary-rgb),.45)!important}
body.theme-dark:has(.home-hero-banner) .home-nav-card,body.theme-light:has(.home-hero-banner) .home-nav-card,body:not(.theme-dark):has(.home-hero-banner) .home-nav-card,body.theme-dark:has(.home-hero-banner) .product-card,body.theme-light:has(.home-hero-banner) .product-card,body:not(.theme-dark):has(.home-hero-banner) .product-card,body.theme-dark:has(.home-hero-banner) .cat-card-horizontal,body.theme-light:has(.home-hero-banner) .cat-card-horizontal,body:not(.theme-dark):has(.home-hero-banner) .cat-card-horizontal{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
body.theme-dark:has(.home-hero-banner) .home-nav-card h6,body.theme-light:has(.home-hero-banner) .home-nav-card h6,body:not(.theme-dark):has(.home-hero-banner) .home-nav-card h6,body.theme-dark:has(.home-hero-banner) .product-card h6,body.theme-light:has(.home-hero-banner) .product-card h6,body:not(.theme-dark):has(.home-hero-banner) .product-card h6{color:var(--xez-text-color)!important}
body.theme-dark:has(.home-hero-banner) .home-nav-icon,body.theme-light:has(.home-hero-banner) .home-nav-icon,body:not(.theme-dark):has(.home-hero-banner) .home-nav-icon{background:rgba(var(--xez-primary-rgb),.16)!important;border-color:var(--xez-border)!important}
body.theme-dark:has(.home-hero-banner) .home-stats-bar,body.theme-light:has(.home-hero-banner) .home-stats-bar,body:not(.theme-dark):has(.home-hero-banner) .home-stats-bar{background:var(--xez-card)!important;border-color:var(--xez-border)!important}
body.theme-dark:has(.home-hero-banner) .home-carousel-section,body.theme-light:has(.home-hero-banner) .home-carousel-section,body:not(.theme-dark):has(.home-hero-banner) .home-carousel-section{background:transparent!important}
</style>


<style id="omgvipshop-global-theme-final">
/* OMGVIPSHOP global theme: every major UI surface follows Website Settings. */
html,body{background:var(--xez-bg)!important;color:var(--xez-text-color)!important}
body.theme-dark,body.theme-light{background:var(--xez-bg)!important;color:var(--xez-text-color)!important}
body .card,body .card-body,body .glass-card,body .product-card,body .category-card,body .feature-card,body .shop-card,body .xez-card,body .xdvz-card,body .modal-content,body .offcanvas,body .dropdown-menu{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
body h1,body h2,body h3,body h4,body h5,body h6,body .text-dark{color:var(--xez-text-color)!important}
body p,body .text-muted,body small{color:var(--xez-text-color)!important;opacity:.82}
body a{color:var(--xez-secondary)!important}body a:hover{color:var(--xez-primary)!important}
body .navbar,body .main-navbar,body header{background:rgba(8,5,16,.97)!important;border-color:var(--xez-border)!important}
body .navbar-collapse{background:var(--xez-card)!important;border-color:var(--xez-border)!important}
body .navbar-brand,body .navbar-text-brand,body .navbar a,body .nav-link{color:var(--xez-text-color)!important}
body .navbar a:hover,body .nav-link:hover{color:var(--xez-secondary)!important}
body .btn-primary,body .btn-success,body .btn-info,body .button-primary,body .bg-main,body .xez-btn-cyan,body .btn-login,body .btn-navbar-register{background:linear-gradient(135deg,var(--xez-primary),var(--xez-secondary))!important;border-color:var(--xez-primary)!important;color:#fff!important}
body .btn-primary:hover,body .btn-success:hover,body .btn-info:hover,body .button-primary:hover,body .xez-btn-cyan:hover,body .btn-login:hover,body .btn-navbar-register:hover{filter:brightness(1.12)!important;color:#fff!important}
body .btn-warning,body .xez-order-btn,body .xez-detail-btn{background:var(--xez-warning)!important;border-color:var(--xez-warning)!important;color:#fff!important}
body .btn-danger{background:var(--xez-danger)!important;border-color:var(--xez-danger)!important;color:#fff!important}
body .btn-secondary,body .btn-light,body .btn-outline-primary,body .btn-outline-danger,body .xez-btn-outline{background:transparent!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
body .btn-secondary:hover,body .btn-light:hover,body .btn-outline-primary:hover,body .btn-outline-danger:hover,body .xez-btn-outline:hover{background:rgba(var(--xez-primary-rgb),.16)!important;color:var(--xez-text-color)!important}
body .form-control,body .form-select,body textarea,body input{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
body .form-control::placeholder,body .form-select::placeholder,body input::placeholder,body textarea::placeholder{color:var(--xez-text-color)!important;opacity:.55!important}
body .form-control:focus,body .form-select:focus,body textarea:focus,body input:focus{border-color:var(--xez-primary)!important;box-shadow:0 0 0 3px rgba(var(--xez-primary-rgb),.22)!important}
body .table{color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}body .table thead,body .table th{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}body .table tbody tr,body .table td{border-color:var(--xez-border)!important}body .table tbody tr:hover{background:rgba(var(--xez-primary-rgb),.10)!important}
body .badge,body .hot,body .tag{background:var(--xez-primary)!important;color:#fff!important;border-color:var(--xez-primary)!important}
body .alert,body .toast,body .latest-order-notification,body .order-notification,body .purchase-notification,body .recent-order-toast{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
body footer,body .home-footer{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
body .list-group-item{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
body hr{border-color:var(--xez-border)!important;opacity:.7}
</style>


<style id="omgvipshop-special-surfaces-final">
body .home-stats-bar,body .home-stat-item,body .home-stat-info{color:var(--xez-text-color)!important}
body .home-stat-label,body .home-stat-value,body .home-stat-value small{color:var(--xez-text-color)!important}
body .home-stat-icon{background:rgba(var(--xez-primary-rgb),.16)!important;border-color:var(--xez-border)!important}body .home-stat-icon i{color:var(--xez-secondary)!important}
body .home-announcement-bar,body .announcement-bar{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
body .auth-card,body .login-card,body .register-card{background:var(--xez-card)!important;color:var(--xez-text-color)!important;border-color:var(--xez-border)!important}
body .auth-card h1,body .auth-card h2,body .auth-card h3,body .auth-card h4,body .auth-card h5,body .auth-card h6,body .auth-card label{color:var(--xez-text-color)!important}
</style>


<style id="omgvipshop-home-section-text-final">
body:has(.home-hero-banner) .container-sm h4.fw-bold,body:has(.home-hero-banner) .container-sm h5.fw-bold,body:has(.home-hero-banner) .container-sm h6.fw-bold{color:var(--xez-text-color)!important;text-shadow:0 0 8px rgba(var(--xez-primary-rgb),.18)!important}
body:has(.home-hero-banner) .container-sm p.text-muted,body:has(.home-hero-banner) .container-sm p.small{color:var(--xez-text-color)!important;opacity:.84!important}
body:has(.home-hero-banner) .container-sm .text-xez-primary{color:var(--xez-secondary)!important}
</style>


<style id="omgvipshop-home-description-specificity-final">
body.theme-dark:has(.home-hero-banner) .container-sm p.text-muted,body.theme-light:has(.home-hero-banner) .container-sm p.text-muted,body:not(.theme-dark):has(.home-hero-banner) .container-sm p.text-muted,body.theme-dark:has(.home-hero-banner) .container-sm p.small,body.theme-light:has(.home-hero-banner) .container-sm p.small,body:not(.theme-dark):has(.home-hero-banner) .container-sm p.small{color:var(--xez-text-color)!important;opacity:.88!important}
</style>


<style id="omgvipshop-home-products-text-final">
body:has(.home-hero-banner) .container-sm h4.fw-bold.mb-1,body.theme-dark:has(.home-hero-banner) .container-sm h4.fw-bold.mb-1,body.theme-light:has(.home-hero-banner) .container-sm h4.fw-bold.mb-1{color:#f5efff!important;visibility:visible!important;opacity:1!important}
body:has(.home-hero-banner) .container-sm p.text-muted.small.mb-0,body.theme-dark:has(.home-hero-banner) .container-sm p.text-muted.small.mb-0,body.theme-light:has(.home-hero-banner) .container-sm p.text-muted.small.mb-0{color:#f5efff!important;visibility:visible!important;opacity:.88!important}
body:has(.home-hero-banner) .product-card h6,body.theme-dark:has(.home-hero-banner) .product-card h6,body.theme-light:has(.home-hero-banner) .product-card h6{color:#f5efff!important;visibility:visible!important;opacity:1!important}
body:has(.home-hero-banner) .product-card .text-xez-primary,body.theme-dark:has(.home-hero-banner) .product-card .text-xez-primary,body.theme-light:has(.home-hero-banner) .product-card .text-xez-primary{color:#a855f7!important;visibility:visible!important;opacity:1!important}
body:has(.home-hero-banner) .product-card .text-muted,body.theme-dark:has(.home-hero-banner) .product-card .text-muted,body.theme-light:has(.home-hero-banner) .product-card .text-muted{color:#f5efff!important;opacity:.78!important}
</style>
