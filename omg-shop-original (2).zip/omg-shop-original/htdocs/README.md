# Discord Webhook แจ้งเตือนการเติมเงิน

ชุดไฟล์นี้รับคำขอ `POST` จากโค้ดฝั่งเซิร์ฟเวอร์ แล้วส่ง Embed ไปยัง Discord โดยแสดง **ชื่อผู้ใช้**, **จำนวนเงิน** และเว็บไซต์

## ไฟล์

- `discord_webhook.php` — คลาสส่ง Embed ไป Discord และฟังก์ชันช่วยเหลือ
- `topup_notify.php` — endpoint สำหรับแจ้งเตือนการเติมเงินโดยเฉพาะ
- `notify.php` — endpoint ทั่วไปสำหรับเหตุการณ์อื่น
- `config.example.php` — แม่แบบตั้งค่า ห้ามใช้ Webhook URL จริงในไฟล์ตัวอย่าง

## ติดตั้ง

1. สร้าง Webhook ใหม่ใน Discord ที่ `Server Settings → Integrations → Webhooks` แล้วคัดลอก URL
2. เปลี่ยนชื่อ `config.example.php` เป็น `config.php`
3. ใส่ Webhook URL ใหม่และสร้าง `NOTIFY_API_KEY` เป็นค่าสุ่มยาว ๆ
4. อัปโหลด `discord_webhook.php`, `topup_notify.php` และ `config.php` ขึ้นโฮสต์ โดยเก็บ `config.php` นอก public web root ถ้าทำได้
5. เรียก `topup_notify.php` จาก PHP ฝั่งเซิร์ฟเวอร์เท่านั้น ไม่ควรใส่ API key หรือ Webhook URL ใน JavaScript ของผู้เข้าชม

## ตัวอย่างเรียกจากโค้ดเติมเงิน

```php
$payload = json_encode([
    'username' => $username,
    'amount' => $topupAmount,
], JSON_UNESCAPED_UNICODE);

$ch = curl_init('https://omgvip.shop/topup_notify.php');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'X-Notify-Key: ' . NOTIFY_API_KEY,
    ],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 10,
]);
$response = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($status < 200 || $status >= 300) {
    error_log('Top-up Discord notification failed: ' . (string)$response);
}
```

## ทดสอบด้วย cURL

```bash
curl -X POST 'https://omgvip.shop/topup_notify.php' \
  -H 'Content-Type: application/json' \
  -H 'X-Notify-Key: ใส่ค่าเดียวกับ-NOTIFY_API_KEY' \
  -d '{"username":"ทดสอบ","amount":100}'
```

## ความปลอดภัย

Webhook URL ที่เคยส่งในแชตควรสร้างใหม่ด้วยคำสั่ง **Regenerate URL** ใน Discord ก่อนใช้งานจริง ห้ามส่งรหัสผ่าน เลขบัตร หรือข้อมูลสำคัญเข้า Discord และควรเรียก endpoint หลังจากตรวจสอบการเติมเงินสำเร็จแล้วเท่านั้น เพื่อป้องกันการแจ้งเตือนปลอม

ระบบปิด `allowed_mentions` เพื่อป้องกันข้อความจากผู้ใช้แท็ก `@everyone`, `@here` หรือผู้ใช้อื่นโดยไม่ตั้งใจ
